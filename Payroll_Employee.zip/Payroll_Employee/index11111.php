<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

$doc_path = $_SERVER["DOCUMENT_ROOT"];
include($doc_path . '/include_payroll_admin.php');

$payrollAdmin = new payrollAdmin();

if (!isset($_SESSION['emp_login_id']) || empty($_SESSION['emp_login_id'])) {
    header("Location: /login.php");
    exit();
}

// Retrieve user information from session
$emp_login_id = $_SESSION['emp_login_id'];
$employeeName = $_SESSION['fname'] ?? 'Employee';

// Fetch employee details
$empdetails = $payrollAdmin->showEployeedetails($emp_login_id);
$clientData = $payrollAdmin->displayClient($empdetails['client_id']);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width"/>
    <title>Salary | HR Head Home</title>
    <link rel="stylesheet" href="/Payroll/css/responsive.css">
    <link rel="stylesheet" href="/Payroll/css/style.css">
    <style>
        .userdetailsdiv {
            padding-top: 0.5rem!important;
            text-transform: uppercase;
            margin: auto;
        }
    </style>
</head>
<body>
    <!-- Header starts here -->
    <?php include('header.php'); ?>
    <!-- Header end here -->

    <div class="clearFix"></div>
    <!-- Menu starts here -->
    <!-- Menu ends here -->

    <div class="clearFix"></div>
    <!-- Slider part starts here -->
    <div class="twelve mobicenter innerbg">
        <div class="row">
            <div class="twelve" id="margin1"> <h3>Employee Home Page</h3></div>
            <div class="clearFix"></div>
            <div class="twelve" id="margin1">
                <div class="three columns" id="margin4">
                    <img src="/Payroll/images/no-profile-pic.jpg" height="320">
                </div>
                <div class="nine columns" id="margin4">
                    <div class="card mb-3">
                        <div class="card-body">
                            <div class="row" style="min-height:400px;margin:auto;">
                                <h2 class="h2" style="text-transform: uppercase;text-align:center;">Welcome <?= htmlspecialchars($employeeName) ?></h2>
                                <div class="borderdiv"></div>
                                <div class="col-sm-8 userdetailsdiv">
                                    <div class="twelve" id="margin1">
                                        <div class="four columns"><h6>Full Name:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= htmlspecialchars($empdetails['first_name']." ".$empdetails['middle_name']." ".$empdetails['last_name']) ?></h6></div>
                                        <div class="clearFix"></div>
                                        <div class="four columns"><h6>Client Name:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= htmlspecialchars($clientData['client_name']) ?></h6></div>
                                        <div class="clearFix"></div>
                                        <div class="four columns"><h6>Joining Date:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= ($empdetails['joindate'] && $empdetails['joindate'] != "0000-00-00") ? date('d-m-Y', strtotime($empdetails['joindate'])) : "" ?></h6></div>
                                        <div class="clearFix"></div>
                                        <div class="four columns"><h6>Mobile No.:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= htmlspecialchars($empdetails['mobile_no']) ?></h6></div>
                                        <div class="clearFix"></div>
                                        <div class="four columns"><h6>Email ID:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= htmlspecialchars($empdetails['email']) ?></h6></div>
                                        <div class="clearFix"></div>
                                        <div class="four columns"><h6>Department:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= htmlspecialchars($empdetails['dept']) ?></h6></div>
                                        <div class="clearFix"></div>
                                        <div class="four columns"><h6>Address:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= htmlspecialchars($empdetails['emp_add1']) ?></h6></div>
                                        <div class="clearFix"></div>
                                        <div class="four columns"><h6>Aadhar No:</h6></div>
                                        <div class="eight columns"><h6 class="userdetails"><?= htmlspecialchars($empdetails['adharno']) ?></h6></div>
                                        <div class="clearFix"></div>
                                    </div>
                                </div>
                                <div class="col-sm-4 userdetailsdiv">
                                    <div class="mininav-toggle text-center">
                                        <img class="mainnav__avatar no_profle_img rounded-circle border" src="/public/assets/img/profile-photos/no-profile-pic.jpg" alt="Profile Picture">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <br/>
        </div>
    </div>
    <!-- Slider part ends here -->
    <div class="clearFix"></div>
    <!-- Footer start -->
    <?php include('footer.php'); ?>
    <!-- Footer end -->
</body>
</html>
