
<!--Header starts here-->


<header class="twelve header_bg">

    <div class="row" >

        <div class="twelve padd0 columns" >

            <div class="six padd0 columns mobicenter text-left " id="container1">

                <!-- Modify top header1 start here -->
<br/>
<!--                <a href="index.php"><div class="logo" ><img src="../images/logo.png"></div></a>-->
<?php
error_reporting(E_ALL);
include_once('/home/jgup8bq0n8f6/public_html/Payroll/lib/class/payroll_admin.php');
$payrollAdmin = new payrollAdmin();
$co_id=$_SESSION['comp_id'];
$rowcomp=$payrollAdmin->displayCompany($co_id);
$crmonth = $payrollAdmin->getClientMonth($co_id);
//print_r($_SESSION);die;
echo ' <h4 class="Color2" >'.$rowcomp['comp_name'].' </h4>';
?>
                <br/>
                <!-- Modify top header1 ends here -->

            </div>
<div class="two padd0 columns cmoncl" valign="center" > Month : <b><?php echo date('M Y',strtotime($crmonth['current_month']));?></b></div>

<div class="four padd0 columns text-right text-center" id="container3">

                <!-- Modify top header3  Navigation start here -->


                <div class="mobicenter text-right" id="margin1" >
                    <br/>
                  <a class="btn" href="/payroll-logout">Logout</a>
                    <br/><br/>
                </div>



                <!-- Modify top header3 Navigation start here -->

            </div>




        </div>

</header>

<style>
    .dataTables_filter, label {display: flex !important;}
    .dataTables_filter, table {padding: 0px !important;}
</style>

 <link rel="stylesheet" href="Payroll/css/responsive.css">
  <link rel="stylesheet" href="Payroll/css/style.css">
  <script type="text/javascript" src="Payroll/js/jquery.min.js"></script>
  
 <link href="Payroll/css/jquery.dataTables.min.css" rel="stylesheet">
	<link href="Payroll/css/buttons.dataTables.min.css" rel="stylesheet">

<!--Header end here-->


<?php

 if ($_SESSION['log_type']==6){
        include('menu.php');
 }

?>
