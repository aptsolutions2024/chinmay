<?php
//print_r($_REQUEST);exit;
session_start();
include_once('../lib/class/payroll_admin.php');
$payrollAdmin = new payrollAdmin();
$cid = addslashes($_REQUEST['cid']);
$name = addslashes(strtoupper($_REQUEST['name']));
$add1 = addslashes($_REQUEST['add1']);
$esicode = addslashes($_REQUEST['esicode']);
$pfcode =addslashes($_REQUEST['pfcode']);
$tanno = addslashes($_REQUEST['tanno']);
$panno = addslashes($_REQUEST['panno']);
$gstno = addslashes($_REQUEST['gstno']);
$mont=date("Y-m-d", strtotime($_REQUEST['cm']));

$comp_id = $_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$sc = addslashes($_REQUEST['sc']);
$email = addslashes($_REQUEST['email']);
$parent_comp=$_REQUEST['parent_comp'];
if($parent_comp=='Y'){
$parent=0;
}else{
$parent = addslashes($_REQUEST['parent']);
}
//print_r($_REQUEST);
echo $result = $payrollAdmin->updateClient($cid,$name,$add1,$esicode,$pfcode,$tanno,$panno,$gstno,$mont,$parent,$sc,$email,$comp_id,$user_id,$parent_comp);
?>

