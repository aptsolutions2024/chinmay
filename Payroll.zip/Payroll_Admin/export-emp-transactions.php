<?php
include ('../include_payroll_admin.php');
$payrollAdmin = new payrollAdmin();

if($_SESSION['log_type']==2)
{
    
}else
{
    echo "<script>window.location.href='/payroll-logout';</script>";exit();
}

$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$setExcelName = "employee_detail";
$client_id = $_SESSION['clientid'];

    $head = $payrollAdmin->blankExportTranDays($comp_id,$client_id);
    $setCounter=count($head[1]);
 
    $setMainHeader = "Client_id \tClient_name\tSal_month\t Emp_id\tEmployee_NAME\t";
    $setData = "";
    $cnt=count($head[0]);
    
    for ($i = 1; $i < $cnt; $i++) {
         $setMainHeader .= $head[0][$i] . "\t";
    }
    $setMainHeader .="ticket_no\t Dept_Name\t comp_ticket_no\t";

    foreach ($head[1] as $rec ) {
        $rowLine = '';
        foreach ($rec as $value) {
            if (!isset($value) || $value == "") {
                $value = "\t";
            } else {
//It escape all the special charactor, quotes from the data.
                $value = strip_tags(str_replace('"', '""', $value));
                $value = '"' . $value . '"' . "\t";
            }
            $rowLine .= $value;
        }
        $setData .= trim($rowLine) . "\n";
    }
    $setData = str_replace("\r", "", $setData);

    if ($setData == "") {
        $setData = "\nno matching records found\n";
    }


else{

    if ($setData == "") {
        $setData = "\nno matching records found\n";
    }
}

//echo $setMainHeader;

//This Header is used to make data download instead of display the data
header("Content-type: application/octet-stream");

header("Content-Disposition: attachment; filename=" . $setExcelName . ".xls");

header("Pragma: no-cache");
header("Expires: 0");

//It will print all the Table row as Excel file row with selected column name as header.
echo ucwords($setMainHeader) . "\n" . $setData . "\n";




?>







