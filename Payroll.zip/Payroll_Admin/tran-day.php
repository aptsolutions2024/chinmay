<?php

include ('../include_payroll_admin.php');

if($_SESSION['log_type']==2 || $_SESSION['log_type']==3 )
{
    
}else
{
    echo "<script>window.location.href='/payroll-logout';</script>";exit();
}

$result1 = $payrollAdmin->showClient1($comp_id,$user_id);


?>
<!DOCTYPE html>
<head>
  <meta charset="utf-8"/>
  <!-- Set the viewport width to device width for mobile -->
  <meta name="viewport" content="width=device-width"/>
  <title>Salary | Transactions Days</title>
  <!-- Included CSS Files -->
  <link rel="stylesheet" href="../css/responsive.css">

  <link rel="stylesheet" href="../css/style.css">
    <script type="text/javascript" src="../js/jquery.min.js"></script>
  <script>
      function clstr(){
          $('#clerror').html("");
          $('#lmterror').html("");
      }
        function displaydata(){ //alert("hello");
            $(".successclass").hide();
            clstr();
            var val=$("#client").val();
       $("#client").removeClass('bordererror');
       var lmt=$("#lmt").val();
       $("#lmt").removeClass('bordererror');
       
       
            if(val=='0'){
                $("#client").focus();
               error ="Please Select the Client Name";
	   $("#client").val('');
	   $("#client").addClass('bordererror');
	   $("#client").attr("placeholder", error);
            }
            else if(lmt=='0'){
                $("#lmterror").focus();
                error ="Please Select the Limit";
	   $("#lmterror").val('');
	   $("#lmterror").addClass('bordererror');
	   $("#lmterror").attr("placeholder", error);
            }
            else {
             $.post('/display-tran-days',{
                'id':val,
                'lmt':lmt
            },function(data){
                $("#display").html(data);
                $("#display").show();
            });
            monthdisplay(val);

            }
        }

      function monthdisplay(val){
          $.post('/display-monthval',{
              'id':val
          },function(data){
              $("#sm").html(data);
              $("#sm").show();
          });
      }

  </script>

 <body>

<!--Header starts here-->
<?php include('header.php');?>
<!--Header end here-->
<div class="clearFix"></div>
<div class="clearFix"></div>
<!--Slider part starts here-->

<form id="form" action="/tran-day-process" method="post">
<div class="twelve mobicenter innerbg">
    <div class="row">
        <div class="twelve padd0" id="margin1"> <h3>Transactions Days</h3></div>
        <div class="clearFix"></div>
                <?php
                if(isset($_REQUEST['msg']) && $_REQUEST['msg']=='update'){
                    ?>
                <div class="twelve padd0 columns successclass">
                    <br />Transactions Updated successfully!<br />
                </div>
                <?php
                }
                ?>
                <div class="clearFix"></div>
            <div class="twelve" id="margin1">
                <div class="boxborder" style="min-height: 100px;">
                <div class="one padd0 columns"  >
                    <span class="labelclass">Client :</span>
                </div>
                <div class="four padd0 columns"  >
                    <select class="textclass" name="client" id="client" onchange="displaydata();">
                        <option value="0">--Select--</option>
                        <?php foreach ($result1 as $row1){?>
                            <option value="<?php echo $row1['mast_client_id']; ?>"><?php echo $row1['client_name']; ?></option>
                        <?php } ?>
                    </select>
                    <span class="errorclass hidecontent" id="clerror"></span>
                </div>


                <div class="two padd0 columns"  align="center">
                    <span class="labelclass">Record Range :</span>
                </div>
                <div class="two padd0 columns">
                    <select class="textclass" name="lmt" id="lmt" onchange="displaydata();">
                     


                        <option value="0, 30">0 to 30</option>
                        <option value="30, 30">31 to 60</option>
                        <option value="60, 30">61 to 90</option>
                        <option value="90, 30">91 to 120</option>
                        <option value="120, 30">121 to 150</option>
                        <option value="150, 30">151 to 180</option>
                        <option value="180, 30">181 to 210</option>
                        <option value="210, 30">211 to 240</option>
                        <option value="240, 30">241 to 270</option>
                        <option value="270, 30">271 to 300</option>
                        <option value="300, 30">301 to 330</option>
                        <option value="330, 30">331 to 360</option>


                    </select>
                    <span class="errorclass hidecontent" id="lmterror"></span>
                </div>
                <div class="three columns">
                    <span class="labelclass">Month :</span> <span class="labelclass" id="sm">&nbsp;&nbsp;&nbsp;-&nbsp;&nbsp; &nbsp;&nbsp;&nbsp; </span>&nbsp;

                    <input type="button" onclick="displaydata();" class="btnclass" value="Show" >
                </div>
               
                <div class="clearFix"></div>

    <div class="twelve" id="display" align="center">
        </div>
         </div>
         </div>
    </div>
	</div>
</form>
</div>
<!--Slider part ends here-->
<div class="clearFix"></div>

<!--footer start -->
<?php include('footer.php');?>

<!--<script src="http://code.jquery.com/jquery-1.8.2.js"></script>
<script src="http://code.jquery.com/ui/1.9.1/jquery-ui.js"></script>-->

<!--footer end -->

</body>

</html>