<?php
include ('../include_payroll_admin.php');
$payrollAdmin = new payrollAdmin();
$name = addslashes(strtoupper($_REQUEST['name']));
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$result = $payrollAdmin->insertDepartment($name,$comp_id,$user_id);
?>

