<?php
include ('../../include_payroll_admin.php');
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$setCounter = 0;
//print_r($_SESSION);die;
$clientid=$_SESSION['clientid'];
$month=$_SESSION['month'];
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$clintid=$_SESSION['clintid'];
$setExcelName = "employee_detail";
$emp=$_REQUEST['emp'];


//$res=$payrollAdmin->showEmployeereport($comp_id,$user_id);
$resclt=$payrollAdmin->displayClient($clintid);
$cmonth=$resclt['current_month'];
if($month=='current'){
    $monthtit =  date('F Y',strtotime($cmonth));
    $tab_days='tran_days';	
    $tab_emp='tran_employee';
    $tab_empinc='tran_income';
    $tab_empded='tran_deduct';
    $frdt=$cmonth;
    $todt=$cmonth;
 }
else{
    $monthtit =  date('F Y',strtotime($_SESSION['frdt']));
    $tab_days='hist_days';
    $tab_emp='hist_employee';
    $tab_empinc='hist_income';
    $tab_empded='hist_deduct';

    $frdt=date("Y-m-d", strtotime($_SESSION['frdt']));
    $todt=date("Y-m-d", strtotime($_SESSION['frdt']));
	
/*	$res=$payrollAdmin->lastDay($frdt);
	$frdt = $res['last_day'];
*/	
echo $frdt=$payrollAdmin->lastDay($frdt);
	
 }

$p='';
if($emp=='Parent'){
    $p="(P)";
}

$setExcelName = "uan_ecr".$p;

$rows=$payrollAdmin->deleteUAN();


if($emp=='Parent')
	{
	   $sql = "select e.client_id,tdd.head_id ,mc.client_name,t4.gross_salary,tdd.amount as amount,tdd.std_amt as std_amt,tdd.employer_contri_1 as employer_contri_1,tdd.employer_contri_2 as employer_contri_2,e.uan,e.first_name,e.middle_name,e.last_name,round(t5.absent,0) as absent from $tab_empded tdd inner join mast_deduct_heads md on tdd.head_id = md.mast_deduct_heads_id inner join employee e on e.emp_id = tdd.emp_id inner join mast_client mc on e.client_id = mc.mast_client_id inner join $tab_days t5  on tdd.emp_id = t5.emp_id and tdd.sal_month = t5.sal_month  inner join  $tab_emp t4 on t4.emp_id = tdd.emp_id  and t4.sal_month = tdd.sal_month where tdd.amount>0 and mc.parentId = '$clintid' AND tdd.sal_month = '$frdt' and  tdd.head_id in (select mast_deduct_heads_id from mast_deduct_heads where deduct_heads_name like '%P.F.%' and comp_id ='$comp_id') AND tdd.sal_month='$frdt'" ;

	
	
	}
else{

 $sql = "select e.client_id,tdd.head_id ,mc.client_name,tdd.amount as amount,tdd.std_amt as std_amt,tdd.employer_contri_1 as employer_contri_1,tdd.employer_contri_2 as employer_contri_2,e.uan,e.first_name,e.middle_name,e.last_name from tdd.amount>0 and  tran_deduct tdd inner join mast_deduct_heads md on tdd.head_id = md.mast_deduct_heads_id inner join employee e on e.emp_id = tdd.emp_id inner join mast_client mc on e.client_id = mc.mast_client_id where mc.client_id = '$clintid' AND tdd.sal_month = '$frdt'  and tdd.comp_id ='$comp_id'  AND tdd.head_id in (select mast_deduct_heads_id from mast_deduct_heads where deduct_heads_name like '%P.F.%' and comp_id ='$comp_id') and tdd.sal_month='$frdt'" ;


}

$row = $payrollAdmin->getPFUAN($emp,$comp_id,$frdt,$tab_empded,$tab_days,$tab_emp,$clintid);
foreach($row as $row1)
{   
$row2 = $payrollAdmin->getPFUAN1($row1['uan'],$row1['first_name'],$row1['middle_name'],$row1['last_name'],$row1['gross_salary'],$row1['std_amt'],$row1['amount'],$row1['employer_contri_2'],$row1['employer_contri_1'],$row1['absent']);
}


$setRec = $payrollAdmin->getAllFUAN();


$setCounter = sizeof($setRec);
$setMainHeader="";
$setData="";
for ($i = 0; $i < $setCounter; $i++) {
    //$setMainHeader .= mysql_field_name($setRec, $i)."\t";
    $setMainHeader .= $setRec."\t";
}
foreach($setRec as $rec)
{
    $rowLine = '';
    foreach($rec as $value)       {
        if(!isset($value) || $value == "")  {
            $value = "\t";
        }   else  {
//It escape all the special charactor, quotes from the data.
            $value = strip_tags(str_replace('"', '""', $value));
            //$value =  $value . "#~#";
			     $value = '"' . $value . '"' . "\t";
        }
        $rowLine .= $value;
    }
    $setData .= trim($rowLine)."\n";
}
$setData = str_replace("\r", "", $setData);

if ($setData == "") {
    $setData = "\nno matching records found\n";
}







//This Header is used to make data download instead of display the data
header("Content-type: application/octet-stream");

header("Content-Disposition: attachment; filename=".$setExcelName.".xls");

header("Pragma: no-cache");
header("Expires: 0");

//It will print all the Table row as Excel file row with selected column name as header.
echo ucwords($setMainHeader)."\n".$setData."\n";
?>







