<?php
include ('../../include_payroll_admin.php');

//error_reporting(0);
$month=$_SESSION['month'];
$clientid=$_SESSION['clientid'];
$emp=$_REQUEST['emp'];
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];

//$res=$payrollAdmin->showEmployeereport($comp_id,$user_id);

$resclt=$payrollAdmin->displayClient($clientid);
$cmonth=$resclt['current_month'];

if($month=='current'){
	$monthtit =  date('F Y',strtotime($cmonth));
    $tab_emp='tran_employee';
    $tab_empded='tran_deduct';
	$tab_days = 'tran_days';
    $frdt=$cmonth;
    $todt=$cmonth;
  }
else{
    $monthtit =  date('F Y',strtotime($_SESSION['frdt']));
    $tab_emp='hist_employee';
    $tab_empded='hist_deduct';
	$tab_days = 'hist_days';
	$frdt=date("Y-m-d", strtotime($_SESSION['frdt']));
    $todt=date("Y-m-d", strtotime($_SESSION['frdt']));
	
/*	$sql = "SELECT LAST_DAY('".$frdt."') AS last_day";
	$row= mysql_query($sql);
	$res = mysql_fetch_assoc($row);
	$frdt = $res['last_day'];
*/	
	$frdt=$payrollAdmin->lastDay($frdt);
  }
 
/*if($emp=='Parent')
	{
	 $sql = "SELECT t1.*,t2.first_name,t2.middle_name,t2.last_name,t2.uan,t4.pfno,t5.absent,t4.client_id FROM $tab_empded t1 inner join $tab_days t5 on t5.emp_id = t1.emp_id and t5.sal_month = t1.sal_month inner join employee t2  on  t1.emp_id=t2.emp_id  inner join  $tab_emp t4 on t4.emp_id = t1.emp_id  and t4.sal_month= t1.sal_month  inner join mast_client t3 on t4.client_id= t3.mast_client_id  where  t3.parentid='".$clientid."' AND  t1.head_id  in (select  mast_deduct_heads_id from mast_deduct_heads  where  deduct_heads_name like '%P.F.%'  and mast_deduct_heads.comp_id ='".$comp_id."')  ";
	}
else{
 	$sql = "SELECT t1.*,t2.first_name,t2.middle_name,t2.last_name,t2.uan,t4.pfno,t5.absent,t4.client_id FROM $tab_empded t1  inner join $tab_days t5 on t5.emp_id = t1.emp_id and t5.sal_month = t1.sal_month  inner join employee t2  on  t1.emp_id=t2.emp_id  inner join  $tab_emp t4 on t4.emp_id = t1.emp_id  and t4.sal_month = t1.sal_month where  t4.client_id='".$clientid."' AND  t1.head_id  in (select  mast_deduct_heads_id from mast_deduct_heads  where  deduct_heads_name like '%P.F.%'  and mast_deduct_heads.comp_id ='".$comp_id."')  ";

}

 $sql .= " AND t1.sal_month='".$frdt."' ";


 $sql .="order by t4.emp_id,t2.first_name,t2.middle_name,t2.last_name";
$res12 = mysql_query($sql);
$tcount= mysql_num_rows($res12);*/

$res12=$payrollAdmin->getPFstatement($emp,$tab_empded,$tab_days,$tab_emp,$clientid,$comp_id,$frdt);
$tcount= sizeof($res12);

if($month!=''){
    $reporttitle="PF Statement FOR THE MONTH ".$monthtit;
}
$p='';
if($emp=='Parent'){
    $p="(P)";
}
$_SESSION['client_name']=$resclt['client_name'].$p;
$_SESSION['reporttitle']=strtoupper($reporttitle);

?>

<!DOCTYPE html>

<html lang="en-US">
<head>

    <meta charset="utf-8"/>


    <title> &nbsp;</title>

    <!-- Included CSS Files -->
    <link rel="stylesheet" href="../css/responsive.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .thheading{
            text-transform: uppercase;
            font-weight: bold;
            background-color: #fff;
        }
        .heading{
            margin: 10px 20px;
        }
        .btnprnt{
            margin: 10px 20px;
        }
        .page-bk {
            position: relative;

            /*display: block;*/
            page-break-after: always;
            z-index: 0;

        }


        table {
            border-collapse: collapse;
            width: 100%;

        }

        table, td, th {
            padding: 5px!important;
            border: 1px dotted black!important;
            font-size:12px !important;
            font-family: monospace;

        }
        @media print
        {
            .btnprnt{display:none}
            .header_bg{
                background-color:#7D1A15;
                border-radius:0px;
            }
            .heade{
                color: #fff!important;
            }
            #header, #footer {
                display:none!important;
            }
            #footer {
                display:none!important;
            }
            .body { padding: 10px; }
            body{
                margin-left: 50px;
            }
        }

        @media all {
            #watermark {
                display: none;

                float: right;
            }

            .pagebreak {
                display: none;
            }

            #header, #footer {

                display:none!important;

            }
            #footer {
                display:none!important;
            }

        }


    </style>
</head>
<body>
<div class="btnprnt">
    <button class="submitbtn" onclick="myFunction()">Print</button>
    <button class="submitbtn"  onclick="history.go(-1);" >Cancel</button>
</div>
<!-- header starts -->


<!-- header end -->

<!-- content starts -->




<div>
<div class="header_bg">
<?php
include('printheader3.php');
?>
</div>


    <div class="row body" >







        <table width="100%">

		<?php
			
		/*	$sql2 = "select * from pf_charges where '".$frdt."' >=from_date and '".$frdt."' <= to_date";
			$res13 = mysql_query($sql2);
			$res14 = mysql_fetch_array($res13);*/
			
			$res14=$payrollAdmin->getCharges($frdt);
?>
	





    <tr>
        <th class="thheading" width="4%">Clnt No </th>
        <th class="thheading" width="4%">EmpID  </th>
        <th class="thheading" width="5%">PF No  </th>
		<th class="thheading" width="7%">UAN No </th>
        <th class="thheading" width="7%" colspan = '3'>Name Of the Employee </th>
        <th class="thheading" width="7%">P.F. Wages</th>
        <th class="thheading" width="7%">Employee's P.F.<?php echo number_format($res14['acno1_employee'],2,".",","); ?> %</th>
        <th class="thheading" width="7%">Employer's P.F. <?php echo number_format($res14['acno1_employer'],2,".",","); ?>%</th>
        <th class="thheading" width="7%">Pension <?php echo number_format($res14['acno10'],2,".",","); ?>% </th>
		<th class="thheading" width="7%">Total 24%</th>
        
        <th class="thheading" width="7%">PFAdmin <?php echo number_format(trim($res14['acno2']),2,".",","); ?>% </th>
        <th class="thheading" width="7%">DLIS <?php echo number_format(trim($res14['acno21']),2,".",","); ?>% </th>
        <th class="thheading" width="7%">DLISAdmin <?php echo number_format($res14['acno22'],2,".",","); ?>% </th>

        <th class="thheading" width="7%">Total</th>
        <th class="thheading" width="7%">NCP Days</th>
    </tr>

<?php
$totalamt=0;
$totalco1=0;
$ttotalco1=0;
$totalco833 =0;

$ttotalco2=0;
$totalco2=0;
$totalstdam=0;
$tabsent = 0;
$totac2=0;
$totac21=0;
$totac22=0;
$c[]='';
$i=0;
foreach($res12 as $row){
    $total1=0;

    ?>
    <tr>
        <td align="center" >           <?php  echo $row["client_id"];?>        </td>
        <td align="center" >           <?php  echo $row["emp_id"];?>        </td>
        <td align="center" >           <?php  echo $row["pfno"];?>        </td>
        <td align="center" >           <?php  echo $row["uan"];?>        </td>
        <td colspan="3"> <?php echo $row["first_name"]." ".$row["middle_name"]." ".$row["last_name"];?></td>
        <td align="center" >  <?php echo NUMBER_FORMAT($row['std_amt'],0," ",",");
									$totalstdam=$totalstdam+$row['std_amt'];
									$c[$i]=$row['amount'];
								?>  </td>       
		<td align="center" > <?php  echo NUMBER_FORMAT($row['amount'],0," ",",");
									$totalamt=$totalamt+$row['amount'];
									$c[$i]=$row['amount'];
									$total1=$row['amount'];
								?> </td>
        <td align="center" > <?php  echo NUMBER_FORMAT($row['employer_contri_1'],0," ",",");
									$totalco1=$totalco1+$row['employer_contri_1'];
								?>  </td>

        <td align="center" > <?php echo NUMBER_FORMAT($row['employer_contri_2'],0," ",",");
								   $totalco833=$totalco833+$row['employer_contri_2'];
								?> </td>

        <td align="center" > <?php echo NUMBER_FORMAT($row['employer_contri_2']+$row['employer_contri_1']+$row['amount'],0," ",",");
									$ttotalco2=$ttotalco2+$row['employer_contri_2']+$row['employer_contri_1']+$row['amount'];
								?> </td>
								
        <td align="center" > <?php $ac2=round($row['std_amt']*$res14['acno2']/100,0);
									echo NUMBER_FORMAT($ac2,0," ",",");
									$totac2 = $totac2+$ac2;
								?> </td>
								
        <td align="center" > <?php $ac21=round($row['std_amt']*$res14['acno21']/100,0);
									echo NUMBER_FORMAT($ac21,0," ",",");
									$totac21 = $totac21+$ac21;
								?> </td>
        <td align="center" > <?php $ac22=round($row['std_amt']*$res14['acno22']/100,0);
									echo NUMBER_FORMAT($ac22,0," ",",");
									$totac22 = $totac22+$ac22;
								?> </td>
		<td align="center" > <?php 
									echo NUMBER_FORMAT($row['employer_contri_2']+$row['employer_contri_1']+$row['amount']+$ac2+$ac21+$ac22,0," ",",");
							 ?> </td>
								
        <td align="center" > <?php  echo NUMBER_FORMAT($row['absent'],0," ",",");
									$tabsent=$tabsent+$row['absent'];
								?>  </td>


    </tr>
            <?php
    $i++;

}


$s=array_count_values($c);

?>

            <tr>
                

                <td class="thheading" colspan = 7 >  Total  </td>
                <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($totalstdam,0," ",","); ?> </td>
                <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($totalamt,0," ",","); ?> </td>
                <td class="thheading"align="center"  ><?php echo NUMBER_FORMAT($totalco1,0," ",","); ?> </td>
                <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($totalco833,0," ",","); ?> </td>
                 <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($ttotalco2,0," ",","); ?> </td>
                 <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($totac2,0," ",","); ?> </td>
                 <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($totac2,0," ",","); ?> </td>
                 <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($totac22,0," ",","); ?> </td>
				 
                 <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($totalamt+$totalco1+$totalco833+$totac2+$totac21+$totac22,0," ",","); ?> </td>
                 <td class="thheading" align="center" ><?php echo NUMBER_FORMAT($tabsent,0," ",","); ?> </td>
				 
				 
            </tr>
			
			<tr>
			<td   class="thheading" colspan="17" >No. of Employees :<?php echo $tcount; ?></td>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
</tr>
			
            <!--<tr>
                <td colspan="12"  class="thheading">Pf Admin Charges (<?php //echo "  ". $res14['acno2']?>%)</td>
                <td class="thheading" align="center" ><?php //echo $ac=round($totalstdam*$res14['acno2']/100,0); ?></td>
            </tr>
            <tr>
                <td class="thheading" colspan="12">D.L.I.S. Contribution (<?php //echo $res14['acno21']?>%)</td>
                <td class="thheading" align="center" ><?php //echo $dlisc=round($totalstdam*$res14['acno21']/100,0); ?></td>
            </tr>
            <tr>
                <td class="thheading" colspan="12">D.L.I.S. Admin Charges (<?php //echo $res14['acno22']?>%)</td>
                <td class="thheading" align="center" ><?php //echo $dlisac=round($totalstdam*$res14['acno22']/100,0); ?>
            </tr> <tr>
                <td class="thheading" colspan="12"></td>
                <td class="thheading" align="center" ><?php //echo NUMBER_FORMAT( round($totalamt+$totalco1+$totalco2+$dlisac+$dlisc+$ac,2),0,".",","); ?>
            </tr>-->

</table>

        </div>
<br/><br/>
    </div>

<!-- content end -->

<script>
    function myFunction() {
        window.print();
    }
</script>


</body>
</html>