<?php
include ('../../include_payroll_admin.php');

error_reporting(0);
$month=$_SESSION['month'];
$clientid=$_SESSION['clientid'];
//$emp=$_REQUEST['emp'];
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];

//$res=$payrollAdmin->showEmployeereport($comp_id,$user_id);

$resclt=$payrollAdmin->displayClient($clientid);
$mon = $_REQUEST['mon'];
$frdt = $_REQUEST['frdt'];
 $todt = $_REQUEST['todt'];
if($mon =='current'){
 $cmonth=$resclt['current_month'];
 $frdt =$resclt['current_month'];
}

if($month=='current'){
    $monthtit =  date('F Y',strtotime($cmonth));
    //$tab_days='tran_days';
    $tab_emp='tran_employee';
    //$tab_empinc='tran_income';
    $tab_empded='tran_deduct';
	 $cmonth=$resclt['current_month'];
 $frdt =$resclt['current_month'];
 }
else{
    $monthtit =  date('F Y',strtotime($_SESSION['frdt']));
    //$tab_days='hist_days';
    $tab_emp='hist_employee';
    //$tab_empinc='hist_income';
    $tab_empded='hist_deduct';
	//$tab_adv='hist_advance';

    //$frdt=date("Y-m-d", strtotime($_SESSION['frdt']));
    //$todt=date("Y-m-d", strtotime($_SESSION['frdt']));
	
	//$sql = "SELECT LAST_DAY('".$frdt."') AS last_day";
	//$row= mysql_query($sql);
	//$res = mysql_fetch_assoc($row);
	//$frdt = $res['last_day'];
	
 }
 ?>
 <!DOCTYPE html>

<html lang="en-US">
<head>

    <meta charset="utf-8"/>


    <title> &nbsp;</title>

    <style>
        .thheading{
            text-transform: uppercase;
            font-weight: bold;
            background-color: #fff;
        }
    
		.tdtext{
            text-transform: uppercase;
			 align-content: center;
        }
    

		.heading{
            margin: 10px 20px;
        }
        .btnprnt{
            margin: 10px 20px;
        }
        .page-bk {
            position: relative;

            /*display: block;*/
            page-break-after: always;
            z-index: 0;

        }


        table {
            border-collapse: collapse;
            width: 100%;

        }

        table, td, th {
            padding: 5px!important;
            border: 1px dotted black!important;
            font-size:14px !important;
            font-family: monospace;

        }
        @media print
        {
            .btnprnt{display:none}
            .header_bg{
                background-color:#7D1A15;
                border-radius:0px;
            }
            .heade{
                color: #fff!important;
            }
            #header, #footer {
                display:none!important;
            }
            #footer {
                display:none!important;
            }
            .body { padding: 10px; }
            body{
                margin-left: 50px;
            }
        }

        @media all {
            #watermark {
                display: none;

                float: right;
            }

            .pagebreak {
                display: none;
            }

            #header, #footer {

                display:none!important;

            }
            #footer {
                display:none!important;
            }

        }


    </style>
</head>
<body>
<div class="btnprnt">
    <button class="submitbtn" onclick="myFunction()">Print</button>
    <button class="submitbtn"  onclick="history.go(-1);" >Cancel</button>
</div>

<div>
</div>
 

<?php 
 
$frdt = date('Y-m-d',strtotime($frdt));
$todt = date('Y-m-d',strtotime($todt));



$res = $payrollAdmin->getCountESICode($comp_id);

$grwages=0;
$grEE=0;
$grER=0;
$grEMP= 0;
$totwages=0;
$totEE=0;
$totER=0;
$totEMP= 0;


if($month!=''){
    $reporttitle="ESI Summery Statement FOR THE MONTH ".$monthtit;
}
$_SESSION['reporttitle']=strtoupper($reporttitle);
?>
<div class="header_bg">
<?php
include('printheader.php');
?>
</div>
<?php
foreach($res as $esicode1)
{  
    $totwages=0;
    $totEE=0;
    $totER=0;
    $totEMP= 0;
    
$resesiclient=$payrollAdmin->getESICode1($comp_id,$tab_empded,$tab_emp,$frdt);

$num_rows = sizeof($resesiclient);



if ($num_rows> 0) 
{?>


   <div class="row body" >

<div >
<?php
//include('printheader.php');
//echo "<br>";
echo "ESI CODE : ".$esicode1['esicode'];
//echo "<br>";
?>
</div>

    <table width='100%'>

    <tr>
        <th class='thheading' width='5%'>Client NO </th>
        <th class='thheading' width='25%'>Client Name </th>
        <th class='thheading' width='10%'>Total Rs. </th>
        <th class='thheading' width='10%'>Employee</th>
        <th class='thheading' width='10%'>Employer</th>
        <th class='thheading' width='15%'>Total</th>
        <th class='thheading' width='10%'>No. Of Employee</th>
        
    </tr>

<?php 
foreach($resesiclient as $client)
{ 


?>

    <tr>   <td ><?php echo $client['client_id'];?> </td>
        <td ><?php echo $client['client_name'];?>  </td>
        <td ><?php echo $client['std_amt'];?>  </td>
        <td ><?php echo $client['amount'];?> </td>
        <td ><?php echo $client['employer'];?> </td>
        <td > <?php echo number_format($client['amount']+$client['employer'],2,".",",");?></td>
        <td ><?php echo $client['cnt'];?> </td>
    </tr> 




<? 

$grwages=$grwages+ $client['std_amt'];
$grEE=$grEE+$client['amount'];
$grER=$grER+$client['employer'];
$grEMP= $geEmp+$client['cnt'];
$totwages=$totwages+$client['std_amt'];
$totEE=$totEE+$client['amount'];
$totER=$totER+$client['employer'];
$totEMP= $totEMP+$client['cnt'];


} 
?>
    <tr>   <td > </td>
        <td >Total  </td>
        <td  ><?php  echo number_format($totwages,2,".",",");?>  </td>
        <td ><?php  echo number_format($totEE,2,".",",");?> </td>
        <td ><?php  echo number_format($totER,2,".",",");?> </td>
        <td > <?php echo number_format(round($totEE+$totER,0),2,".",",");?></td>
        <td ><?php  echo $totEMP;?> </td>
    </tr>
    </table>
    <br></div>
<?php
}
}
?>
        
     <div class="row body" >
      <table width='100%'>

    <tr>
        <th class='thheading' width='5%'>Client NO </th>
        <th class='thheading' width='25%'>Client Name </th>
        <th class='thheading' width='10%'>Total Rs. </th>
        <th class='thheading' width='10%'>Employee</th>
        <th class='thheading' width='10%'>Employer</th>
        <th class='thheading' width='15%'>Total</th>
        <th class='thheading' width='10%'>No. Of Employee</th>
         
    </tr>

     <tr>      <td > </td>
        <td >Grand Total  </td>
        <td ><?php  echo number_format($grwages,2,".",",");?>  </td>
        <td ><?php  echo number_format($grEE,2,".",",");?> </td>
        <td ><?php  echo number_format($grER,2,".",",");?> </td>
        <td > <?php echo number_format(round($grEE+$grER,0),2,".",",");?></td>
        <td ><?php  echo $totEMP;?> </td>
    </tr> 

</table>
        </div>
<br/>
    </div>
<!-- content end -->
<script>
    function myFunction() {
        window.print();
    }
</script>
</body>
</html>