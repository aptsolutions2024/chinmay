<?php
include ('../../include_payroll_admin.php');

error_reporting(0);
$month=$_SESSION['month'];
$clientid=$_SESSION['clientid'];
//$emp=$_REQUEST['emp'];
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];

//$res=$payrollAdmin->showEmployeereport($comp_id,$user_id);

$resclt=$payrollAdmin->displayClient($clientid);
$mon = $_REQUEST['mon'];
$frdt = $_REQUEST['frdt'];
$todt = $_REQUEST['todt'];
if($mon =='current'){
 $cmonth=$resclt['current_month'];
 $frdt =$resclt['current_month'];
 
 //$tab_days='tran_days';
    $tab_emp='tran_employee';
    //$tab_empinc='tran_income';
    $tab_empded='tran_deduct';
	//$tab_adv='tran_advance';
}else{
    $monthtit =  date('F Y',strtotime($frdt));
    //$tab_days='hist_days';
    $tab_emp='hist_employee';
    //$tab_empinc='hist_income';
    $tab_empded='hist_deduct';
	//$tab_adv='hist_advance';

	
 }
$frdt = date('Y-m-d',strtotime($frdt));
$todt = date('Y-m-d',strtotime($todt));

$res=$payrollAdmin->getESICode2($tab_emp,$frdt,$tab_empded,$comp_id);

if($month!=''){
    $reporttitle="Without ESI Summery Statement FOR THE MONTH ".$monthtit;
}
$p='';
if($emp=='Parent'){
    $p="(P)";
}
$_SESSION['client_name']=$resclt['client_name'].$p;
$_SESSION['reporttitle']=strtoupper($reporttitle);

?>

<!DOCTYPE html>

<html lang="en-US">
<head>

    <meta charset="utf-8"/>


    <title> &nbsp;</title>

    <!-- Included CSS Files -->
    <link rel="stylesheet" href="../css/responsive.css">
    <link rel="stylesheet" href="../css/style.css">
    <style>
        .thheading{
            text-transform: uppercase;
            font-weight: bold;
            background-color: #fff;
        }
    
		.tdtext{
            text-transform: uppercase;
			 align-content: center;
        }
    

		.heading{
            margin: 10px 20px;
        }
        .btnprnt{
            margin: 10px 20px;
        }
        .page-bk {
            position: relative;

            /*display: block;*/
            page-break-after: always;
            z-index: 0;

        }


        table {
            border-collapse: collapse;
            width: 100%;

        }

        table, td, th {
            padding: 5px!important;
            border: 1px dotted black!important;
            font-size:12px !important;
            font-family: monospace;

        }
        @media print
        {
            .btnprnt{display:none}
            .header_bg{
                background-color:#7D1A15;
                border-radius:0px;
            }
            .heade{
                color: #fff!important;
            }
            #header, #footer {
                display:none!important;
            }
            #footer {
                display:none!important;
            }
            .body { padding: 10px; }
            body{
                margin-left: 50px;
            }
        }

        @media all {
            #watermark {
                display: none;

                float: right;
            }

            .pagebreak {
                display: none;
            }

            #header, #footer {

                display:none!important;

            }
            #footer {
                display:none!important;
            }

        }


    </style>
</head>
<body>
<div class="btnprnt">
    <button class="submitbtn" onclick="myFunction()">Print</button>
    <button class="submitbtn"  onclick="history.go(-1);" >Cancel</button>
</div>

<div>
<div class="header_bg">
<?php
include('printheader.php');
?>
</div>
 
    <div class="row body" >

<table width='90%'>

 <tr>	<th class='thheading' width='7%'>Sr. No.</th>
        <th class='thheading' width='5%'>Salary Month</th>
        <th class='thheading' width='5%'>Client Id </th>
        <th class='thheading' width='7%'>Emp Id </th>
        <th class='thheading' width='25%'>Name of The Employee</th>
        <th class='thheading' width='5%'>Gross Salary</th>
		 <th class='thheading' width='18%'>Client</th>
		
        
    </tr>

<?php 
	$sr=1;
	$total=sizeof($client);
	if($total!=0){
foreach($res as $client){
  ?>
 <tr><td><?php echo $sr;?></td>
        <td ><?php echo date('M Y',strtotime($client['sal_month']));?> </td>
        <td ><?php echo $client['mast_client_id'];?>  </td>
        <td ><?php echo $client['emp_id'];?>  </td>
        <td ><?php echo $client['first_name']." ".$client['middle_name']." ".$client['last_name'];?> </td>
        <td ><?php echo $client['gross_salary'];?> </td>
        <td ><?php echo $client['client_name'];?> </td>
    </tr>
	<?php $sr++;}}else{ ?> 
	<tr><td colspan="7" align="center">No record found.</td></tr>
	<?php } ?>
</table>

        </div>
<br/><br/>
    </div>
<!-- content end -->
<script>
    function myFunction() {
        window.print();
    }
</script>
</body>
</html>