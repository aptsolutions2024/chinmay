<?php
include ('../../include_payroll_admin.php');

$setCounter = 0;
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$setExcelName = "esi_export";
$clintid=$_SESSION['clintid'];
$month=$_SESSION['month'];



if($month=='current'){
    $tab_emp='tran_employee';
    $tab_empded='tran_deduct';
    
	$resclt=$payrollAdmin->displayClient($clintid);
$cmonth=$resclt['current_month'];
    $frdt=$cmonth;
 }
else{
    $tab_emp='hist_employee';
    $tab_empded='hist_deduct';
	$frdt=date("Y-m-d", strtotime($_SESSION['frdt']));
 }

$srno = 1;

$setRec=$payrollAdmin->ESIStatement($tab_empded,$tab_emp,$comp_id,$frdt);

$setCounter = sizeof($setRec);
$setMainHeader="";
$setData="";
$setMainHeader="ESICode\t S.no\t ESINO \t Nanme \t Days \t Wages \t EE Con \t ER Con \t Total\n";

foreach($setRec as $rec)
 {
    $rowLine = '';
    foreach($rec as $value)       {
        if(!isset($value) || $value == "")  {
            $value = "\t";
        }   else  {
//It escape all the special charactor, quotes from the data.
            $value = strip_tags(str_replace('"', '""', $value));
            $value = '"' . $value . '"' . "\t";
        }
        $rowLine .= $value;
    }
    $setData .= trim($rowLine)."\n";
}
$setData = str_replace("\r", "", $setData);

if ($setData == "") {
    $setData = "\nno matching records found\n";
}

//This Header is used to make data download instead of display the data


header("Content-type: application/octet-stream");
header("Content-Disposition: attachment; filename=".$setExcelName.".xls");
header("Pragma: no-cache");
header("Expires: 0");

//It will print all the Table row as Excel file row with selected column name as header.
echo ucwords($setMainHeader)."\n".$setData."\n";
?>







