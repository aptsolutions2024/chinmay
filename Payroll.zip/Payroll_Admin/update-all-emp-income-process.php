<?php
include ('../include_payroll_admin.php');

$payrollAdmin = new payrollAdmin();

if($_SESSION['log_type']==2)
{
    
}else
{
    echo "<script>window.location.href='/payroll-logout';</script>";exit();
}
$emp_ic_id=$_REQUEST['emp_ic_id'];
$texta=$_REQUEST['texta'];

$textc=$_REQUEST['textc'];
$caltype=$_REQUEST['caltype'];
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
 $rows=$payrollAdmin->updateAllempincome($emp_ic_id,$texta,$caltype,$textc,$comp_id,$user_id);
echo "<script>window.location.href='/edit-all-employee';</script>";exit();
?>

