<?php
include ('../include_payroll_admin.php');

$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$clientid=$_REQUEST['clientid']; 
$filename=$_FILES["file"]["tmp_name"];


$res1=$payrollAdmin->getEmpHeads($comp_id);

$headid = array();
foreach($res1 as $row111)
{
	$headid[] = $row111['mast_deduct_heads_id'];
}
 $pfid = $headid[0];
 $esiid = $headid[1];
 $proftaxid = $headid[2];
 $lwfid = $headid[3];
	if($_FILES["file"]["size"] > 0)
	{
       $count=0;  
		$file = fopen($filename, "r");
	    while ($emapData = fgetcsv($file, 10000, ","))
	    {
			if($count!=0){
				$dept = addslashes($emapData[12]);
             
         		 	   $dept_id=$payrollAdmin->getDeptId($dept,$comp_id);
//0   	           1       	   2       	  3	     4	          5         	6	        7	      8	     9      	10  	 11      	12      	13	          14	        15	     16  	     17	            18	        19       20         21      22              23                24
//first_name	Middle Name	Last Name	gender	bdate	    joindate	due_date	leftdate	Pfdate 	pfno	ESI Status	esino	Department	Qualification	mobile_no	pay_mode	bank	    bankacno	comp_ticket_no	panno	adharno     uan	 married_status	 emp_add1	        designation
//First Name	Middle Name	Last Name	Gender	Birth Date	Join Date	Due Date	Left Date	PF Date	PF No	ESI Status	ESI No	Department	Qualification	Phone No	Pay Mode	Bank Name	Bank Ac No	Comp Ticket No	PAN No	Adhar No	UAN	 Married Status	 Employee Address	Designation


 				$desg = addslashes($emapData[24]);
			   $qualif = addslashes($emapData[13]);
		      //echo "   <br>***Qualif ";
		      
            $qualif_id=$payrollAdmin->getQualifId($qualif,$comp_id);
            $desg_id=$payrollAdmin->getDesgIdNew($desg,$comp_id);
				 
				
	 
				 
				 $bank = addslashes($emapData[16]); 
				  //echo "    bank - ";
				  $bank_id=$payrollAdmin->getBankId($bank,$comp_id);
				  //echo "<pre>";print_r($emapData);
				   //echo "hello".$emapData[4]."hello"; 
				   if($emapData[4]!="" && $emapData[4]!=" "){
					 $empdata4 = date('Y-m-d', strtotime(str_replace('/', '-', $emapData[4])));
				   }else{
					   $empdata4 = "0000-00-00";
				   }
				   if($emapData[5]!="" && $emapData[5]!=" "){
					 $empdata5 = date('Y-m-d', strtotime(str_replace('/', '-', $emapData[5])));
				   }else{
					   $empdata5 = "";
				   }
				   if($emapData[6]!="" && $emapData[6]!=" "){
					 $empdata6 = date('Y-m-d', strtotime(str_replace('/', '-', $emapData[6])));
				   }else{
					   $empdata6 = "0000-00-00";
				   }
				   if($emapData[7]!="" && $emapData[7]!=" "){
					 $empdata7 = date('Y-m-d', strtotime(str_replace('/', '-', $emapData[7])));
				   }else{
					   $empdata7 = "0000-00-00";
				   }
				   if($emapData[8]!="" && $emapData[8]!=" "){
					 $empdata8 = date('Y-m-d', strtotime(str_replace('/', '-', $emapData[8])));
				   }else{
					   $empdata8 = "0000-00-00";
				   }
				 
       
if($emapData[1] !="" && $emapData[1] !=" "){
//echo $desg_id;die;
	$empid=$payrollAdmin->insertCSVWiseEmployee($comp_id,$user_id,addslashes($emapData[0]),addslashes($emapData[1]),addslashes($emapData[2]),addslashes($emapData[3]),$empdata4,$empdata5,$empdata6,$empdata7,$empdata8,addslashes($emapData[9]),addslashes($emapData[11]),$dept_id,$qualif_id,addslashes($emapData[14]),addslashes($emapData[15]),$bank_id,addslashes($emapData[17]),addslashes($emapData[18]),addslashes($emapData[19]),addslashes($emapData[20]),addslashes($emapData[21]),addslashes($emapData[22]),addslashes($emapData[23]),$desg_id ,$clientid);
	
$respf=$payrollAdmin->insertCSVWiseDeduct($comp_id,$empid,$user_id,$pfid,$esiid,$proftaxid,$lwfid);

}





			}
			$count++;
	    } 

		
	    fclose($file);
		
		
}	
//redirect('/import-emp');
header("Location: import-emp");
die();
?>
