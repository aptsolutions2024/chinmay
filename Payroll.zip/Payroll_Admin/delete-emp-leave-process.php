<?php
session_start();
error_reporting(0);
include_once('../../source/lib/class/payroll_admin.php');
$payrollAdmin = new payrollAdmin();
  $id = addslashes($_REQUEST['id']);
  $result = $payrollAdmin->deleteEmpleave($id);
?>

