r<?php
include ('../include_payroll_admin.php');

$incomeid=addslashes($_REQUEST['incomeid']);
$ct=addslashes($_REQUEST['caltype']);
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$filename=$_FILES["file"]["tmp_name"];
//$income = $_REQUEST['incomeid'];
	if($_FILES["file"]["size"] > 0)
	{
       $count=0;  
		$file = fopen($filename, "r");
	    while ($emapData = fgetcsv($file, 10000, ","))
			
	    {
			
			//print_r($emapData);
			      
			if($count!=0){
			 	$countch=$payrollAdmin->countEmpIncome(addslashes($emapData[0]),$incomeid);
			    
				$result=$payrollAdmin->updateEmpIncome(addslashes($emapData[4]),$ct,addslashes($emapData[5]),addslashes($emapData[0]),$incomeid,$comp_id,$user_id,$countch);
			}
			$count++;
	    }


	    fclose($file);

		if($count>1)
		{
			echo "<script type=\"text/javascript\">
					alert(\"CSV File has been successfully Imported.\");
				</script>";
    echo "<script>window.location.href='/import-income';</script>";exit();
			
		}
		
	}	
?>
