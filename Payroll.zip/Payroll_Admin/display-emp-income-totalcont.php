<?php
include ('../include_payroll_admin.php');

$payrollAdmin = new payrollAdmin();

if($_SESSION['log_type']==2)
{
    
}else
{
    echo "<script>window.location.href='/payroll-logout';</script>";exit();
}

$id = $_REQUEST['id'];

$row = $payrollAdmin->getEmpIncome($id);
echo $row['total'];
?>