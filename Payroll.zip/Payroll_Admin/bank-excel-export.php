<?php

include ('../include_payroll_admin.php');

$payrollAdmin = new payrollAdmin();

if($_SESSION['log_type']==2)
{
    
}else
{
    echo "<script>window.location.href='/payroll-logout';</script>";exit();
}


$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$month=$_SESSION['month'];
$setExcelName = "employee_detail";
$client_id = $_SESSION['clientid'];

//$pay_type =$_REQUEST['pay_type'];

$setExcelName = "bank-excel_".$client_id;
$resclt=$payrollAdmin->displayClient($client_id);

if ($comp_id ==1)
	{$comp = "Khalipe Hopes PVt. LTd.";
     }
else 
	{$comp = "Hopes Consultancy Services";
     }



$cmonth=$resclt['current_month'];
if($month=='current'){
    $monthtit =  date('F Y',strtotime($cmonth));
    $tab_emp='tran_employee';
    $frdt=$cmonth;
 }
else{
    $tab_emp='hist_employee';
	$monthtit =  date('F Y',strtotime($_SESSION['frdt']));
    $frdt=date("Y-m-d", strtotime($_SESSION['frdt']));
	$frdt=$payrollAdmin->lastDay($frdt);
 }
$rowcomp=$payrollAdmin->displayCompany($comp_id);
$debitacno = $rowcomp['bankacno'];
$desc= "Salary for ".$monthtit;
 $row=$payrollAdmin->bank_excel($client_id,$frdt,$tab_emp);
// $setMainHeader= "Debit Ac No ". "\t"."	Beneficiary Ac No	 ". "\t"."	Beneficiary Name	 ". "\t"."	Amt	 ". "\t"."	Pay Mod	 ". "\t"."	Date	 ". "\t"."	IFSC	 ". "\t"."	Payable Location ". "\t"."		Print Location ". "\t"."		Bene Mobile No.	 ". "\t"."	Bene Email ID	 ". "\t"."	Bene add1	 ". "\t"."	Bene add2	 ". "\t"."	Bene add3	 ". "\t"."	Bene add4	 ". "\t"."	Add Details 1	 ". "\t"."	Add Details 2	 ". "\t"."	Add Details 3	 ". "\t"."	Add Details 4	 ". "\t"."	Add Details 5	 ". "\t"."	Remarks";
 $setMainHeader="Debit Ac No	Beneficiary Ac No	Beneficiary Name	Amt	Pay Mod	Date	IFSC	Payable Location	Print Location	Bene Mobile No.	Bene Email ID	Bene add1	Bene add2	Bene add3	Bene add4	Add Details 1	Add Details 2	Add Details 3	Add Details 4	Add Details 5	Remarks";
 $setData="";
 if (count($row)){
       foreach ($row as $rec ) {
            $setData.= $debitacno."\t".$rec['bankacno']."\t".$rec['empname']."\t".$rec['netsalary']."\t"."N"."\t".date('d/m/Y')."\t".$rec['ifsc_code']."\t\t\t\t\t\t\t\t\t\t\t\t\t\t".$desc."\t\n";
            $setData = str_replace("\r", "", $setData);

        }
    }
    else{
        $setData = "\nno matching records found\n";
    }



//This Header is used to make data download instead of display the data
header("Content-type: application/octet-stream");

header("Content-Disposition: attachment; filename=" . $setExcelName . ".xls");

header("Pragma: no-cache");
header("Expires: 0");

//It will print all the Table row as Excel file row with selected column name as header.
echo ucwords($setMainHeader) . "\n" . $setData . "\n";




?>

