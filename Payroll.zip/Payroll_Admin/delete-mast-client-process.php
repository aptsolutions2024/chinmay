<?php
session_start();
error_reporting(0);
include_once('../../source/lib/class/payroll_admin.php');
$payrollAdmin = new payrollAdmin();
  $cid = addslashes($_REQUEST['cid']);
  $result = $payrollAdmin->deleteClient($cid);
?>

