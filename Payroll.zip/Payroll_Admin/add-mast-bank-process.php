<?php
include ('../include_payroll_admin.php');

  $name = $_REQUEST['name'];
 $add = $_REQUEST['add'];
$branch = $_REQUEST['branch'];
$pincode = $_REQUEST['pincode'];
$city = $_REQUEST['city'];
$ifsccode = $_REQUEST['ifsccode'];
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];

$action = $_REQUEST['action'];
if($action=='Insert')
{
 echo $result = $payrollAdmin->insertBank($name,$add,$branch,$pincode,$city,$ifsccode,$comp_id,$user_id);
}else
{
  $bid = addslashes($_REQUEST['bid']);
  echo $result = $payrollAdmin->updateBank($bid,$name,$add,$branch,$pincode,$city,$ifsccode,$comp_id,$user_id);
}


	 ?>

