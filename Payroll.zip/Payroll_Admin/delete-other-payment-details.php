<?php
include ('../include_payroll_admin.php');

  $id = addslashes($_REQUEST['id']);
  $result = $payrollAdmin->deleteotherpaymentdetails($id);
?>

