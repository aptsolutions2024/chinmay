<?php
echo "Inside - Monthly Closing"; 

include ('../include_payroll_admin.php');
$comp_id=$_SESSION['comp_id'];

    /* $sql = "select current_month from mast_client where comp_id = '$comp_id'";
    $row= mysql_query($sql);
    $res = mysql_fetch_assoc($row);
    $cmonth = $res['current_month']; */

 
 
   
	$row=$payrollAdmin->insertHistEmp($comp_id);
	$row1=$payrollAdmin->insertHistDays($comp_id);
	$row2=$payrollAdmin->insertHistIncome($comp_id);
	$row3=$payrollAdmin->insertHistDeduct($comp_id);
	$row4=$payrollAdmin->insertHistAdvance($comp_id);
	$row5=$payrollAdmin->updateEmployeeMonthC($comp_id);


//die;
	//Deleting data from  tran files

	$row6=$payrollAdmin->deleteTranTables($comp_id,'tran_employee');
	$row7=$payrollAdmin->deleteTranTables($comp_id,'tran_deduct');
	$row8=$payrollAdmin->deleteTranTables($comp_id,'tran_income');
	$row9=$payrollAdmin->deleteTranTables($comp_id,'tran_advance');
	$row10=$payrollAdmin->deleteTranDays($comp_id);
	$row11=$payrollAdmin->UpdateMastClients($comp_id);


?>