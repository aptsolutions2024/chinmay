<?php
session_start();
error_reporting(E_ALL);
include_once('../../source/lib/class/payroll_admin.php');
$payrollAdmin = new payrollAdmin();
  $did = $_REQUEST['did'];
  echo $result = $payrollAdmin->deleteDepartment($did);
?>

