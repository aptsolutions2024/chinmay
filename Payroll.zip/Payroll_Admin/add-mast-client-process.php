<?php
session_start();
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
include ('../include_payroll_admin.php');

error_reporting(0);
//include_once('../../source/lib/class/payroll_admin.php');
$payrollAdmin = new payrollAdmin();
$name = addslashes(strtoupper($_REQUEST['name']));
 $add1 = addslashes($_REQUEST['add1']);
$esicode = addslashes($_REQUEST['esicode']);
$pfcode = addslashes($_REQUEST['pfcode']);
$tanno = addslashes($_REQUEST['tanno']);
$panno = addslashes($_REQUEST['panno']);
$gstno = addslashes($_REQUEST['gstno']);
$sc = addslashes($_REQUEST['sc']);
$email= $_REQUEST['email'];
$mont=date("Y-m-d", strtotime($_REQUEST['cm']));
//$parent=addslashes($_REQUEST['parent']);
$parent_comp=$_REQUEST['parent_comp'];
if($parent_comp=='Y'){
$parent=0;
}else{
$parent = addslashes($_REQUEST['parent']);
}
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$result = $payrollAdmin->insertClient($name,$add1,$esicode,$pfcode,$tanno,$panno,$gstno,$mont,$parent,$comp_id,$user_id,$sc,$email,$parent_comp);

?>

