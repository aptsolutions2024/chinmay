<?php
session_start();
include ('../include_payroll_admin.php');

$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$result1 = $payrollAdmin->showClient1($comp_id,$user_id);

$result = $payrollAdmin->showClient1($comp_id,$user_id);
$total_results = sizeof($result);


?>
<!DOCTYPE html>

<head>

  <meta charset="utf-8"/>



  <!-- Set the viewport width to device width for mobile -->

  <meta name="viewport" content="width=device-width"/>



  <title>Salary | Client</title>

  <!-- Included CSS Files -->

  <link rel="stylesheet" href="Payroll/css/responsive.css">

  <link rel="stylesheet" href="Payroll/css/style.css">
  <link rel="stylesheet" href="Payroll/css/jquery-ui.css">
    <script type="text/javascript" src="Payroll/js/jquery.min.js"></script>
    <script type="text/javascript" src="Payroll/js/jquery-ui.js"></script>


    <script>
        $( function() {
            $("#cm").datepicker({
                changeMonth: true,
                changeYear: true,
                dateFormat:'dd-mm-yy'
            });
        } );



    function deleterow(id) {
        if(confirm('Are you You Sure want to delete this Field?')) {
            $.get('/delete-mast-client-process', {
                'cid': id
            }, function (data) {
                $('#success').hide();
                $('#error').hide();
                $("#success1").html('Recourd Delete Successfully');
                $("#success1").show();
                $("#dispaly").load(document.URL + ' #dispaly');
            });
        }

    }
    function clear() {
        $('#cnerror').html("");
        $('#ad1error').html("");
        $('#pererror').html("");
        $('#esierror').html("");
        $('#pferror').html("");
        $('#tanerror').html("");
        $('#panerror').html("");
        $('#gsterror').html("");
    }
  function save() {
      clear();
      $('#success1').hide();
        var name=$("#cname").val();
        var add1=$("#add1").val();
        var esicode=$("#esicode").val();
        var pfcode=$("#pfcode").val();
        var tanno=$("#tanno").val();
        var panno1=$("#panno").val();
        var gstno=$("#gstno").val();
      var cm=$("#cm").val();
      var parent=$("#parent").val();
      var sc=$("#sc").val();
      var email=$("#email").val();
     var parent_comp=$("#parent_comp").val();
   var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;
$("#cname").removeClass('bordererror');
$("#add1").removeClass('bordererror');
$("#esicode").removeClass('bordererror');
$("#pfcode").removeClass('bordererror');
$("#tanno").removeClass('bordererror');
$("#panno").removeClass('bordererror');
$("#gstno").removeClass('bordererror');
$("#cm").removeClass('bordererror');
$("#email").removeClass('bordererror');
$("#parent").removeClass('bordererror');


    if(name ==""){
   $("#cname").focus();
   error ="Please Enter the Client Name";
   $("#cname").val('');
   $("#cname").addClass('bordererror');
   $("#cname").attr("placeholder", error);
   return false;
}
  else if(add1 ==""){
   $("#add1").focus();
   error ="Please Enter the address 1";
   $("#add1").val('');
   $("#add1").addClass('bordererror');
   $("#add1").attr("placeholder", error);
   return false;
}
 else if(parent ==""){
   $("#parent").focus();
   error ="Please select parent";
   $("#parent").val('');
   $("#parent").addClass('bordererror');
   $("#parent").attr("placeholder", error);
   return false;
}else if(esicode ==""){
   $("#esicode").focus();
   error ="Please Enter the ESI Code";
   $("#esicode").val('');
   $("#esicode").addClass('bordererror');
   $("#esicode").attr("placeholder", error);
   return false;
}
 else if(pfcode ==""){
   $("#pfcode").focus();
   error ="Please Enter the PF Code";
   $("#pfcode").val('');
   $("#pfcode").addClass('bordererror');
   $("#pfcode").attr("placeholder", error);
   return false;
}
 else if(tanno ==""){
   $("#tanno").focus();
   error ="Please Enter the TAN No";
   $("#tanno").val('');
   $("#tanno").addClass('bordererror');
   $("#tanno").attr("placeholder", error);
   return false;
}
 else if(panno1 ==""){
   $("#panno").focus();
   error ="Please Enter the PAN No";
   $("#panno").val('');
   $("#panno").addClass('bordererror');
   $("#panno").attr("placeholder", error);
   return false;
}
 else if(gstno ==""){
   $("#gstno").focus();
   error ="Please Enter the GST No";
   $("#gstno").val('');
   $("#gstno").addClass('bordererror');
   $("#gstno").attr("placeholder", error);
   return false;
}
 else if(cm ==""){
   $("#cm").focus();
   error ="Please Select Current Month";
   $("#cm").val('');
   $("#cm").addClass('bordererror');
   $("#cm").attr("placeholder", error);
   return false;
}
else if (!filter.test(email) && email != "") {

            error = "Please enter valid email";

            $("#email").val('');

            $("#email").addClass('bordererror');

            $("#email").attr("placeholder", error);

            return false;

        }

      else {
              $.get('/add-mast-client-process',{
                  'name':name,
                  'add1':add1,
                  'esicode':esicode,
                  'pfcode':pfcode,
                  'tanno':tanno,
                  'panno':panno1,
                  'gstno':gstno,
                  'cm':cm,
                  'sc':sc,
                  'email':email,
                  'parent':parent,
                  'parent_comp':parent_comp

              },function(data){
                    alert(data);
                  $('#error').hide();
                  $("#success").html('Record Insert Successfully<br/><br/>');
                  $("#success").html(data);
                  $("#success").show();
                  $("#form").trigger('reset');
                  $("#dispaly").load(document.URL +  ' #dispaly');


              });

      }

  }



    </script>
    <style>
    .highlight {
    background-color:#333;
    cursor:pointer;
    }
    </style>
</head>
 <body>

<!--Header starts here-->
<?php include('header.php');?>
<!--Header end here-->
<div class="clearFix"></div>
<!--Menu starts here-->



<!--Menu ends here-->
<div class="clearFix"></div>
<!--Slider part starts here-->

<div class="twelve mobicenter innerbg">
    <div class="row">
	
        <div class="twelve" id="margin1"><h3>Client</h3></div>



        <div class="clearFix"></div>
		<div class="boxborder" id="addclient">
        <form id="form">
        <div class="twelve" id="margin1">
            <div class="twelve padd0 columns successclass hidecontent" id="success">


            </div>

            <div class="clearFix"></div>
            <div class="one padd0 columns">
            <span class="labelclass">Name :</span>
            </div>
            <div class="four padd0 columns">
                <input type="text" name="cname" id="cname" placeholder="Client Name" class="textclass">
                <span class="errorclass hidecontent" id="cnerror"></span>
            </div>
            <div class="two columns">

            </div>
            <div class="one columns">
                <span class="labelclass">Address:</span>
            </div>
            <div class="four padd0 columns">
                <textarea class="textclass" id="add1" name="add1"  placeholder="Address"></textarea>
                <span class="errorclass hidecontent" id="ad1error"></span>
            </div>
            <div class="clearFix"></div>

<!--------------Start Parent Yes/No------------------------>
   <div class="one padd0 columns" id="margin1">
                <span class="labelclass">Parent Company :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <select id="parent_comp" name="parent_comp" class="textclass" onchange="showparent(this.value)">
                       <option value="N">No</option>
                       <option value="Y">Yes</option>
                </select>
                <span class="errorclass hidecontent" id="pererror"></span>
            </div>
            <div class="two columns">

            </div>
              <div class="one columns" id="margin1">
                <span class="labelclass">  ESI CODE :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="esicode" id="esicode" placeholder="ESI Code" class="textclass">
                <span class="errorclass hidecontent" id="esierror"></span>
            </div>
               
               <div class="clearFix"></div>
<!--------------End Parent Yes/No------------------------>
    <div class="parent">
            <div class="one padd0 columns" id="margin1">
                <span class="labelclass">Parent :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <select id="parent" name="parent" class="textclass">
                    <option value="">- Not Applicable -</option>
                    <?php
                    foreach($result1 as $row1){
                    
                        ?>

                        <option value="<?php echo $row1['mast_client_id'];?>"><?php echo $row1['client_name'];?></option>
                    <?php }

                    ?>
                </select>
                <span class="errorclass hidecontent" id="pererror"></span>
            </div>
            <div class="two columns">

            </div>
        </div>

          
            <div class="clearFix"></div>

            <div class="one padd0 columns" id="margin1">
                <span class="labelclass"> PFCODE :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="pfcode" id="pfcode" placeholder="PF Code" class="textclass">
                <span class="errorclass hidecontent" id="pferror"></span>
            </div>
            <div class="two columns">

            </div>
            <div class="one columns" id="margin1">
                <span class="labelclass">TAN No :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="tanno" id="tanno" placeholder="TAN No" class="textclass">
                <span class="errorclass hidecontent" id="tanerror"></span>
            </div>
            <div class="clearFix"></div>

            <div class="one padd0 columns" id="margin1">
                <span class="labelclass">PAN No :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="panno" id="panno" placeholder="PAN No" class="textclass">
                <span class="errorclass hidecontent" id="panerror"></span>
            </div>
            <div class="two columns">

            </div>
            <div class="one columns" id="margin1">
                <span class="labelclass"> GST No :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="gstno" id="gstno" placeholder="GST No" class="textclass">
                <span class="errorclass hidecontent" id="gsterror"></span>
            </div>

            <div class="clearFix"></div>

            <div class="one padd0 columns" id="margin1">
                <span class="labelclass">Month :</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="cm" id="cm" placeholder="Current Month" class="textclass">
                <span class="errorclass hidecontent" id="cmerror"></span>
            </div>
            <div class="two columns">

            </div>
            <div class="one columns" id="margin1">
                <span class="labelclass">Email Id:</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="email" id="email" placeholder="Enter the Email Id" class="textclass">
            </div>

            <div class="clearFix"></div>
            <div class="one padd0 columns" id="margin1">
                <span class="labelclass">Charges:</span>
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="text" name="sc" id="sc" placeholder="Services Charges" class="textclass">

            </div>

            <div class="two padd0 columns" id="margin1">

            </div>
            <div class="five padd0 columns" id="margin1">

            </div>

            <div class="clearFix"></div>

             <div class="one padd0 columns" id="margin1">
            </div>
            <div class="four padd0 columns" id="margin1">
                <input type="button" name="submit" id="submit" value="Save" class="btnclass" onclick="save();">
            </div>
            <div class="seven padd0 columns" id="margin1">
                &nbsp;
            </div>
            <div class="clearFix"></div>

            </form>
        </div>
        </div>
		<div id="editclient"></div>
        <div class="twelve" id="margin1">
            <h3>Display Client</h3>
        </div>
         <hr>
    <span class="successclass hidecontent" id="success1"></span>
        <div class="twelve" id="margin1" style="background-color: #fff;" >

            <div id="dispaly">
            <table width="100%" id="example" class="display" >
                 <thead>
                    <tr>
                        <th align="left" width="5%">Sr.No</th>
                        <th align="left" width="20%">Name</th>
                        <th align="left" width="20%">Parent</th>
                        <th align="left" width="20%">Address</th>
                        <th align="left" width="20%">ESI Code</th>
                        <th align="left" width="20%">PAN No</th>

                        <th align="center" width="10%">Action</th>

                    </tr>
 </thead>
                <?php
                $count=1;
               
                foreach($result as $row){
                   
                    $parentNm=$payrollAdmin->displayClient($row['parentId']);
                   
                ?>

                    <tr id="reload('<?=$row['mast_client_id'];?>');">
                        <td class="tdata"><?php echo $count;?></td>
                        <td class="tdata"><?=$row['client_name'];?></td>
                         <td class="tdata"><?=$parentNm['client_name'];?></td>
                        <td class="tdata"><?=$row['client_add1'];?></td>
                          <td class="tdata"><?=$row['esicode'];?></td>
                        <td class="tdata"><?=$row['panno'];?></td>
                        <td class="tdata" align="center"> 
						<a  onclick="editMasClient('<?=$row['mast_client_id'];?>');">
                                <img src="Payroll/images/edit-icon.png" /></a>
                            <!--a href="javascrip:void()" onclick="deleterow(<?=$row['mast_client_id'];?>)">
                                <img src="Payroll/images/delete-icon.png" /></a--></td>

                    </tr>
                <?php
                    $count++;
                } ?>
                <?php if($total_results == 0){?>
                <tr align="center">
                    <td colspan="7" class="tdata errorclass">
                        <span class="norec">No Record found</span>
                    </td>
                <tr>
                    <?php }?>
            </table>
               
            </div>







</div>


</div>
<br/>
<!--Slider part ends here-->
<div class="clearFix"></div>

<!--footer start -->
<?php include('footer.php');?>

<script>
    function editMasClient(id) {
       $.post('/edit-mast-client', {
                'cid': id
            }, function (data) {
				$("#addclient").hide();
				$("#editclient").html(data);
				$("#editclient").show();
                
            });

    }
    function update() {
      $('#success1').hide();
        var name=$("#editcname").val();
        var add1=$("#editadd1").val();
        var esicode=$("#editesicode").val();
        var pfcode=$("#editpfcode").val();
        var tanno=$("#edittanno").val();
        var panno1=$("#editpanno").val();
        var gstno=$("#editgstno").val();
        var cid=$("#cid").val();
      var cm=$("#editcm").val();
      var parent=$("#editparent").val();
      var sc=$("#editsc").val();
      var email=$("#editemail").val();
      var parent_comp=$("#editparent_comp").val();
     // var rule = /^[a-zA-Z]*$/;
$("#editcname").removeClass('bordererror');
$("#editadd1").removeClass('bordererror');
$("#editesicode").removeClass('bordererror');
$("#editpfcode").removeClass('bordererror');
$("#edittanno").removeClass('bordererror');
$("#editpanno").removeClass('bordererror');
$("#editgstno").removeClass('bordererror');
$("#cid").removeClass('bordererror');
$("#editcm").removeClass('bordererror');
$("#editparent").removeClass('bordererror');
$("#editsc").removeClass('bordererror');
$("#editemail").removeClass('bordererror');

    if(name ==""){
   $("#editcname").focus();
   error ="Please Enter the Client Name";
   $("#editcname").val('');
   $("#editcname").addClass('bordererror');
   $("#editcname").attr("placeholder", error);
   return false;
}
  else if(add1 ==""){
   $("#editadd1").focus();
   error ="Please Enter the address 1";
   $("#editadd1").val('');
   $("#editadd1").addClass('bordererror');
   $("#editadd1").attr("placeholder", error);
   return false;
} else if(esicode ==""){
   $("#editesicode").focus();
   error ="Please Enter the ESI Code";
   $("#editesicode").val('');
   $("#editesicode").addClass('bordererror');
   $("#editesicode").attr("placeholder", error);
   return false;
}
 else if(pfcode ==""){
   $("#edittanno").focus();
   error ="Please Enter the TAN No";
   $("#edittanno").val('');
   $("#edittanno").addClass('bordererror');
   $("#edittanno").attr("placeholder", error);
   return false;
}
 else if(panno1 ==""){
   $("#editpanno").focus();
   error ="Please Enter the PAN No";
   $("#editpanno").val('');
   $("#editpanno").addClass('bordererror');
   $("#editpanno").attr("placeholder", error);
   return false;
}
 else if(gstno ==""){
   $("#editgstno").focus();
   error ="Please Enter the GST No";
   $("#editgstno").val('');
   $("#editgstno").addClass('bordererror');
   $("#editgstno").attr("placeholder", error);
   return false;
}
 else if(cm ==""){
   $("#editcm").focus();
   error ="Please Select Current Month";
   $("#editcm").val('');
   $("#editcm").addClass('bordererror');
   $("#editcm").attr("placeholder", error);
   return false;
}
else {

              $.post('/edit-mast-client-process',{
                  'name':name,
                  'cid':cid,
                  'add1':add1,
                  'esicode':esicode,
                  'pfcode':pfcode,
                  'tanno':tanno,
                  'panno':panno1,
                  'gstno':gstno,
                  'cm':cm,
                  'sc':sc,
                  'email':email,
                  'parent':parent,
                  'parent_comp':parent_comp

              },function(data){ 
                  //alert(data);
                  $('#error').hide();
                  $("#editsuccess").html(data);
                  $("#editsuccess").show();
                  $("#dispaly").load(document.URL +  ' #dispaly');
              });

      }
  

  }
  
  function showparent(value){
      if(value=='N'){
         $('.parent').show();
      }else{
         $('.parent').hide(); 
      }
  }
</script>
<!--footer end -->

</body>

</html>