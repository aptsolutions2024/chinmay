<?php
include ('../include_payroll_admin.php');


$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];




?>
<!DOCTYPE html>
<head>
  <meta charset="utf-8"/>
  <!-- Set the viewport width to device width for mobile -->
  <meta name="viewport" content="width=device-width"/>
  <title>Salary | Monthly Closing</title>

  <script>

      function closing(){
         $('#display').html('<div style="height: 200px;width:400px;padding-top:100px;" align="center"> <img src="../images/loading.gif" /></div>');
          var clientid = '1';
          $.post('/monthly_closing',{
              'clientid':clientid
          },function(data){
 
              $("#display").html(data);

          });
      }
	  
	  
	  
      function update_advances(){
         $('#display').html('<div style="height: 200px;width:400px;padding-top:100px;" align="center"> <img src="../images/loading.gif" /></div>');
          var clientid = '1';
          $.post('/update_advances',{
              'clientid':clientid
          },function(data){
 
              $("#display").html(data);

          });
      }

  </script>

 <body>

<!--Header starts here-->
<?php include('header.php');?>
<!--Header end here-->
<div class="clearFix"></div>
<!--Menu starts here-->


<!--Menu ends here-->
<div class="clearFix"></div>
<!--Slider part starts here-->


            
            
<div class="twelve mobicenter innerbg">
    <div class="row" >
         <div class="boxborder" id="chackPassword" style="height: 120px;margin-top: 3%;" >
       
            <div class="one padd0 columns">
            <span class="labelclass">Password :</span>
            </div>
            <div class="four padd0 columns">
                <input type="password" name="password" id="password" placeholder="Enter password" class="textclass">
                <span class="errorclass hidecontent" id="cnerror"></span>
            </div>
             <div class="clearFix"></div>
             <div class="one padd0 columns"></div>
            <div class="four padd0 columns" id="margin1">
             <button class="btnclass" onclick="checkPassword()"> Submit</button>
          </div>
          </div>
            
       <div id="monthlyClosing" style="display:none;">
        <div class="twelve padd0" id="margin1"> <h3>Monthly Closing</h3></div>
        
        <div class="clearFix"></div>
        <div class="twelve padd0" id="margin1">
            <div class="boxborder" id="addOtherPayment">
            <div class="one padd0 columns"  id="margin1">
               <!-- <span class="labelclass">Client :</span> -->
            </div>
            <div class="four padd0 columns" id="margin1">
                <button class="btnclass" onclick="closing()">
                    Monthly Closing

                </button>
               <!-- <select id="clientid" name="clientid" class="textclass" >
                    <option value="0">--select--</option>
                    <?php
       
                    ?>
                </select> -->
            </div>
           

		<div class="four padd0 columns" id="margin1">
                <button class="btnclass" onclick="update_advances()">
                    Update Advances
                </button>
               <!-- <select id="clientid" name="clientid" class="textclass" >
                    <option value="0">--select--</option>
                    <?php
                    ?>
                </select> -->
            </div>

			<div class="two  padd0 columns" id="margin1" align="center">
               <a href="/db_backup_view" ><button class="btnclass"> Database Backup </button></a>
            </div>
            <div class="five  padd0 columns" id="margin1" align="center">

            </div>
            <div class="clearFix"></div>
            <div class="twelve" id="display">
            </div>

 </div>
  </div>
</div>



</div>




</div>

<!--Slider part ends here-->
<div class="clearFix"></div>

<!--footer start -->
<?php include('footer.php');?>

<script>
    function checkPassword()
    {
        var password= $("#password").val();
        if(password ==""){
           $("#password").focus();
           error ="Please enter password";
           $("#password").val('');
           $("#password").addClass('bordererror');
           $("#password").attr("placeholder", error);
           return false;
        }else if(password=='hopes')
        {
          $("#monthlyClosing").show();
          $("#chackPassword").hide();
        }else
        {
            alert("Your password does not match. Please try again.");
            $("#password").val('');
        }
    }
</script>

<!--footer end -->

</body>

</html>