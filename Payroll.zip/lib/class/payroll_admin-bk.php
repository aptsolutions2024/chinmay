<?php
class user{
   
     /*  use for login Starts  */
    function login($user,$pass){
	     $sql = "select * from login_master where username ='".$user."' AND userpass='".$pass."' ";
		$res = mysql_query($sql);
		$row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row;
        }
	}
    /*  use for login end  */

	  /* use for display Cal type Starts  */
    function showCalType($dbname){
        $sql = "select * from $dbname";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display Cal type end  */
	
	
    /*  use for show all clients Starts  */
	function showClient(){
       $sql = "select * from mast_client ORDER BY `mast_client_id` DESC";
		$res = mysql_query($sql);
        return $res;
	}
    /*  use for show all clients end  */

    /*  use for show all clients as comp and user wise Starts  */
    function showClient1($comp_id,$user_id){
       $sql = "select * from mast_client where comp_id ='".$comp_id."' AND user_id='".$user_id."'  ORDER BY `mast_client_id` DESC";
		$res = mysql_query($sql);
        return $res;
	}
    /*  use for show all clients as comp and user wise end  */

    /*  use for display all clients Starts  */
	function displayClient($cid){
       $sql = "select * from mast_client WHERE mast_client_id='".$cid."'";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row;
        }
	}
    /*  use for display all clients end  */

    /* use for display client as client Id  Starts  */
    function displayemployeeClient($cid){
     $sql = "select * from employee WHERE client_id='".$cid."' AND job_status!='L'";
     $res = mysql_query($sql);
     return $res;
    }
    /* use for display client as client Id  end  */

    /* use for display client as client Id  Starts  */
    function displayemployeeClientlmt($cid,$lmt){
     $sql = "select * from employee WHERE client_id='".$cid."' AND job_status!='L' order by emp_id, first_name,middle_name,last_name limit $lmt";
     $res = mysql_query($sql);
     return $res;
    }
    /* use for display client as client Id  end  */

    /* use for update client as client Id Starts  */
    function updateClient($cid,$name,$add1,$esicode,$pfcode,$tanno,$panno,$gstno,$mont,$parent,$sc,$email,$comp_id,$user_id){
        $sql = "UPDATE `mast_client` SET `comp_id`='".$comp_id."',`user_id`='".$user_id."',`email`='".$email."',`ser_charges`='".$sc."',`client_name`='".$name."',`client_add1`='".$add1."',`esicode`='".$esicode."',`pfcode`='".$pfcode."',`tanno`='".$tanno."',`panno`='".$panno."',`gstno`='".$gstno."',`current_month`='".$mont."',`parentId`='".$parent."',`db_update`=NOW()  WHERE mast_client_id='".$cid."'";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update client as client Id Starts  */

    /* use for insert client Starts  */
	function insertClient($name,$add1,$esicode,$pfcode,$tanno,$panno,$gstno,$mont,$parent,$comp_id,$user_id,$sc,$email){
              $sql = "INSERT INTO `mast_client`(`client_name`, `client_add1`,`esicode`, `pfcode`, `tanno`, `panno`, `gstno`, `current_month`,`parentId`, `user_id`,`comp_id`,`email`, `ser_charges`,`db_adddate`, `db_update`) VALUES('".$name."','".$add1."','".$esicode."','".$pfcode."','".$tanno."','".$panno."','".$gstno."','".$mont."','".$parent."','".$user_id."','".$comp_id."','".$email."','".$sc."',NOW(),NOW())";
	          $res = mysql_query($sql);
            return $res;
	}
    /* use for insert client end  */

    /* use for delete client Starts  */
	function deleteClient($cid){
            $sql = "DELETE FROM `mast_client` WHERE mast_client_id='".$cid."' ";
		    $res = mysql_query($sql);
            return $res;
    }
    /* use for delete client end */

    /* use for insert emp Starts  */
   function insertEmployee($fname,$mname,$lname,$gentype,$bdate,$joindate,$lodate,$incdate,$add1,$panno,$perdate,$pfdate,$client,$design,$depart,$qualifi,$bank,$location,$bankacno,$paycid,$esistatus,$namerel,$prnsrno,$esicode,$pfcode,$adhaar,$drilno,$uan,$votid,$jobstatus,$email,$phoneno,$duedate,$ticket_no,$comp_ticket_no,$married_status,$pay_mode,$pin_code,$handicap,$nation,$comp_id,$user_id,$qualification,$department){
          $sql = "INSERT INTO `employee`(`first_name`, `middle_name`, `last_name`, `gender`, `bdate`, `joindate`, `leftdate`,`incrementdate`, `permanentdate`, `pfdate`, `client_id`, `desg_id`, `dept_id`, `qualif_id`, `bank_id`, `loc_id`,  `paycode_id`, `bankacno`, `middlename_relation`, `prnsrno`, `esino`, `pfno`, `esistatus`, `adharno`, `panno`,`driving_lic_no`, `uan`, `voter_id`, `job_status`, `email`,`emp_add1`,`mobile_no`,  `due_date`, `ticket_no`, `comp_ticket_no`, `married_status`, `pay_mode`, `nationality`, `handicap`,`pin_code`,`comp_id`,`user_id`, `dept`, `qualif`,`db_adddate`, `db_update`) VALUES ('".$fname."','".$mname."','".$lname."','".$gentype."','".$bdate."','".$joindate."','".$lodate."','".$incdate."','".$perdate."','".$pfdate."','".$client."','".$design."','".$depart."','".$qualifi."','".$bank."','".$location."','".$paycid."','".$bankacno."','".$namerel."','".$prnsrno."','".$esicode."','".$pfcode."','".$esistatus."','".$adhaar."','".$panno."','".$drilno."','".$uan."','".$votid."','".$jobstatus."','".$email."','".$add1."','".$phoneno."','".$duedate."','".$ticket_no."','".$comp_ticket_no."','".$married_status."','".$pay_mode."','".$nation."','".$handicap."','".$pin_code."','".$comp_id."','".$user_id."','".$department."','".$qualification."',NOW(),NOW())"; 
         $res = mysql_query($sql);
         $count = mysql_insert_id();
        return $count;
    }
    /* use for insert emp end  */

    /*   Starts  */
    function insertEmployeebk($techstype,$gentype,$bdate,$joindate,$add1,$add2,$prnsrno,$esicode,$pfcode,$tanno,$panno,$gstno){
         $sql = "INSERT INTO `employee`( `teaching_staff`, `gender`, `bdate`, `joindate`, `emp_add1`, `emp_add2`, `prnsrno`, `esicode`, `pfcode`, `tanno`, `panno`, `gstno`, `db_adddate`, `db_update`) VALUES ('".$techstype."','".$gentype."','".$bdate."','".$joindate."','".$add1."','".$add2."','".$prnsrno."','".$esicode."','".$pfcode."','".$tanno."','".$panno."','".$gstno."',Now(),Now())";
        $res = mysql_query($sql);
       $count = mysql_insert_id();
        return $count;
    }

    /* use for insert emp income Starts  */
    function insertEmployeeincome($empid,$caltype,$stdamt,$incomeid,$inremark,$comp_id,$user_id){
         $sql1 = "select * from `emp_income` WHERE emp_id='".$empid."' AND head_id='".$incomeid."' ";
         $res1 = mysql_query($sql1);
         $rows = mysql_fetch_array($res1);
         $rowsdata=mysql_num_rows($res1);
       if($rowsdata=='0') {
            $sql = "INSERT INTO `emp_income`(`emp_id`,`head_id`, `calc_type`, `std_amt`, `remark`,`comp_id`,`user_id`, `db_addate`, `db_update`) VALUES ('".$empid."','".$incomeid."','".$caltype."','".$stdamt."','".$inremark."','".$comp_id."','".$user_id."',Now(),Now())";
            $res = mysql_query($sql);
       }else{
            $sql = "UPDATE `emp_income` SET calc_type='".$caltype."',std_amt='".$stdamt."',remark='".$inremark."',db_update=NOW() WHERE emp_income_id='".$rows['emp_income_id']."'";
            $res = mysql_query($sql);
       }
        return $res;
    }

    function insertEmpDesgincome($client_id,$design_id,$caltype,$stdamt,$incomeid)
	{
	$sql = "INSERT INTO `desg_income`(`desg_id`, `client_id`, `head_id`, `std_amt`, `calc_type`, `db_date`, `db_update`) VALUES ('".$design_id."','".$client_id."','".$incomeid."','".$stdamt."','".$caltype."',Now(),Now())";
   $res = mysql_query($sql);
    return $res;
    }
    function deletedesgEmpincome($id){
        $sql = "DELETE FROM desg_income WHERE `id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
     function showDesgEployeeincomeall($id){
        $sql = "select * from `desg_income` WHERE id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
     function updateDesgEmployeeincome($id, $caltype, $stdamt,$incomeid){
        $sql = "UPDATE `desg_income` SET head_id='".$incomeid."',calc_type='".$caltype."',std_amt='".$stdamt."',db_update=NOW() WHERE id='".$id."'";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for insert emp income end  */

    /* use for insert emp Duduct Starts  */
    function insertEmployeeeduct($empid,$decaltype,$destdamt,$destid, $destdremark,$comp_id,$user_id,$selbank){
        $sql1 = "select * from `emp_deduct` WHERE emp_id='".$empid."' AND head_id='".$destid."' ";
        $res1 = mysql_query($sql1);
        $rows = mysql_fetch_array($res1);
        $rowsdata=mysql_num_rows($res1);
        if($rowsdata=='0') {
              $sql = "INSERT INTO `emp_deduct`(`emp_id`, `head_id`, `calc_type`, `std_amt`, `remark`, `comp_id`,`user_id`,bank_id, `db_addate`, `db_update`) VALUES ('".$empid."','".$destid."','".$decaltype."','".$destdamt."','".$destdremark."','".$comp_id."','".$user_id."','".$selbank."',Now(),Now())";
                    $res = mysql_query($sql);
        }else{
        $sql = "UPDATE `emp_deduct` SET calc_type='".$decaltype."',std_amt='".$destdamt."',bank_id='".$selbank."',remark='".$destdremark."',db_update=NOW() WHERE  emp_deduct_id='".$rows['emp_deduct_id']."'";
            $res = mysql_query($sql);
        }
        return $res;
    }
    /* use for insert emp Duduct end */

    /* use for insert emp leave Starts  */
   function insertEmployeeleave($empid,$ob,$leayear,$comp_id,$user_id,$ason,$lt){
       $sql1 = "select * from `emp_leave` WHERE emp_id='".$empid."' AND leave_type_id='".$lt."' AND as_on='".$ason."' ";
       $res1 = mysql_query($sql1);
       $rows = mysql_fetch_array($res1);
       $rowsdata=mysql_num_rows($res1);
       if($rowsdata=='0') {
           $sql = "INSERT INTO `emp_leave`(`emp_id`, `year`, `ob`, `comp_id`,`user_id`,`leave_type_id`, `as_on`, `db_adddate`, `db_update`) VALUES  ('" . $empid . "','" . $leayear . "','" . $ob . "','".$comp_id."','".$user_id."','".$lt."','".$ason."',Now(),Now())";
           $res = mysql_query($sql);
       }
       else{
           $sql = "UPDATE `emp_leave` SET `year`='".$leayear."', `ob`='".$ob."',db_update=NOW() WHERE emp_leave_id='".$rows['emp_leave_id']."'";
           $res = mysql_query($sql);
       }
        return $res;
    }
    /* use for insert emp leave end  */

    /* use for insert emp advances Starts  */
    function insertEmployeeadvances($empid,$advamt,$advins,$comp_id,$user_id,$advdate,$advtype){
     $sql1 = "select * from `emp_advnacen` WHERE emp_id='".$empid."' AND advance_type_id='".$advtype."' AND date='".$advdate."' ";
        $res1 = mysql_query($sql1);
        $rows = mysql_fetch_array($res1);
        $rowsdata=mysql_num_rows($res1);
        if($rowsdata=='0') {
         $sql = "INSERT INTO `emp_advnacen`(`emp_id`,`date`,`advance_type_id`,`adv_amount`,`adv_installment`,`comp_id`,`user_id`, `db_addate`, `db_update`) VALUES ('".$empid."','".$advdate."','".$advtype."','".$advamt."','".$advins."','".$comp_id."','".$user_id."',Now(),Now())";
             $res = mysql_query($sql);
      }
        else{
            $sql = "UPDATE emp_advnacen SET adv_amount='".$advamt."', adv_installment='".$advins."',db_update=NOW() WHERE emp_advnacen_id='".$rows['emp_advnacen_id']."'";
            $res = mysql_query($sql);
        }
        return $res;
    }
    /* use for insert emp advances end */

    /* use for display emp with compid and userid Starts  */
    function showEmployee($comp_id,$user_id){
        $sql = "select * from employee where comp_id ='".$comp_id."' AND user_id='".$user_id."'   ORDER BY `emp_id` DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp with compid and userid end  */

    /* use for display emp with empid Starts  */
    function showEployeedetails($id){
       $sql = "select * from employee WHERE emp_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp with empid end  */

     function show_tab_Eployeedetails($tab,$id,$sal_month){
       $sql = "select * from $tab WHERE emp_id='".$id."' and sal_month = '".$sal_month."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }


    /* use for display emp income with empid Starts  */
   function showEployeeincome($id){
        $sql = "select * from `emp_income` WHERE emp_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp income with empid end */

    /* use for display emp deduct with empid Starts  */
    function showEployeededuct($id){
        $sql = "select * from `emp_deduct` WHERE emp_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp deduct with empid end  */

    /* use for display emp leave with empid Starts  */
    function showEployeeleave($id){
      $sql = "select * from `emp_leave` WHERE emp_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp leave with empid end  */

    /* use for display emp adnavce with empid Starts  */
    function showEployeeadnavcen($id){
      $sql = "select * from `emp_advnacen` WHERE emp_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp adnavce with empid end */

    /* use for update emp with empid Starts  */
    function updateEmployee($id,$fname,$mname,$lname,$gentype,$bdate,$joindate,$lodate,$incdate,$add1,$panno,$perdate,$pfdate,$client,$design,$depart,$qualifi,$bank,$location,$bankacno,$paycid,$esistatus,$namerel,$prnsrno,$esicode,$pfcode,$adhaar,$drilno,$uan,$votid,$jobstatus,$emailtext,$phone,$duedate,$ticket_no,$comp_ticket_no,$married_status,$pay_mode,$pin_code,$handicap,$nation,$comp_id,$user_id,$qualification,$department){
     $sql = "UPDATE `employee` SET `comp_id`='".$comp_id."',`user_id`='".$user_id."',email='".$emailtext."',`first_name`='".$fname."',`middle_name`='".$mname."',`last_name`='".$lname."',`gender`='".$gentype."',`bdate`='".$bdate."',`joindate`='".$joindate."',`leftdate`='".$lodate."',`incrementdate`='".$incdate."',`permanentdate`='".$perdate."',`pfdate`='".$pfdate."',`client_id`='".$client."',`desg_id`='".$design."',`dept_id`='".$depart."',`qualif_id`='".$qualifi."',`bank_id`='".$bank."',`loc_id`='".$location."',`paycode_id`='".$paycid."',`bankacno`='".$bankacno."',`middlename_relation`='".$namerel."',`prnsrno`='".$prnsrno."',`esino`='".$esicode."',`pfno`='".$pfcode."',`esistatus`='".$esistatus."',`adharno`='".$adhaar."',`panno`='".$panno."',`driving_lic_no`='".$drilno."',`uan`='".$uan."',`voter_id`='".$votid."',`job_status`='".$jobstatus."',`emp_add1`='".$add1."',`mobile_no`='".$phone."', `due_date`='".$duedate."', `ticket_no`='".$ticket_no."', `comp_ticket_no`='".$comp_ticket_no."', `married_status`='".$married_status."', `pay_mode`='".$pay_mode."', `nationality`='".$nation."', `handicap`='".$handicap."',`pin_code`='".$pin_code."',`dept`='".$department."',`qualif`='".$qualification."',db_update=NOW() WHERE emp_id='".$id."'";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update emp with empid end  */

    /* use for update emp income with empincomeid Starts  */
    function updateEmployeeincome($id,$caltype,$stdamt,$incomeid,$inremark,$comp_id,$user_id){
        $sql = "UPDATE `emp_income` SET `comp_id`='".$comp_id."',`user_id`='".$user_id."', head_id='".$incomeid."',remark='".$inremark."',calc_type='".$caltype."',std_amt='".$stdamt."',db_update=NOW() WHERE emp_income_id='".$id."'";
        $res = mysql_query($sql);
        return $res;
    }
   /* use for update emp income with empincomeid end */

    /* use for update emp deduct with empdeductid Starts  */
    function updateEmployeeeduct($id,$decaltype,$destdamt,$destid, $destdremark,$comp_id,$user_id,$selbank){
      $sql = "UPDATE `emp_deduct` SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',head_id='".$destid."',remark='".$destdremark."',calc_type='".$decaltype."',std_amt='".$destdamt."',bank_id='".$selbank."',db_update=NOW() WHERE emp_deduct_id='".$id."'";
	  
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update emp deduct with empdeductid end  */

    /* use for update emp leave with empleaveid Starts  */
    function updateEmployeeleave($id,$ob,$leayear,$comp_id,$user_id,$ason,$lt){
       $sql = "UPDATE `emp_leave` SET `leave_type_id`='".$lt."', `as_on`='".$ason."',`comp_id`='".$comp_id."',`user_id`='".$user_id."',`year`='".$leayear."', `ob`='".$ob."',db_update=NOW() WHERE emp_leave_id='".$id."'";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update emp leave with empleaveid Starts  */

    /* use for update emp advance with empadvanceid Starts  */
    function updateEmployeeadvances($id,$advamt,$advins,$comp_id,$user_id,$advdate,$advtype){
       $sql = "UPDATE emp_advnacen SET `date`='".$advdate."',`advance_type_id`='".$advtype."',`comp_id`='".$comp_id."',`user_id`='".$user_id."',adv_amount='".$advamt."', adv_installment='".$advins."',db_update=NOW() WHERE emp_advnacen_id='".$id."'";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update emp advance with empadvanceid end */

    /* use for insert department Starts  */
    function insertDepartment($name,$comp_id,$user_id){
          $sql = "INSERT INTO `mast_dept`(mast_dept_name,comp_id,user_id,db_adddate,db_update) VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
          $res = mysql_query($sql);
          return $res;
    }
    /* use for insert department end */

    /* use for display department with compid Starts  */
    function showDepartment($comp_id){
        $sql = "select * from mast_dept where comp_id ='".$comp_id."' ORDER BY `mast_dept_name` DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display department with compid end */

    /* use for delete department with deptid Starts  */
    function deleteDepartment($did){
       $sql = "DELETE FROM `mast_dept` WHERE mast_dept_id='".$did."' ";
	   $res = mysql_query($sql);
        return $res;
    }
    /* use for delete department with deptid end  */

    /* use for update department with deptid Starts */
   function updateDepartment($did,$name,$comp_id,$user_id){
      $sql = "UPDATE `mast_dept` SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',`mast_dept_name`='".$name."' ,db_update=NOW() WHERE mast_dept_id='".$did."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update department with deptid end */

    /* use for display department with deptid Starts */
    function displayDepartment($did){
             $sql = "SELECT * FROM `mast_dept`  WHERE mast_dept_id='".$did."' ";
             $res = mysql_query($sql);
             $row=mysql_fetch_array($res);
             return $row;
    }
    /* use for display department with deptid end */

    /* use for insert qualification Starts */
    function insertQualification($name,$comp_id,$user_id){
            $sql = "INSERT INTO `mast_qualif`(mast_qualif_name,comp_id,user_id,`db_adddate`, `db_update`) VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
            $res = mysql_query($sql);
            return $res;
    }
    /* use for insert qualification end */

    /* use for display qualification with compid Starts */
    function showQualification($comp_id){
           $sql = "select * from mast_qualif where comp_id ='".$comp_id."' ORDER BY `mast_qualif_name` ASC";
           $res = mysql_query($sql);
           return $res;
    }
    /* use for display qualification with compid end */

    /* use for display qualification with qualifid Starts */
    function displayQualification($qid){
        $sql = "SELECT * FROM `mast_qualif` WHERE mast_qualif_id='".$qid."' ";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display qualification with qualifid end */

    /* use for delete qualification with qualifid Starts */
    function deleteQualification($id){
     $sql = "DELETE FROM  `mast_qualif`  WHERE mast_qualif_id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete qualification with qualifid end */

    /* use for update qualification with qualifid Starts */
    function updateQualification($id,$name,$comp_id,$user_id){
      $sql = "UPDATE `mast_qualif` SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."', mast_qualif_name='".$name."' ,db_update=NOW() WHERE mast_qualif_id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update qualification with qualifid end */


    /* use for insert designation Starts */
    function insertDesignation($name,$comp_id,$user_id){
        $sql = "INSERT INTO `mast_desg`(mast_desg_name,comp_id,user_id,db_adddate,db_update) VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for insert designation end */

    /* use for display designation with compid Starts */
    function showDesignation($comp_id){
      $sql = "select * from mast_desg where comp_id ='".$comp_id."' ORDER BY `mast_desg_id` DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display designation with compid end*/

    /* use for delete designation with desgid Starts */
    function deleteDesignation($id){
        $sql = "DELETE FROM mast_desg  WHERE mast_desg_id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete designation with desgid end */

    /* use for display designation with desgid  Starts */
    function displayDesignation($did){
        $sql = "SELECT * FROM mast_desg  WHERE mast_desg_id='".$did."' ";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display designation with desgid  end */


 

    /* use for update designation with desgid  Starts */
    function updateDesignation($id,$name,$comp_id,$user_id){
        $sql = "UPDATE mast_desg SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',mast_desg_name='".$name."' ,db_update=NOW() WHERE mast_desg_id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update designation with desgid  end */

    /* use for insert location Starts */
    function insertLocation($name,$comp_id,$user_id){
        $sql = "INSERT INTO `mast_location`(mast_location_name,comp_id,user_id,db_adddate,db_update) VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for insert location end */

    /* use for display location with compid Starts */
    function showLocation($comp_id){
        $sql = "select * from mast_location where comp_id ='".$comp_id."' ORDER BY `mast_location_id` DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display location with compid end */

    /* use for display location Starts */
    function displayLocation($lid){
        $sql = "SELECT * FROM mast_location WHERE mast_location_id='".$lid."' ";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display location end*/

    /* use for delete location Starts */
    function deleteLocation($id){
        $sql = "DELETE FROM mast_location WHERE mast_location_id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete location end*/

    /* use for update location Starts */
    function updateLocation($id,$name,$comp_id,$user_id){
        $sql = "UPDATE mast_location SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',mast_location_name='".$name."' ,db_update=NOW() WHERE mast_location_id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update location end */

    /* use for display bank with compid Starts */
    function showBank($comp_id){
         $sql = "select * from mast_bank where comp_id ='".$comp_id."' ORDER BY `bank_name` ASC";
	   
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display bank with compid end */

    /* use for insert payscalecode Starts */
    function insertPayscalecode($name,$comp_id,$user_id){
        $sql = "INSERT INTO `mast_paycode`(mast_paycode_name,comp_id,user_id,db_adddate,db_update) VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for insert payscalecode end */

    /* use for display payscalecode with compid Starts */
    function showPayscalecode($comp_id){
        $sql = "select * from mast_paycode where comp_id ='".$comp_id."' ORDER BY `mast_paycode_id` DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display payscalecode with compid end */

    /* use for display payscalecode Starts */
    function displayPayscalecode($pscid){
         $sql = "select * from mast_paycode  WHERE `mast_paycode_id`='".$pscid."' ";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display payscalecode end*/

    /* use for delete payscalecode Starts */
    function deletePayscalecode($id){
      $sql = "DELETE FROM mast_paycode WHERE `mast_paycode_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete payscalecode end */

    /* use for update payscalecode Starts */
    function updatePayscalecode($id,$name,$comp_id,$user_id){
        $sql = "UPDATE mast_paycode SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',mast_paycode_name='".$name."' ,db_update=NOW() WHERE `mast_paycode_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;

    }
    /* use for update payscalecode end */

    /* use for insert bank Starts */
    function insertBank($name,$add,$branch,$pincode,$city,$ifsccode,$comp_id,$user_id){
        $sql = "INSERT INTO `mast_bank`( `bank_name`, `ifsc_code`, `add1`, `branch`, `city`, `pin_code`,`comp_id`, `user_id`, `db_adddate`, `db_update`) VALUES('".$name."','".$ifsccode."','".$add."','".$branch."','".$city."','".$pincode."','".$comp_id."','".$user_id."',NOW(),NOW())";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for insert bank end */

    /* use for delete bank Starts */
    function deleteBank($id){
        $sql = "DELETE FROM mast_bank WHERE `mast_bank_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete bank end */

    /* use for display bank Starts */
    function displayBank($bid){
        $sql = "select * from mast_bank WHERE `mast_bank_id`='".$bid."' ";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display bank end*/

    /* use for update bank Starts */
    function updateBank($bid,$name,$add,$branch,$pincode,$city,$ifsccode,$comp_id,$user_id){
        $sql = "UPDATE mast_bank SET `comp_id`='".$comp_id."', `user_id`='".$user_id."',bank_name='".$name."',`ifsc_code`='".$ifsccode."',`add1`='".$add."',`branch`='".$branch."',`city`='".$city."',`pin_code`='".$pincode."',db_update=NOW() WHERE `mast_bank_id`='".$bid."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update bank end*/

    /* use for insert Income head Starts */
    function insertIncomehead($name,$comp_id,$user_id){
       $sql = "INSERT INTO `mast_income_heads`(income_heads_name,comp_id,user_id,db_addate,db_update)  VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for insert Income head end */

    /* use for display Income head with compid Starts */
    function showIncomehead($comp_id){
       $sql = "select * from mast_income_heads where comp_id ='".$comp_id."' ORDER BY mast_income_heads_id ASC ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display Income head with compid end*/

    /* use for display Income head Starts */
    function displayIncomehead($id){
       $sql = "select * from mast_income_heads WHERE `mast_income_heads_id`='".$id."' ";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display Income head end */

    /* use for delete Income head Starts */
    function deleteIncomeheads($id){
        $sql = "DELETE FROM mast_income_heads WHERE `mast_income_heads_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete Income head end */

    /* use for update Income head Starts */
    function updateIncomehead($id,$name,$comp_id,$user_id){
        $sql = "UPDATE mast_income_heads  SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',income_heads_name='".$name."',db_update=NOW() WHERE `mast_income_heads_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update Income head end  */

    /* use for display deduct head Starts */
    function insertDeductionhead($name,$comp_id,$user_id){
        $sql = "INSERT INTO `mast_deduct_heads`(deduct_heads_name,comp_id,user_id,db_adddate,db_update)  VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display deduct head end */

    /* use for display deduct head with compid Starts */
    function showDeductionhead($comp_id){
        $sql = "select * from mast_deduct_heads where comp_id ='".$comp_id."' ORDER BY `mast_deduct_heads_id` ASC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display deduct head with compid end */

    /* use for delete deduct head Starts */
   function deleteDeductionheads($id){
        $sql = "DELETE FROM mast_deduct_heads WHERE `mast_deduct_heads_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete deduct head end */

    /* use for update deduct head Starts */
  function updateDeductionhead($id,$name,$comp_id,$user_id){
      $sql = "UPDATE mast_deduct_heads SET `comp_id`='".$comp_id."',`user_id`='".$user_id."', deduct_heads_name='".$name."',db_update=NOW() WHERE `mast_deduct_heads_id`='".$id."' ";
      $res = mysql_query($sql);
       return $res;
    }
    /* use for update deduct head end */

    /* use for display deduct head Starts */
   function displayDeductionhead($id){
       $sql = "select * from mast_deduct_heads WHERE  `mast_deduct_heads_id`='".$id."' ";
       $res = mysql_query($sql);
       $row=mysql_fetch_array($res);
       return $row;
   }
    /* use for display deduct head end */

    /* use for display Leave Type with compid  Starts */
   function showLeavetype($comp_id){
       $sql = "select * from mast_leave_type where comp_id ='".$comp_id."' ORDER BY `mast_leave_type_id` DESC";
       $res = mysql_query($sql);
       return $res;
   }
    /* use for display Leave Type with compid end */

    /* use for display Advance Type with compid Starts */
   function showAdvancetype($comp_id){
      $sql = "select * from mast_advance_type where comp_id ='".$comp_id."' ORDER BY `mast_advance_type_id` DESC";
       $res = mysql_query($sql);
       return $res;
   }
    /* use for display Advance Type with compid end */

    /* use for insert Leave Type Starts */
   function insertLeavetype($name,$comp_id,$user_id){
       $sql = "INSERT INTO `mast_leave_type`(leave_type_name,comp_id,user_id,db_adddate,db_update)  VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
       $res = mysql_query($sql);
       return $res;
   }
    /* use for insert Leave Type end */

    /* use for insert Advance Type Starts */
   function insertAdvancetype($name,$comp_id,$user_id){
       $sql = "INSERT INTO `mast_advance_type`(advance_type_name,comp_id,user_id,db_adddate,db_update)  VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
       $res = mysql_query($sql);
       return $res;
   }
    /* use for insert Advance Type end */

    /* use for delete Leave Type Starts */
   function deleteLeavetype($id){
       $sql = "DELETE FROM mast_leave_type WHERE mast_leave_type_id='".$id."' ";
       $res = mysql_query($sql);
       return $res;
   }
    /* use for delete Leave Type end */

    /* use for delete Advance Type Starts */
    function deleteAdvancetype($id){
        $sql = "DELETE FROM mast_advance_type WHERE mast_advance_type_id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete Advance Type end */

    /* use for display Leave Type Starts */
   function displayLeavetype($id){
       $sql = "select * from mast_leave_type WHERE mast_leave_type_id='".$id."' ";
       $res = mysql_query($sql);
       $row=mysql_fetch_array($res);
       return $row;
   }
    /* use for display Leave Type end */

    /* use for display Advance Type Starts */
   function displayAdvancetype($id){
       $sql = "select * from mast_advance_type WHERE mast_advance_type_id='".$id."' ";
       $res = mysql_query($sql);
       $row=mysql_fetch_array($res);
       return $row;
   }
    /* use for display Advance Type Starts */

    /* use for update Leave Type Starts */
   function updateLeavetype($id,$name,$comp_id,$user_id){
       $sql = "UPDATE mast_leave_type SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',leave_type_name='".$name."',db_update=NOW() WHERE mast_leave_type_id='".$id."' ";
       $res = mysql_query($sql);
       $row=mysql_fetch_array($res);
       return $row;
   }
    /* use for update Leave Type end */

    /* use for update Advance Type Starts */
   function updateAdvancetype($id,$name,$comp_id,$user_id){
       $sql = "UPDATE mast_advance_type SET `comp_id`='".$comp_id."',`user_id`='".$user_id."',advance_type_name='".$name."',db_update=NOW() WHERE mast_advance_type_id='".$id."' ";
       $res = mysql_query($sql);
       $row=mysql_fetch_array($res);
       return $row;
   }
    /* use for update Advance Type end */

    /* use for display tran days Starts */
    function displayTranday($id){
        $sql = "SELECT * FROM `tran_days` WHERE emp_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display tran days end */

    /* use for insert tran days Starts */
    function insertTranday($client,$tr_id,$emp,$smonth,$fp,$hp,$lw,$wo,$pr,$ab,$pl,$sl,$cl,$ol,$ph,$add,$oh,$ns,$extra_inc1,$extra_inc2,$leave_encash,$reward,$extra_ded1,$extra_ded2,$leftdate,$invalid,$comp_id,$user_id,$wagediff,$Allow_arrears,$Ot_arrears,$income_tax,$society,$canteen,$remarks){
        $i=0;
        foreach($emp as $e) {
          if($tr_id[$i]!=''){
			
            $sql = "UPDATE `tran_days` SET `user_id`='".$user_id."',`comp_id`='".$comp_id."',extra_inc1='" . $extra_inc1[$i] . "',extra_inc2='" . $extra_inc2[$i] . "',leave_encash='" . $leave_encash[$i] . "',reward='" . $reward[$i] . "', extra_ded1='" . $extra_ded1[$i] . "',extra_ded2='" . $extra_ded2[$i] . "',leftdate='" . $leftdate[$i] . "',invalid='" . $invalid[$i] . "', `comp_id`='".$comp_id."',`user_id`='".$user_id."',`emp_id`='".$emp[$i]."',`client_id`='".$client."',`sal_month`='".$smonth."',`fullpay`='".$fp[$i]."',`halfpay`='".$hp[$i]."',`leavewop`='".$lw[$i]."',`present`='".$pr[$i]."',`absent`='".$ab[$i]."',`weeklyoff`='".$wo[$i]."',`pl`='".$pl[$i]."',`sl`='".$sl[$i]."',`cl`='".$cl[$i]."',`otherleave`='".$ol[$i]."',`paidholiday`='".$ph[$i]."',`additional`='".$add[$i]."',`othours`='".$oh[$i]."',`nightshifts`='".$ns[$i]."',`db_update`=NOW(),`updated_by`='".$user_id."',`wagediff`='".$wagediff[$i]."',`Allow_arrears`='".$Allow_arrears[$i]."',`Ot_arrears` ='".$Ot_arrears[$i]."',`incometax` ='".$income_tax[$i]."',`society` ='".$society[$i]."',`canteen` ='".$canteen[$i]."',`remarks` ='".$remarks[$i]."' WHERE `trd_id`='".$tr_id[$i]."' ";

             $res = mysql_query($sql);
            }
            else {
            $sql = "INSERT INTO `tran_days`(`user_id`,`client_id`, `comp_id`, `emp_id`, `sal_month`, `fullpay`, `halfpay`, `leavewop`,`present`, `absent`, `weeklyoff`, `pl`, `sl`, `cl`, `otherleave`, `paidholiday`, `additional`, `othours`,`nightshifts`, `extra_inc1`, `extra_inc2`,leave_encash,reward, `extra_ded1`, `extra_ded2`, `leftdate`, `invalid`,`db_adddate`, `db_update`,`updated_by`,`wagediff`, `Allow_arrears`, `Ot_arrears`,incometax,society,canteen,remarks) VALUES('" . $user_id . "','" . $client . "','" .$comp_id  . "','" . $emp[$i]. "','" . $smonth . "','" . $fp[$i] . "','" . $hp[$i] . "','" . $lw[$i] . "','" . $pr[$i] . "','" . $ab[$i] . "','" . $wo[$i] . "','" . $pl[$i] . "','" . $sl[$i] . "','" . $cl[$i] . "','" . $ol[$i] . "','" . $ph[$i] . "','" . $add[$i] . "','" . $oh[$i] . "','" . $ns[$i] . "','" . $extra_inc1[$i] . "','" . $extra_inc2[$i] . "','" . $leave_encash[$i]. "','" . $reward[$i]. "','" . $extra_ded1[$i] . "','" . $extra_ded2[$i] . "','" . $leftdate[$i] . "','" . $invalid[$i] . "',NOW(),NOW(),'".$user_id."','".$wagediff[$i]."','".$Allow_arrears[$i]."','".$ot_arrears[$i]."','".$income_tax[$i]."','".$society[$i]."','".$canteen[$i]."','".$remarks[$i]."')";
              $res = mysql_query($sql);
            }
            $i++;
        }
      return $i;
    }
    /* use for insert tran days end */

    /* use for display COLUMNS name in employee table Starts */
    public function selectempstr(){
    //    $sql = "SELECT `COLUMN_NAME` FROM `INFORMATION_SCHEMA`.`COLUMNS` WHERE `TABLE_SCHEMA`='new_salary' AND `TABLE_NAME`='employee'";
        $sql = "SHOW COLUMNS FROM employee";

      //  $sql = "SELECT COLUMN_NAME FROM INFORMATION_SCHEMA.COLUMNS WHERE `TABLE_SCHEMA`='new_salary' AND TABLE_NAME = 'employee' AND COLUMN_NAME NOT IN ('emp_id','db_update','db_adddate')";
        $executequery1 = mysql_query($sql);
        $executequery = mysql_fetch_assoc($executequery1);
        print_r($executequery);
        return $executequery;
    }
    /* use for display COLUMNS name in employee table end */

    /* use for display COLUMNS name in employee table Starts */
    public function selectempstrdet(){
      $sql = "SHOW COLUMNS FROM employee";
        $executequery = mysql_query($sql);
           return $executequery;
    }
    /* use for display COLUMNS name in employee table end */

    /* use for update dynamic COLUMNS in employee table Starts */
    function updateAllemp($empid,$fielda,$fieldb,$fieldc,$fieldd,$texta,$textb,$textc,$textd,$comp_id,$user_id){
        $i = 0;

        foreach($empid as $id1) :

            if ($texta[$i]!='' && $textb[$i]!='' && $textc[$i]!='' && $textd[$i]!='') {

             $sql = "UPDATE employee SET `comp_id`='".$comp_id."',`user_id`='".$user_id."',$fielda='$texta[$i]',$fieldb='$textb[$i]',$fieldc='$textc[$i]',$fieldd='$textd[$i]',db_update=NOW() WHERE emp_id='" . $empid[$i] . "' ";
                mysql_query($sql);
            }

            $i++;

        endforeach;
//exit;
        return $i;

    }
    /* use for update dynamic COLUMNS in employee table end*/

    /* use for update dynamic COLUMNS in employee income table Starts */
    function updateAllempincome($emp_ic_id,$texta,$caltype,$textc,$comp_id,$user_id){
        $i = 0;

        foreach ($emp_ic_id as $id1) :

//            if ($texta[$i]!='' && $caltype[$i]!='' && $textc[$i]!='') {

     $sql = "UPDATE `emp_income` SET `comp_id`='".$comp_id."',`user_id`='".$user_id."',std_amt='$texta[$i]',calc_type='$caltype[$i]',remark='$textc[$i]',db_update=NOW()  WHERE emp_income_id='" . $emp_ic_id[$i] . "' ";
                mysql_query($sql);
//            }

            $i++;

        endforeach;

        return $i;

    }
    /* use for update dynamic COLUMNS in employee income table end */

    /* use for update dynamic COLUMNS in employee deduct table Starts */
   function updateAllempeduct($emp_de_id,$texta,$caltype,$textc,$comp_id,$user_id){
       $i = 0;

        foreach ($emp_de_id as $id1) :

         //   if ($texta[$i]!='' && $caltype[$i]!='' && $textc[$i]!='') {

             $sql = "UPDATE `emp_deduct` SET `comp_id`='".$comp_id."',`user_id`='".$user_id."',std_amt='$texta[$i]',calc_type='$caltype[$i]',remark='$textc[$i]',db_update=NOW()  WHERE emp_deduct_id='" . $emp_de_id[$i] . "' ";
                mysql_query($sql);
        //    }

            $i++;

        endforeach;

        return $i;

    }
    /* use for update dynamic COLUMNS in employee deduct table end */


    /* use for display client Starts */
    function getClientId($c){
       $sql = "select mast_client_id from mast_client WHERE client_name Like '%".$c."%' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_client_id'];
        }
    }
    /* use for display client end */

    /* use for display designation Starts */
    function getDesgId($desg){
       $sql = "select mast_desg_id from mast_desg WHERE mast_desg_name Like '%".$desg."%' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_desg_id'];
        }
    }
    /* use for display designation end */

    /* use for display department Starts */
    function getDeptId($dept){
        $sql = "select mast_dept_id from mast_dept WHERE mast_dept_name Like '%".$dept."%' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_dept_id'];
        }
    }
    /* use for display department end */
	
	/* use for display department Starts WHILE IMPORTING MASTER INFO TO EMPLOYEE FILE*/
    function getDeptIdemp($dept,$comp_id){
         $sql = "select mast_dept_id from mast_dept WHERE (mast_dept_name Like '%".$dept."%'  or dept Like '%".$dept."%') and comp_id = '".$comp_id."'";
	   
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_dept_id'];
        }
    }
    /* use for display department end */
	
	

    /* use for display qualification Starts */
    function getQualifId($qualif,$comp_id){
        $sql = "select mast_qualif_id from mast_qualif WHERE mast_qualif_name Like '%".$qualif."%' and comp_id = '".$comp_id."'" ;
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_qualif_id'];
        }
    }
    /* use for display qualification end */
function getDesgIdNew($desg_name,$comp_id){
        $sql = "select mast_desg_id from mast_desg WHERE mast_desg_name Like '%".$desg_name."%' and comp_id = '".$comp_id."'" ;
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_desg_id'];
        }
    }
    /* use for display designation end */

    /* use for display bank Starts */
    function getBankId($bank,$comp_id){
         $sql = "select mast_bank_id from mast_bank WHERE bank_name Like '%".$bank."%' and comp_id = '".$comp_id."'";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_bank_id'];
        }
    }
    /* use for display bank end */

    /* use for display location Starts */
    function getLocId($loc){
        $sql = "select mast_location_id from mast_location WHERE mast_location_name Like '%".$loc."%' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_location_id'];
        }
    }
    /* use for display location end */

    /* use for display paycode Starts */
    function getPayCId($payc){
        $sql = "select mast_paycode_id from mast_paycode WHERE mast_paycode_name Like '%".$payc."%' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row['mast_paycode_id'];
        }
    }
    /* use for display paycode end */

    /* use for delete emp income Starts */
    function deleteEmpincome($id){
        $sql = "DELETE FROM emp_income WHERE `emp_income_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
      
    /* use for delete emp income end */

    /* use for delete emp deduct Starts */
   function deleteEmpdeduct($id){
        $sql = "DELETE FROM emp_deduct WHERE `emp_deduct_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete emp deduct end */

    /* use for delete emp leave Starts */
    function deleteEmpleave($id){
        $sql = "DELETE FROM emp_leave WHERE `emp_leave_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete emp leave end */

    /* use for delete emp advnace Starts */
   function deleteEmpadvances($id){
        $sql = "DELETE FROM emp_advnacen WHERE `emp_advnacen_id`='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete emp advnace end */

    /* use for display emp income Starts */
    function displayEmpincome($id){
       $sql = "SELECT * FROM `emp_income` WHERE emp_id='".$id."'  ORDER BY `emp_income_id` ASC";
        $res = mysql_query($sql);
        return $res;
    }
     function displaydesgincome($client_id,$design_id){
       $sql = "SELECT * FROM `desg_income` WHERE desg_id='".$design_id."' and client_id='".$client_id."'  ORDER BY `id` ASC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income end */

    /* use for display emp income Starts */
    function displayDedincome($id){
       $sql = "SELECT * FROM `emp_deduct` WHERE emp_id='".$id."'  ORDER BY `emp_deduct_id` ASC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */

    /* use for display emp leave Starts */
    function displayEmpleave($id){
        $sql = "SELECT * FROM `emp_leave` WHERE emp_id='".$id."'  ORDER BY `emp_leave_id` ASC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp leave end */

    /* use for display emp advnace Starts */
    function displayAdvances($id){
        $sql = "SELECT * FROM `emp_advnacen` WHERE emp_id='".$id."'  ORDER BY `emp_advnacen_id` ASC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp advnace end */

    /* use for display emp income Starts */
    function showEployeeincomeall($id){
        $sql = "select * from `emp_income` WHERE emp_income_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp income end */

    /* use for display emp deduct Starts */
    function showEployeedeductall($id){
        $sql = "select * from emp_deduct WHERE `emp_deduct_id`='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp deduct end */

    /* use for display emp leave Starts */
    function showEployeeleaveall($id){
        $sql = "select * from `emp_leave` WHERE emp_leave_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp leave end */

    /* use for display emp advnace Starts */
    function showEployeeadnavcenall($id){
        $sql = "select * from `emp_advnacen` WHERE emp_advnacen_id='".$id."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display emp advnace end */

    /* use for display emp report with compid and userid Starts  */
    function showEmployeereport($comp_id,$user_id){
        $sql = "select * from employee where comp_id ='".$comp_id."' AND user_id='".$user_id."' ORDER BY Client_id,last_name,first_name,middle_name,Joindate ASC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp report with compid and userid end  */

    /* use for display tran emp with empid Starts  */
    function showtranhiEployeedetails($tab_emp,$id,$sal_month){
         $sql = "select * from $tab_emp WHERE emp_id='".$id."' and sal_month ='".$sal_month."'";
        $res = mysql_query($sql);
        $row=mysql_fetch_array($res);
        return $row;
    }
    /* use for display tran emp with empid end  */

	
	
	
	/* Income tax functions */
	 function updateintaxincome($id,$income_desc,$income_amt,$comp_id,$user_id){
        $sqlup=" UPDATE it_file2 SET user_id='".$user_id."',comp_id='".$comp_id."',income_desc='".$income_desc."',income_amt='".$income_amt."' WHERE id='".$id."' ";
        $resup = mysql_query($sqlup);
        return 1;
    }
    function insertintaxincome($empid,$income_desc,$income_amt,$comp_id,$user_id,$yr){
           $sql = "INSERT INTO it_file2 (user_id,comp_id,emp_id,income_desc,income_amt,year)VALUES('".$user_id."','".$comp_id."','" . $empid . "','" . $income_desc. "','" . $income_amt. "','" . $yr. "')";
        $res = mysql_query($sql);
        return $res;
    }

    function updateintaxallow($id,$allow_name,$allow_amt,$comp_id,$user_id){
        $sqlup=" UPDATE it_file2 SET user_id='".$user_id."',comp_id='".$comp_id."',allow_name='".$allow_name."',allow_amt='".$allow_amt."' WHERE id='".$id."' ";
        $resup = mysql_query($sqlup);
        return 1;
    }
    function insertintaxallow($empid,$allow_name,$allow_amt,$comp_id,$user_id,$yr){
           $sql = "INSERT INTO it_file2 (user_id,comp_id,emp_id,allow_name,allow_amt,year)VALUES('".$user_id."','".$comp_id."','" . $empid . "','" . $allow_name. "','" . $allow_amt. "','" . $yr. "')";
        $res = mysql_query($sql);
        return $res;
    }
   function updateintaxc($id,$c_desc,$c_amt,$comp_id,$user_id){
        $sqlup=" UPDATE it_file2 SET user_id='".$user_id."',comp_id='".$comp_id."',80C_desc='".$c_desc."',80c_amt='".$c_amt."' WHERE id='".$id."' ";
        $resup = mysql_query($sqlup);
        return 1;
    }
    function insertintaxc($empid,$c_desc,$c_amt,$comp_id,$user_id,$yr){
        $sql = "INSERT INTO it_file2 (user_id,comp_id,emp_id,80C_desc,80c_amt,year)VALUES('".$user_id."','".$comp_id."','" . $empid . "','" . $c_desc. "','" . $c_amt. "','" . $yr. "')";
        $res = mysql_query($sql);
        return $res;
    }
    function updateintaxchapter($id,$section_name,$gross_amt,$qual_amt,$deduct_amt,$comp_id,$user_id){
        $sqlup=" UPDATE it_file2 SET user_id='".$user_id."',comp_id='".$comp_id."',section_name='" . $section_name. "',gross_amt='".$gross_amt."',qual_amt='".$qual_amt."',deduct_amt='".$deduct_amt."' WHERE id='".$id."' ";
        $resup = mysql_query($sqlup);
        return 1;
    }
    function insertintaxchapter($empid,$section_name,$gross_amt,$qual_amt,$deduct_amt,$comp_id,$user_id,$yr){
        $sql = "INSERT INTO it_file2 (user_id,comp_id,emp_id,section_name,gross_amt,qual_amt,deduct_amt,year) VALUES ('".$user_id."','".$comp_id."','" . $empid . "','" . $section_name. "','" . $gross_amt. "','" . $qual_amt. "','" . $deduct_amt. "','" . $yr. "')";
        $res = mysql_query($sql);
        return $res;
    }

    function showintaxincome($empid){
       $sql = "select * from it_file2 where emp_id='" . $empid . "' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row;
        }
    }

    function showintax($id){
        $sql = "select * from it_file2 where id='" . $id . "' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row;
        }
    }


    /* use for display emp income Starts */
    function displayintax($id){
        $sql = "SELECT * FROM it_file2 WHERE emp_id='".$id."'  ORDER BY id DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */


    /* use for display emp income Starts */
    function displayintaxincome($id){
        $sql = "SELECT * FROM it_file2 WHERE emp_id='".$id."' AND (income_desc!='' OR income_amt!=0) ORDER BY id DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */

    /* use for display emp income Starts */
    function displayintaxallow($id){
        $sql = "SELECT * FROM it_file2 WHERE emp_id='".$id."' AND (allow_name!='' OR allow_amt!=0) ORDER BY id DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */

    /* use for display emp income Starts */
    function displayintaxc($id){
        $sql = "SELECT * FROM it_file2 WHERE emp_id='".$id."' AND (80C_desc!='' OR 80c_amt!=0) ORDER BY id DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */

      /* use for display emp income Starts */
    function displayintaxchapter($id){
        $sql = "SELECT * FROM it_file2 WHERE emp_id='".$id."' AND  (section_name!='' OR gross_amt!='0'  OR qual_amt!='0' OR deduct_amt!='0' )  ORDER BY id DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */



    /* use for delete emp income Starts */
    function deleteintax($id){
        $sql = "DELETE FROM it_file2  WHERE id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete emp income end */


    function insertitdeposit($chno,$status,$deposite_date,$salmonth,$comp_id,$user_id){
        $sql1 = "SELECT * FROM it_deposited WHERE comp_id ='".$comp_id."' AND user_id='".$user_id."' AND sal_month='".$salmonth."' ";
        $res1 = mysql_query($sql1);
        $row1 = mysql_fetch_assoc($res1);
        if(mysql_affected_rows()== 0){
            $sql = "INSERT INTO it_deposited(sal_month, comp_id, user_id, challan_no, deposite_date, oltas_status)VALUES('".$salmonth."','".$comp_id."','".$user_id."','" . $chno . "','" . $deposite_date. "','" . $status. "')";
            $res = mysql_query($sql);
            return $res;
        } else{
            return $row1;
        }


    }

    function updateitdeposit($id,$chno,$status,$deposite_date,$salmonth,$comp_id,$user_id){

        $sqlup=" UPDATE it_deposited SET user_id='".$user_id."',comp_id='".$comp_id."',sal_month='".$salmonth."',challan_no='".$chno."',deposite_date='".$deposite_date."',oltas_status='".$status."' WHERE id='".$id."' ";
        $resup = mysql_query($sqlup);
        return $resup;

    }

    /* use for display emp income Starts */
    function displayitdeposit($comp_id,$user_id){
        $sql = "SELECT * FROM it_deposited WHERE comp_id ='".$comp_id."' AND user_id='".$user_id."' ORDER BY id DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */
    /* use for display emp income Starts */
    function showCompdetails($comp_id,$user_id){
        $sql = "SELECT * FROM itconst WHERE comp_id ='".$comp_id."' AND user_id='".$user_id."' ORDER BY id DESC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display emp income Starts */


     /* use for display emp income Starts */
    function displayCompdetails($id){
        $sql = "SELECT * FROM itconst WHERE id='".$id."'";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        return $row;
    }
    /* use for display emp income Starts */

    /* use for delete client Starts  */
    function deleteitdeposit($id){
       $sql = "DELETE FROM it_deposited WHERE id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete client end */


     /* use for delete client Starts  */
    function deleteitCompanydetails($id){
       $sql = "DELETE FROM itconst WHERE id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for delete client end */


     /* use for insert Company details Starts  */
    function insertCompanydetails($fdate,$tdate,$assyr,$tdsc,$authp,$authd,$authmn,$bcrc,$qcn1,$qap1,$qade1,$qadp1,$qcn2,$qap2,$qade2,$qadp2,$qcn3,$qap3,$qade3,$qadp3,$qcn4,$qap4,$qade4,$qadp4,$prdate,$comp_id,$user_id){

      $sql1 = "SELECT * FROM itconst WHERE comp_id ='".$comp_id."' AND user_id='".$user_id."' AND from_date='".$fdate."'";
        $res1 = mysql_query($sql1);
        $row1 = mysql_fetch_assoc($res1);
     //   echo mysql_affected_rows();
        if(mysql_affected_rows()== 0){
        $sql = "INSERT INTO itconst(from_date, to_date, comp_id, user_id, tds_circle, Assment_year, auth_person, auth_desg, auth_mname, bsrcode,Q1_challan, Q1_amt_paid, Q1_amt_deducted, Q1_amt_deposited, Q2_challan, Q2_amt_paid, Q2_amt_deposited, Q2_amt_deducted, Q3_challan, Q3_amt_paid, Q3_amt_deposited,Q3_amt_deducted, Q4_challan, Q4_amt_paid, Q4_amt_deposited, Q4_amt_deducted, Printed_on) VALUES ('" . $fdate . "','" . $tdate . "','" . $comp_id . "','" . $user_id . "','" . $tdsc . "','" . $assyr . "','" . $authp . "','" . $authd . "','" . $authmn . "','" . $bcrc . "' ,'" . $qcn1 . "','" . $qap1. "','" . $qade1 . "','" . $qadp1 . "' ,'" . $qcn2 . "','" . $qap2. "','" . $qade2 . "','" . $qadp2 . "','" . $qcn3 . "','" . $qap3. "','" . $qade3. "','" . $qadp3 . "','" . $qcn4 . "','" . $qap4. "','" . $qade4 . "','" . $qadp4 . "' ,'" . $prdate . "' )";
         $res = mysql_query($sql);
            return $res;
        } else{

            return $row1;
        }

    }
    /* use for insert Company details end */

     /* use for insert Company details Starts  */
    function updateCompanydetails($id,$fdate,$tdate,$assyr,$tdsc,$authp,$authd,$authmn,$bcrc,$qcn1,$qap1,$qade1,$qadp1,$qcn2,$qap2,$qade2,$qadp2,$qcn3,$qap3,$qade3,$qadp3,$qcn4,$qap4,$qade4,$qadp4,$prdate,$comp_id,$user_id,$year){
        $sql1 = "SELECT * FROM itconst WHERE id!='".$id."' AND from_date='".$fdate."'";
        $res1 = mysql_query($sql1);
        $row1 = mysql_fetch_assoc($res1);
       // echo mysql_affected_rows();
        if(mysql_affected_rows()!= 0){
           $sql="UPDATE itconst SET from_date='".$fdate."',to_date='".$tdate."',tds_circle='".$tdsc."',Assment_year='".$assyr."',auth_person='".$authp."',auth_desg='".$authd."',auth_mname='".$authmn."',bsrcode='".$bcrc."',Q1_challan='".$qcn1."',Q1_amt_paid='".$qap1."',Q1_amt_deducted='".$qade1."',Q1_amt_deposited='".$qadp1."',Q2_challan='".$qcn2."',Q2_amt_paid='".$qap2."',Q2_amt_deducted='".$qade2."',Q2_amt_deposited='".$qadp2."',Q3_challan='".$qcn3."',Q3_amt_paid='".$qap3."',Q3_amt_deducted='".$qade3."',Q3_amt_deposited='".$qadp3."',Q4_challan='".$qcn4."',Q4_amt_paid='".$qap4."',Q4_amt_deducted='".$qade4."',Q4_amt_deposited='".$qadp4."',Printed_on='".$prdate."',year = '".$year."'  WHERE id='".$id."' ";
            $res = mysql_query($sql);
            return $res;
        } else{

            return $row1;
        }

    }
    /* use for insert Company details end */

    function displayitdepositdetails($id){
        $sql = "select * from it_deposited where id='" . $id . "' ";
        $res = mysql_query($sql);
        $row = mysql_fetch_assoc($res);
        if(mysql_affected_rows()== 0){
            return 0;
        } else{
            return $row;
        }
    }
   function insertotherinfo($empid,$year,$hsg_intrest,$ccc,$ccd,$ccf,$taxbenefit_87,$relief_89,$comp_id,$user_id)
   {
       $res1=$this->checkoutotherinfo($empid,$comp_id,$user_id);
       $row1 = mysql_fetch_assoc($res1);
       if(mysql_affected_rows()== 0) {
        $sql = "INSERT INTO it_file2(year, comp_id, user_id,emp_id,hsg_intrest,80ccc,80ccd,80ccf,relief_89,taxbenefit_87) VALUES ('" . $year . "','" . $comp_id . "','" . $user_id . "','" . $empid . "','" . $hsg_intrest . "' ,'" . $ccc . "','" . $ccd . "','" . $ccf . "','" . $relief_89 . "','" . $taxbenefit_87 . "')";
           $res = mysql_query($sql);
           return $res;
       }
       else{
        $sql = "update it_file2 set year='$year',hsg_intrest='$hsg_intrest',80ccc='$ccc',80ccd='$ccd',80ccf='$ccf',relief_89='$relief_89',taxbenefit_87='$taxbenefit_87' where id='".$row1['id']."'";
           $res = mysql_query($sql);
           return $res;
       }


   }

   public function checkoutotherinfo($empid,$comp_id,$user_id)
    {
        $sql1 = "SELECT * FROM it_file2 WHERE comp_id='" . $comp_id . "' AND emp_id='" . $empid . "' AND user_id='" . $user_id . "' AND (hsg_intrest>0 || 80ccc>0 || 80ccd>0 || 80ccf>0 || relief_89>0 || taxbenefit_87>0)";
        $res1 = mysql_query($sql1);
        return $res1;
    }
	
	
		/// vilas
	//get appoint employee details by client id for get printing purpose
	public function getEmployeeDetailsByClientIdAppont($clientid,$cmonth){
		$sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.gender,emp.esistatus,emp.emp_add1,emp.pin_code,emp.emp_id,emp.joindate,md.mast_desg_name ,emp.due_date
		from employee emp	 inner join mast_desg md on md.mast_desg_id = emp.desg_id 
		where emp.client_id='$clientid' and year(emp.joindate) = year('$cmonth') and month(emp.joindate) = month('$cmonth')
		";
		$res1 = mysql_query($sel1);
		return $res1;
	}
	//get employee income
	public function getEmployeeIncome($empid){		
		$sql2 ="select eimc.std_amt,eimc.calc_type, eimc.head_id,inchd.income_heads_name
		from emp_income eimc 
		inner join mast_income_heads inchd on eimc.head_id = inchd.mast_income_heads_id
		where emp_id ='".$empid."'";
		$res2 = mysql_query($sql2);
		return $res2;
	}
	//get employee deducts
	public function getEmployeeDeduction($empid){		
		 $sql2 ="select eded.std_amt, eded.head_id,dedhd.deduct_heads_name
		from emp_deduct eded 
		inner join mast_deduct_heads dedhd on eded.head_id = dedhd.mast_deduct_heads_id
		where eded.emp_id ='".$empid."'";
		$res2 = mysql_query($sql2);
		return $res2;
	}
	 /* use for display emp with empid Starts  */
    function showEployeedetailsQ($id){
       $sql = "select emp.*,md.mast_desg_name from employee emp inner join mast_desg md on emp.desg_id = md.mast_desg_id WHERE emp.emp_id='".$id."'";
        $res = mysql_query($sql);
		return $res;
    }
    /* use for display emp with empid end  */
		//use for convert number to words
	function convertNumberTowords($number){
		//$number = 190908100.25;
   $no = round($number);
   $point = round($number - $no, 2) * 100;
   $hundred = null;
   $digits_1 = strlen($no);
   $i = 0;
   $str = array();
   $words = array('0' => '', '1' => 'one', '2' => 'two',
    '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six',
    '7' => 'seven', '8' => 'eight', '9' => 'nine',
    '10' => 'ten', '11' => 'eleven', '12' => 'twelve',
    '13' => 'thirteen', '14' => 'fourteen',
    '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen',
    '18' => 'eighteen', '19' =>'nineteen', '20' => 'twenty',
    '30' => 'thirty', '40' => 'forty', '50' => 'fifty',
    '60' => 'sixty', '70' => 'seventy',
    '80' => 'eighty', '90' => 'ninety');
   $digits = array('', 'hundred', 'thousand', 'lakh', 'crore');
   while ($i < $digits_1) {
     $divider = ($i == 2) ? 10 : 100;
     $number = floor($no % $divider);
     $no = floor($no / $divider);
     $i += ($divider == 10) ? 1 : 2;
     if ($number) {
        $plural = (($counter = count($str)) && $number > 9) ? 's' : null;
        $hundred = ($counter == 1 && $str[0]) ? ' and ' : null;
        $str [] = ($number < 21) ? $words[$number] .
            " " . $digits[$counter] . $plural . " " . $hundred
            :
            $words[floor($number / 10) * 10]
            . " " . $words[$number % 10] . " "
            . $digits[$counter] . $plural . " " . $hundred;
     } else $str[] = null;
  }
  $str = array_reverse($str);
  $result = implode('', $str);
  $points = ($point) ?
    "." . $words[$point / 10] . " " . 
          $words[$point = $point % 10] : '';
 return  $result . " " . $points;
	}


	//get releave employee details by client id of current month 
	public function getEmployeeDetailsByClientId($clientid){
		$sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.gender,emp.emp_add1,emp.pin_code,emp.emp_id,emp.joindate,emp.leftdate
		from employee emp	
		where emp.client_id='$clientid' 
		";
		$res1 = mysql_query($sel1);
		return $res1;
	}
	function getDesigantion($designid){
		$sel1 ="select mast_desg_name from mast_desg where mast_desg_id='".$designid."'";
		$res1 = mysql_query($sel1);
		$row = mysql_fetch_assoc($res1);
		return $row['mast_desg_name'];
	}
	//to get da
	function pfDed($empId){
		$sel1 ="select std_amt,head_id from emp_income where emp_id='".$empId."' and head_id in(5,6) group by head_id";
		$res1 = mysql_query($sel1);
		$basic="";
		$orda="";
		//$row['std_amt'];
		while($row = mysql_fetch_array($res1)){			
				//$da += $row['std_amt'];	
				if($row['head_id']==5){
					$basic = $row['std_amt'];
				} if($row['head_id']==6){
					$orda = $row['std_amt'];
				}				
		}
		//echo $basic."==".$orda;
		if($orda !=""){
			//$basic =5800;
			//$orda =3256;
			$da = round(($basic + $orda)*12/100);
		}else{
			$da=0;
		}
		
		return $da;
		
	}
	function ptDed($emp){
		$sel1 ="select head_id from emp_deduct where emp_id ='".$emp."' and head_id='3'";
		$res1 = mysql_query($sel1);
	$row = mysql_fetch_assoc($res1);
	return $row['head_id'];
	}
	function pfComp($emp){
		$sel1 ="select std_amt,head_id from emp_income where emp_id='".$emp."' and head_id in(5,6) group by head_id";
		$res1 = mysql_query($sel1);
		$basic="";
		$orda="";
		//$row['std_amt'];
		while($row = mysql_fetch_array($res1)){			
				//$da += $row['std_amt'];	
				if($row['head_id']==5){
					$basic = $row['std_amt'];
				} if($row['head_id']==6){
					$orda = $row['std_amt'];
				}				
		}
		//echo $basic."==".$orda;
		if($orda !=""){
			//$basic =5800;
			//$orda =3256;
			$da = round(($basic + $orda)*12/100);
		}else{
			$da = round($basic*13.15/100);
		}
		
		return $da;
	}
	
/* use for display company details */
    function showCompdetailsById($comp_id){
        $sql = "SELECT * FROM mast_company WHERE comp_id ='".$comp_id."'";
        $res = mysql_query($sql);
		$row = mysql_fetch_assoc($res);
        return $row;
    }
	function getBonusType(){
		$sql = "SELECT * FROM caltype_bonus";
        $res = mysql_query($sql);
        return $res;
	}
	//for get bonus employee
	function getemployeeBonusById($emp,$startyear,$endyear,$clientid){
		$sql = "select * from bonus 	 
		 where emp_id = '".$emp."' and from_date='".$startyear."' and todate='".$endyear."' and client_id='$clientid' ";
		$row = mysql_query($sql);
		return $row;
	}
	//get releave employee details by client id for attendance 
	public function getEmployeeAllDetailsByClientId($clientid){
		$sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.gender,emp.gender,emp.bdate,mde.mast_desg_name, emp.joindate
		from employee emp inner join mast_desg mde on mde.mast_desg_id= emp.desg_id	
		where emp.client_id='$clientid' and (emp.leftdate IS NULL or emp.leftdate ='0000-00-00')
		";
		$res1 = mysql_query($sel1);
		return $res1;
	}

	

	public function getIncomeCalculationTypeByid($id){
		$sql = "select name from caltype_income 	 
		 where id = '".$id."'";
		$row = mysql_query($sql);
		$res = mysql_fetch_assoc($row);
		return $res['name'];
	}
	
	
// functions for cheque 	
	public function chkDetails($empid,$cmonth,$type){
		 $sql="select * from cheque_details where emp_id ='".$empid."' and sal_month = '".date("Y-m-d", strtotime($cmonth))."'
		and type = '".$type."'";
		
	    $res = mysql_query($sql);
		//$row = mysql_fetch_assoc($res);
		
		return $res;
	}
	
	public function getChequeEmployeeByClientId($clientid,$tab_emp,$month){
		  $sel1 ="select e.first_name,e.middle_name,e.last_name ,te.emp_id,te.netsalary 
		from $tab_emp te  inner join employee e on e.emp_id = te.emp_id where te.client_id='$clientid'  and te.pay_mode = 'C' and te.netsalary >0 and sal_month='$month' order by te.emp_id"; 
		
		$res1 = mysql_query($sel1);
	    //print_r($res1);
		return $res1;
	}
	public function getChequeEmployeeByEmpId($emp_id,$tab_emp,$month,$type){
		$sel1 ="select e.first_name,e.middle_name,e.last_name ,te.emp_id,te.netsalary 
		from $tab_emp te inner join employee e on e.emp_id = te.emp_id where te.emp_id = '$emp_id' and te.pay_mode = 'C' and te.netsalary >0 and sal_month='$month' order by te.emp_id"; 
		
		$res1 = mysql_query($sel1);
	    print_r($res1);
		return $res1;
	}
	public function delCheckDetails($id){
  		$sql ="delete from cheque_details where chk_detail_id='".$id."'";

		mysql_query($sql);
		return 1;
	}
	public function checkExistChequeDetails($empid,$salmonth,$type){
		$sql ="select count(*) cnt from cheque_details where emp_id='".$empid."' and sal_month='".$salmonth."' and type='".$type."'";
		$res = mysql_query($sql);
		$row = mysql_fetch_array($res);
		return $row[0]['cnt'];
	}
	function selectClientEmployee(){
        $sql = "select *,mc.client_name,md.mast_desg_name from client_employee ce inner join mast_client mc on ce.client_id=mc.mast_client_id
		inner join mast_desg md on ce.design_id=md.mast_desg_id ORDER BY client_id ASC ";
        $res = mysql_query($sql);
        return $res;
    }
    
    
    
	//get releave employee details by client id for attendance 
	public function getEmployeeAllDetailsByClientIdByLocation($clientid,$sal_month,$tab,$month){
	    if ($month !='previous')
            {
	    
		if ($clientid == 1 ||$clientid == 4 ||$clientid == 6 ){
		 $sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.gender,emp.gender,emp.bdate,mde.mast_desg_name, emp.joindate,emp.loc_id
		from employee emp inner join mast_desg mde on mde.mast_desg_id= emp.desg_id	
		where emp.client_id in (1,4,6)  and (emp.job_status != 'L') order by loc_id;
		";
		}
		else
		{
	 $sel1 ="select emp.emp_id,emp.first_name,emp.middle_name,emp.last_name,emp.gender,emp.gender,emp.bdate,mde.mast_desg_name, emp.joindate,emp.loc_id
		from employee emp inner join mast_desg mde on mde.mast_desg_id= emp.desg_id	
		where emp.client_id = $clientid  and (emp.job_status != 'L') order by emp_id;
		";
			
		}

}
else
{
		if ($clientid == 1 ||$clientid == 4 ||$clientid == 6 ){
		 $sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.gender,emp.gender,emp.bdate,mde.mast_desg_name, emp.joindate,emp.loc_id
		from $tab te inner join employee emp on emp.emp_id = te.emp_id inner join mast_desg mde on mde.mast_desg_id= emp.desg_id	
		where emp.client_id in (1,4,6)  and te.sal_month = '$sal_month' order by loc_id;
		";
		}
		else
		{
 	 $sel1 ="select emp.emp_id,emp.first_name,emp.middle_name,emp.last_name,emp.gender,emp.gender,emp.bdate,mde.mast_desg_name, emp.joindate,emp.loc_id
		from $tab te inner join employee emp  on emp.emp_id = te.emp_id inner join mast_desg mde on mde.mast_desg_id= emp.desg_id	
		where emp.client_id = $clientid  and te.sal_month = '$sal_month'  order by emp_id;
		";
			
		}

}
		$res1 = mysql_query($sel1);
		return $res1;
	}
	
	
	
	function selectedBanks($comp_id,$client_id,$field,$frdt,$tab_emp){
	$sql = "select distinct bank_id, mb.* from $tab_emp te inner join mast_bank mb on te.bank_id = mb.mast_bank_id where te.comp_id = '$comp_id' and  te.client_id in ($client_id) and $field = '$frdt' order by mb.bank_name ";  

        $res = mysql_query($sql);
        return $res;
	}

	function getLeaveDates($clientid){
		$sql = "select distinct payment_date from leave_details where client_id = '$clientid' order by payment_date desc";
        $res = mysql_query($sql);
        return $res;
		
	}
	
	
function selectedBanks_deduct($comp_id,$client_id,$field,$frdt,$tab_emp,$tab_deduct){
		 $sql = "select distinct tdd.bank_id, mb.* from $tab_deduct tdd inner join $tab_emp te on te.emp_id = tdd.emp_id and te.sal_month = tdd.sal_month inner join mast_bank mb on tdd.bank_id = mb.mast_bank_id where te.comp_id = '$comp_id' and  te.client_id = '$client_id' and tdd.bank_id>0 and  tdd.$field = '$frdt' order by mb.bank_name ";  
		
        $res = mysql_query($sql);
        return $res;
	}
	
	
function getdates($client_id){
		 $sql = "select distinct  payment_date from leave_details where client_id='$client_id' order by payment_date desc  ";  
		$res = mysql_query($sql);
        return $res;
	}
	

	public function getemployeeBonusByClient($client,$startyear,$endyear,$days){
		
		 $sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.emp_id,emp.joindate,emp.leftdate
		from employee emp	inner join bonus te on te.emp_id = emp.emp_Id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and (te.apr_payable_days + te.may_payable_days+te.jun_payable_days+te.jul_payable_days+te.aug_payable_days+te.sep_payable_days+te.oct_payable_days+te.nov_payable_days+te.dec_payable_days+te.jan_payable_days+te.feb_payable_days+te.mar_payable_days) >=$days and emp.prnsrno !='Y'";  

		$res1 = mysql_query($sel1);
		return $res1;
	}
	
	
	public function getTotBonusByClient($client,$startyear,$endyear,$days){
		
		 $sel1 ="select sum(te.tot_bonus_amt +te.tot_exgratia_amt ) as amount 
		from employee emp	inner join bonus te on te.emp_id = emp.emp_Id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and (te.apr_payable_days + te.may_payable_days+te.jun_payable_days+te.jul_payable_days+te.aug_payable_days+te.sep_payable_days+te.oct_payable_days+te.nov_payable_days+te.dec_payable_days+te.jan_payable_days+te.feb_payable_days+te.mar_payable_days) >=$days and emp.prnsrno !='Y'";  

		$res1 = mysql_query($sel1);
		return $res1;
	}
		
	public function getemployeeBonusByClientHold($client,$startyear,$endyear,$days){
		
	$sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.emp_id,emp.joindate,emp.leftdate
		from employee emp	inner join bonus te on te.emp_id = emp.emp_Id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and  emp.prnsrno ='Y'";  
				
		$res1 = mysql_query($sel1);
		return $res1;
	}


	public function getemployeeBonusByClientHoldTotal($client,$startyear,$endyear,$days){
		
	 $sel1 ="select sum(tot_bonus_amt+tot_exgratia_amt) as amount 	from employee emp	inner join bonus te on te.emp_id = emp.emp_Id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and  emp.prnsrno ='Y'";  
				
		$res1 = mysql_query($sel1);
		return $res1;
	}

		
	public function getemployeeBonusByClientlessdays($client,$startyear,$endyear,$days){
		
		 $sel1 ="select emp.first_name,emp.middle_name,emp.last_name,emp.emp_id,emp.joindate,emp.leftdate
		from employee emp	inner join bonus te on te.emp_id = emp.emp_Id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and (te.apr_payable_days + te.may_payable_days+te.jun_payable_days+te.jul_payable_days+te.aug_payable_days+te.sep_payable_days+te.oct_payable_days+te.nov_payable_days+te.dec_payable_days+te.jan_payable_days+te.feb_payable_days+te.mar_payable_days) <$days ";  
		$res1 = mysql_query($sel1);
		return $res1;
	}
		
	
			
function getadvdates($emp_id){
		$sql = "select distinct  date from emp_advnacen where emp_id='$emp_id' order by date desc  ";  
		
		$res = mysql_query($sql);
        return $res;
	}
	
	
	
		public function getBonusChequeEmployeeByEmpId($empid1,$frdt1,$to){
		$sql ="select e.first_name,e.middle_name,e.last_name ,te.emp_id,te.amount ,te.payment_date 
		from bonus te inner join employee e on e.emp_id = te.emp_id where te.pay_mode = 'C' and te.tot_bonus_amount+tot_exgratia_amt >0 and from_date = $frdt1 and todate=$to and te.emp_id = $empid1  order by te.emp_id"; 
		$res1 = mysql_query($sel1);
		//$res2 = mysql_fetch_array($res1);
		print_r($res1);
		return $res1;
		}
		
		public function getBonusChequeEmployeeByClientId($clientid,$tab_emp,$frdt1,$to){
			
			$sel1 ="select e.first_name,e.middle_name,e.last_name ,te.emp_id,te.tot_bonus_amt+te.tot_exgratia_amt as   amount from bonus te inner join employee e on e.emp_id = te.emp_id where te.pay_mode = 'C' and  te.client_id = $clientid and te.tot_bonus_amt+te.tot_exgratia_amt >0 and from_date = '$frdt1' and todate='$to' and e.prnsrno !='Y' and te.tot_payable_days >= '".$_SESSION['days']."' order by te.emp_id"; 

		$res1 = mysql_query($sel1);
	    //print_r($res1);
		return $res1;
		}
		
		public function chkBonusChequeDetails($emp,$frdt1,$to,$type){		
		$sel1="select * from cheque_details where emp_id =$emp and from_date = '$frdt1' and todate='$to' and type = '$type'";
		$res1 = mysql_query($sel1);
		return $res1;	
		
	}
	
		public function chkBonusDetails($empid,$frdt1,$to,$type){
		$sql="select * from cheque_details where emp_id ='".$empid."' and  from_date = '$frdt1' and to_date='$to'  and type = '".$type."'";
	    $res = mysql_query($sql);
		//$row = mysql_fetch_assoc($res);
		
		return $res;
	}


	
	/* use for display Other Payment with compid Starts  */
    function showOtherPayment($comp_id){
        $sql = "select * from mast_other_payment where comp_id ='".$comp_id."' ORDER BY `op_name` ASC";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for display Other Payment with compid end */
	
	/* use for insert OtherPayment Starts  */
    function insertOtherPayment($name,$comp_id,$user_id){
          $sql = "INSERT INTO `mast_other_payment`(op_name,comp_id,user_id,db_adddate,db_update) VALUES('".$name."','".$comp_id."','".$user_id."',NOW(),NOW())";
          $res = mysql_query($sql);
          return $res;
    }
    /* use for insert department end */

    
    /* use for delete OtherPayment Starts  */
    function deleteOtherPayment($did){
       $sql = "DELETE FROM `mast_other_payment` WHERE op_id='".$did."' ";
	   $res = mysql_query($sql);
        return $res;
    }
    /* use for delete OtherPayment end  */

    /* use for update OtherPayment with deptid Starts */
   function updateOtherPayment($did,$name,$comp_id,$user_id){
      $sql = "UPDATE `mast_other_payment` SET  `comp_id`='".$comp_id."',`user_id`='".$user_id."',`op_name`='".$name."' ,db_update=NOW() WHERE op_id='".$did."' ";
        $res = mysql_query($sql);
        return $res;
    }
    /* use for update OtherPayment   end */

    /* use for display OtherPayment with deptid Starts */
    function displayOtherPayment($did){
             $sql = "SELECT * FROM `mast_other_payment` WHERE op_id='".$did."' ";
             $res = mysql_query($sql);
             $row=mysql_fetch_array($res);
             return $row;
    }
    /* use for display OtherPayment with deptid end */
	
	
	function showOtherPaymentEmployee($clientid){	
	  //  $sql = "SELECT emp_id,first_name,middle_name,last_name FROM employee e WHERE job_status !='L' and client_id='".$clientid."'";		
	  $sql = "SELECT emp_id,first_name,middle_name,last_name FROM employee e WHERE client_id='".$clientid."' order by emp_id ";		
		$res = mysql_query($sql);		
		return $res;
    }
	
	function getOtherPaymentEmployee($empid,$billno,$optype,$clientid){		
		$sql = "SELECT * FROM op_details WHERE emp_id='".$empid."' and op_id='".$optype."' and client_id='".$clientid."'";	
		if($billno !=""){
			$sql .= " and bill_no='".$billno."'";
		}	
		//echo $sql;
		$res = mysql_query($sql);
		$row1 = mysql_fetch_assoc($res);		
		return $row1;
    }
	
	function checkEmpDetailsinOP($empid,$billno,$optype,$clientid){	
		$sql = "SELECT count(*) cnt FROM op_details WHERE emp_id='".$empid."' and bill_no='".$billno."' and op_id='".$optype."' and client_id='".$clientid."'";		
		$res = mysql_query($sql);
		$row1 = mysql_fetch_assoc($res);		
		return $row1['cnt'];
    }
	function deleteotherpaymentdetails($id){
		 $sql = "DELETE FROM `op_details` WHERE id='".$id."' ";
	   $res = mysql_query($sql);
        return $res;
	}
	function checkopdetails($amount,$billno,$emp,$client,$optype,$billdate){
		 $sql = "SELECT * FROM op_details WHERE emp_id='".$emp."' and op_id='".$optype."'and bill_no='".$billno."'";		
		$res = mysql_query($sql);
		$row1 = mysql_fetch_assoc($res);		
		return $row1;
	}
	
	function insertopdetails($amount,$billno,$emp,$client,$opid,$paymentdate){
		  $sql = "INSERT INTO `op_details`(op_id,client_id,emp_id,payment_date,amount,bill_no,db_adddate,db_update) VALUES('".$opid."','".$client."','".$emp."','".$paymentdate."','".$amount."','".$billno."',NOW(),NOW())";
          $res = mysql_query($sql);
          return $res;
	} 
	function updateopdetails($amount,$billno,$emp,$client,$opid,$paymentdate,$opdetailid){
		 $sql = "UPDATE `op_details` SET  `op_id`='".$opid."',`client_id`='".$client."',`emp_id`='".$emp."',payment_date='".$paymentdate."' ,amount='".$amount."',bill_no='".$billno."',db_update=NOW() WHERE id='".$opdetailid."' ";
        $res = mysql_query($sql);
        return $res;
	}
	function updateOtherPaymentDetails($id,$amount){
		$sql = "UPDATE `op_details` SET  amount='".$amount."',db_update=NOW() WHERE id='".$id."' ";
        $res = mysql_query($sql);
        return $res;
	}
	function getOpdetails($client_id,$invoiceno){	
		 $sql = "SELECT sum(round(od.amount,0)) total, mop.op_name name FROM op_details od inner join mast_other_payment mop on od.op_id = mop.op_id where od.client_id='".$client_id."' and od.bill_no = '".$invoiceno."' group by od.op_id";		
		$res = mysql_query($sql);
		return $res;
    }
	function getOpbildate($billno){	
		$sql = "SELECT payment_date FROM op_details where bill_no='".$billno."' limit 1";		
		$res = mysql_query($sql);
		$row1 = mysql_fetch_assoc($res);
		return $row1['payment_date'];
    }
	function lockBilldetails($billid,$op,$client){
		 $sql = "UPDATE `op_details` SET loc = '1' WHERE bill_no='".$billid."' and op_id='".$op."' and client_id='".$client."'";
        $res = mysql_query($sql);
        //return $res;
	}
	
	
	function savenewbillno($billno,$billdate,$newbillno,$newbilldate){
	 	 $sql = "UPDATE `op_details` SET bill_no = '$newbillno',payment_date ='$newbilldate'  WHERE bill_no='".$billno."' and payment_date = '$billdate' ";
        $res = mysql_query($sql);
	
        return $res;
	}
	
	function getOptype($clientid,$billno)
	{
	  $sql = "select  od.op_id,mop.op_name,sum(round(od.amount,0)) as amount,payment_date from op_details od  inner join mast_other_payment mop on mop.op_id = od.op_id where od.bill_no = '$billno' and od.client_id ='$clientid' group by od.op_id";
       $res = mysql_query($sql);
	 return $res;
		
	}
	
	function getEmpOpdetails($clientid,$invoice,$opid)
	{
	 $sql = "select  od.op_id, od.client_id, od.emp_id, od.payment_date, round(od.amount,0) as amount, od.bill_no, od.loc ,concat(e.first_name,' ',e.middle_name,' ' ,e.last_name) as emp_name from op_details od inner join employee e on od.emp_id = e.emp_id where od.bill_no = '$invoice' and od.client_id ='$clientid' and od.op_id = '$opid'";
       $res = mysql_query($sql);
	 return $res;
		
	}
	
	
	function selectedBanksforOP($comp_id,$client_id,$billno){
	$sql = "select distinct e.bank_id, mb.* from op_details  te inner join employee e on te.emp_id = e.emp_id inner join mast_bank mb on e.bank_id = mb.mast_bank_id where e.comp_id = '$comp_id' and  te.client_id in ($client_id) and bill_no = '$billno' order by mb.bank_name ";  

        $res = mysql_query($sql);
        return $res;
	}

	public function getChequeOpdetailseByClientId($clientid,$tab_emp,$invoiceno,$empid1){
	    if ($empid1>0)
	    {
    		  $sel1 ="select e.first_name,e.middle_name,e.last_name ,te.emp_id,sum(round(te.amount,0)) as amount
	    	from $tab_emp te  inner join employee e on e.emp_id = te.emp_id where te.client_id='$clientid' and te.emp_id ='$empid1'  and te.pay_mode = 'C' and te.amount >0 and invoiceno ='$invoiceno' order by te.emp_id"; 
	        
	    }
	    else
	    {
		  $sel1 ="select e.first_name,e.middle_name,e.last_name ,te.emp_id, sum(round(te.amount,0)) as amount
		from $tab_emp te  inner join employee e on e.emp_id = te.emp_id where te.client_id='$clientid'  and e.pay_mode = 'C' and te.amount >0 and te.bill_no ='$invoiceno' order by te.emp_id"; 
	    }
		$res1 = mysql_query($sel1);
	    //print_r($res1);
		return $res1;
	}

	public function opchkDetails($empid,$invoice,$type){
	 	 $sql="select * from cheque_details where emp_id ='".$empid."' and bill_no = '$invoice' and type = 'O' ";
		
	    $res = mysql_query($sql);
		//$row = mysql_fetch_assoc($res);
		
		return $res;
	}
	

	public function opcheckExistChequeDetails($empid,$invoiceno,$type){
		$sql ="select count(*) cnt from cheque_details where emp_id='".$empid."' and bill_no = '$invoiceno'";
		$res = mysql_query($sql);
		$row = mysql_fetch_array($res);
		return $row[0]['cnt'];
	}

    function updateBonusLock($client_id,$startbonusyear,$endbonusyear)
    {
        
  		 $sql = "UPDATE bonus SET  `locked`='1',updated=NOW() WHERE client_id = '$client_id' and from_date = '$startbonusyear' and todate = '$endbonusyear' ";
        $res = mysql_query($sql);
        return $res;
      
    }

	
}


?>