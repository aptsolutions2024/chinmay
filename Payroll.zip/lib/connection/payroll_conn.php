<?php
$config = array('DBUSER'=>'hrnewsuser',
                'DBPASS'=>'asfreshasever7!',
                'DBHOST'=>'localhost',
                'DBNAME'=> 'hopes_payroll');
	?> 