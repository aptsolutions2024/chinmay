<?php
session_start();
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
error_reporting(0);
//print_r($_POST);die;

//error_reporting(0);
//include_once('../source/lib/class/payroll_admin.php');
include_once('lib/class/payroll_admin.php');


$payrollAdmin = new payrollAdmin();


  $user = addslashes($_REQUEST['username']);
  $pass = addslashes($_REQUEST['password']);
$result_logins = $payrollAdmin->login($user,$pass);
$total=$result_logins[1];


if($total==1){
    $result_login=$result_logins[0];
    $_SESSION['log_id']=$result_login['log_id'];
    $_SESSION['log_type']=$result_login['login_type'];
    $_SESSION['fname']=$result_login['fname'];
    $_SESSION['comp_id']=$result_login['comp_id'];
    $_SESSION['emp_login_id']=$result_login['emp_id'];
    if($result_login['login_type']!=6){
    echo "<script>window.location.href='/user-home';</script>";exit();
    }else{
          echo "<script>window.location.href='/employee-home';</script>";exit(); 
    }
 
 }else{
       $_SESSION['error_code']='0014';
       echo "<script>window.location.href='/payroll';</script>";exit();
}
	 ?>

