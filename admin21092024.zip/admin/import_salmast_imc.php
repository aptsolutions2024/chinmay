<?php       
$con=mysql_connect("localhost","root","");
 mysql_select_db("new_imcon_salary",$con)
or die("Could not connect trial");

if(!$con){
    die('Could not connect: '.mysql_error());
}

 $filename ='d:/Imc_salm1csv.csv';
		$count=0;  
		$file = fopen($filename, "r");
		echo "Please wait.File is being uploaded.";
/*		$sql = "TRUNCATE `hist_employee`;";
		$result = mysql_query($sql);
		$sql = "TRUNCATE hist_income";
		$result = mysql_query($sql);
		$sql = "TRUNCATE  hist_deduct";
		$result = mysql_query($sql);
		$sql = "TRUNCATE  hist_days";
		$result = mysql_query($sql);*/
		
			
	    while ($emapData = fgetcsv($file,10000000, ",")) 
			
	    {
			
			if($count>7){
				echo $emapData[3];
				 $sqlemp = "select * from employee where ticket_no = lpad('".$emapData[3]."',6,'0')";
				$resemp = mysql_query($sqlemp);
                 $resemp1 = mysql_fetch_array($resemp);
				 $x = mysql_num_rows($resemp);
				 
			if ($x > 0){
                    				
					if($emapData[1]!=''){
							$sdate=date("Y-m-d", strtotime($emapData[1]));
								}
					else{
							$sdate='0000-00-00';
					}

					 $sql = "insert into hist_employee(`emp_id`, `sal_month`, `client_id`, `desg_id`, `dept_id`, `qualif_id`, `bank_id`, `loc_id`, `paycode_id`, `bankacno`, `esistatus`, `esino`, `pfno`, `comp_ticket_no`, `pay_mode`, `payabledays`, `gross_salary`, `tot_deduct`, `netsalary`, `comp_id`, `user_id`, `db_adddate`, `db_update` ) values ( '".$resemp1['emp_id']."','".$sdate."','".$resemp1['client_id']."','".$resemp1['desg_id']."','".$resemp1['dept_id']."','".$resemp1['qualif_id']."','".$resemp1['bank_id']."','".$resemp1['loc_id']."','".$resemp1['paycode_id']."','".addslashes( ($emapData[10]))."','".addslashes( ($emapData[26]))."' ,'".  addslashes( ($emapData[27]))."','".addslashes( ($emapData[24]))."','".$resemp1['comp_ticket_no']."','".addslashes( ($emapData[8]))."','".addslashes( ($emapData[38]))."','".addslashes( ($emapData[71]))."','".addslashes( ($emapData[97]))."','".addslashes( ($emapData[98]))."','2','3',now(),now())";					
					//$result = mysql_query($sql);
					
					$sql = "insert into hist_days (`emp_id`, `client_id`, `sal_month`, `present`, `absent`, `weeklyoff`, `pl`, `sl`, `cl`, `otherleave`, `paidholiday`, `additional`, `othours`, `nightshifts`, `extra_inc1`, `extra_ded1`, `wagediff`, `Allow_arrears`, `Ot_arrears`,  `comp_id`, `user_id` )values ('".$resemp1['emp_id']."','".$resemp1['client_id']."','".$sdate."','".addslashes( ($emapData[32]))."','".addslashes( ($emapData[36]))."','".addslashes( ($emapData[33]))."','".addslashes( ($emapData[35]+$emapData[42]))."','".addslashes( ($emapData[41]))."','0','0','".addslashes( ($emapData[34]))."','".addslashes( ($emapData[37]))."','".addslashes( ($emapData[44]))."','".addslashes( ($emapData[45]))."','".addslashes( ($emapData[61]))."','".addslashes( ($emapData[96]))."','".addslashes( ($emapData[50]))."','".addslashes( ($emapData[69]))."','".addslashes( ($emapData[70]))."','2','3')";
					//$result = mysql_query($sql);
				 
				 	if ($emapData[6] =="D"){$calc_type = 5;}
					if ($emapData[6] =="S"){$calc_type = 14;}
					if ($emapData[6] =="M"){$calc_type = 2;}

				//BASIC
				 $sql = " insert into hist_income (`emp_id`, `sal_month`, `head_id`, `calc_type`, `std_amt`, `amount` ) values ";
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','25','".$calc_type."','". addslashes(($emapData[31]))."','".addslashes(($emapData[47]))."'),";
				 //Overtime
				if ($emapData[49]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','31','".$calc_type."','". addslashes( ($emapData[49]))."','".addslashes(($emapData[67]))."'),";
				}
				 //wagediff
				if ($emapData[50]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','47','".$calc_type."','0','".addslashes(($emapData[50]))."'),";
				 }
				 //hra
				if ($emapData[51]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','27','".$calc_type."','". addslashes(($emapData[133]))."','".addslashes( ($emapData[51]))."'),";
				}
				 //ccalw
				if ($emapData[52]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','36','".$calc_type."','0','".addslashes(($emapData[52]))."'),";
				}
				//canteenalw
				if ($emapData[54]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','34','".$calc_type."','". addslashes(($emapData[134]))."','".addslashes(($emapData[54]))."'),";
				}
				//travelalw
				if ($emapData[55]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','35','".$calc_type."','". addslashes( ($emapData[135]))."','".addslashes(($emapData[55]))."'),";
				}
				//nightshiftalw
				if ($emapData[56]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','33','".$calc_type."','0','".addslashes( ($emapData[56]))."'),";
				}
				//attend alw
				if ($emapData[57]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','37','".$calc_type."','". addslashes( ($emapData[139]))."','".addslashes(($emapData[57]))."'),";
				}
				//educationalw
				if ($emapData[58]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','38','".$calc_type."','0','".addslashes( ($emapData[58]))."'),";
				}
				//washingalw
				if ($emapData[59]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','39','".$calc_type."','". addslashes( ($emapData[141]))."','".addslashes(($emapData[59]))."'),";
				}
				//otheralw
				if ($emapData[62]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','29','".$calc_type."','". addslashes( ($emapData[144]))."','".addslashes(($emapData[62]))."'),";
				}
				//allowarr
				if ($emapData[69]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','48','".$calc_type."','0','".addslashes( ($emapData[69]))."'),";
				}
				//otarr
				if ($emapData[70]>0){
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','49','".$calc_type."','0','".addslashes( ($emapData[70]))."'),";
				}
				//DA
				 $sql = $sql."('".$resemp1['emp_id']."','".$sdate."','26','".$calc_type."','". addslashes( ($emapData[132]))."','".addslashes( ($emapData[48]))."');";
				//$result = mysql_query($sql);
				 
				 
               
				$sql = "INSERT INTO `hist_deduct`( `emp_id`, `sal_month`, `head_id`, `calc_type`, `std_amt`, `amount`, `employer_contri_1`, `employer_contri_2`) VALUES";
				//PF
				if ($emapData[72]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','20','7','". addslashes( ($emapData[128]))."','".addslashes( ($emapData[72]))."','".addslashes( ($emapData[74]))."','".addslashes( ($emapData[75]))."'),";}
				//ESI
				if ($emapData[76]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','21','7','0','".addslashes( ($emapData[76]))."','".addslashes( ($emapData[78]))."','0'),";}
				//society
				if ($emapData[81]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','26','7','0','".addslashes( ($emapData[81]))."','0','0'),";}
				//bankloan
				if ($emapData[84]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate.	"','27','7','0','".addslashes( ($emapData[84]))."','0','0'),";}
				//canteen
				if ($emapData[88]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','24','7','0','".addslashes( ($emapData[88]))."','0','0'),";}
				//lwf
				if ($emapData[94]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','23','7','0','".addslashes( ($emapData[94]))."','".addslashes( ($emapData[95]))."','0'),";}
				//extra_ded1`
				if ($emapData[96]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','29','7','0','".addslashes( ($emapData[96]))."','0','0'),";}
				//incometax
				if ($emapData[126]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','34','7','0','".addslashes( ($emapData[126]))."','0','0'),";}
				//prof.tax
				if ($emapData[81]>0){
				$sql = $sql."('".$resemp1['emp_id']."','".$sdate."','22','7','0','".addslashes( ($emapData[81]))."','".addslashes( ($emapData[81]))."','0'),";}
				
				$sql = $sql."('0','".$sdate."','0','0','0','0','0','0');";
				echo $sql."<br>";
				//$result = mysql_query($sql);
				
            	if ($emapData[81]>0){
					$sql = "update hist_income hi set amount = '".addslashes( ($emapData[81]))."' where emp_id = 
					'".$resemp1['emp_id']."' and sal_month= '".$sdate."' and head_id = '22'
			}
			else
				{echo "<br> Not Found - ".$emapData[3]."<br>";}
			
	    }$count++;
		}
		
	    fclose($file);
        $sql = "delete from hist_deduct where head_id` = 0";
		$result = mysql_query($sql);
		
		/*$sql = "update hist_income hi inner join employee e on e.ticket_no =hi.ticketno set hi.emp_id =e.emp_id";
		$result = mysql_query($sql);

		$sql = "update hist_deduct hd inner join employee e on e.ticket_no =hd.ticketno set hi.emp_id =e.emp_id";
		$result = mysql_query($sql);
		
		$sql = "update hist_days hd inner join employee e on e.ticket_no =hd.ticketno set hi.emp_id =e.emp_id";
		$result = mysql_query($sql);*/
		
		if($count>1)
		{
			echo "<script type=\"text/javascript\">
					alert(\"CSV File has been successfully Imported.\");
 				</script>";
			
		}
		
		?>
		
