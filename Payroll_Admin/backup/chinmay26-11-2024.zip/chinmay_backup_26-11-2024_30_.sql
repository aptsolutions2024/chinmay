

CREATE TABLE `mast_advance_type` (
  `mast_advance_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `advance_type_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_advance_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_advance_type VALUES("1","SALARY ADV.","1","5","2017-09-14 12:48:09","2018-06-11 11:53:47");
INSERT INTO mast_advance_type VALUES("2","FESTIVAL ADV.","1","5","2017-09-14 12:50:47","2018-06-11 14:58:46");
INSERT INTO mast_advance_type VALUES("3","BANK LOAN","1","5","2017-09-25 11:40:05","2017-09-25 11:40:05");



CREATE TABLE `mast_bank` (
  `mast_bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bankcode` varchar(4) DEFAULT NULL,
  `bank_name` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `add1` text NOT NULL,
  `city` varchar(20) NOT NULL,
  `pin_code` varchar(10) NOT NULL,
  `ifsc_code` varchar(20) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` date NOT NULL,
  `db_update` date NOT NULL,
  PRIMARY KEY (`mast_bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_bank VALUES("1","","NOT APPLICABLE","-","-","-","-","-","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("2","","Corporation Bank","Chinchwad","Raka Chambers, Chinchwad Station, Midc Telco Road, Chinchwad, Pune ","Chinchwad, Pune, Mah","411019","CORP0000445","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("3","5760","Canara Bank","Byndoor Ii","MAIN ROAD BYNDOOR KUNDAPUR TQ KARNATAKA","Udupi","-","CNRB0010122","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("4","","CANARA BANK","Jarar","Mandi Road,, Jarar,dist : Agra (U.p.)","Jarar","283 104","CNRB0000375","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("5","","BANK OF INDIA","Savarde Branch","Pawar Saw Mill Building, Near New English -School Sawarde, Tal Chiplun Dist Ratnagiri","Sawarde (Maharashtra","-","BKID0001421","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("6","","BANK OF BARODA","Khandala","Opp. Panchayat Samiti Khandala,dist.-satara","Khandala","-","BARB0KHANDA","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("7","","BANK OF BARODA","Lonand","Bank Of Baroda 619 Navi Peth Lonand, Dist Satara","Lonand","415521","BARB0LONAND","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("8","","BANK OF BARODA","Chinchwad","Mumbai Pune Road H Al Colony, Pimpri Chinchwad","Pune","411018","BARB0VJCHIN","1","5","2024-09-30","2024-09-30");
INSERT INTO mast_bank VALUES("9","","AJARA URBAN COOPERATIVE BANK","Gokul Shirgaon","Gokul Shirgaon Manufacturing Association,new Building,plot No.p-40,ground Floor,midc,gokul Shirgaon,tal Karveer","Gokul Shirgaon","-","AJAR0000025","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("10","","ICICI BANK","Shirwal","Icici Bank Ltd., Shop No. 1 To 6, Amrut-vishva, Gat No.344-b, Kamala Ruia Nagar, A/p Shirwal, Taluka Khandala, Satara Dist., Maharashtra","Shirwal","412801","ICIC0002115","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("11","","IDBI","Wathar Bk","Kirti Complex,idbi Bank,wathar Bk Branch Tal Khandala Dist Satara","Khandala","-","IBKL0001412","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("12","","BANK OF MAHARASHTRA","Pimpode Bk","Kadam Bldg. Pimpode Bk., Tal Koregaon ","Pimpode","415525","MAHB0000293","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("13","","BANK OF MAHARASHTRA","Shirwal","Pansare Bldg Main Road, Tal Khandala ","Shirwal","412801","MAHB0000218","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("14","","BANK OF MAHARASHTRA","Masulkar Colony, Pune","Masulkar Colony, Pimpri , Pune ","Pune","411018","MAHB0001072","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("15","","BANK OF MAHARASHTRA","Akurdi, Pune","Kalbhor Bhavan, Pune Maumbai Rd, Akurdi, Pune ","Pune","411035","MAHB0000391","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("16","","BANK OF MAHARASHTRA","Mid Corporate Branch Kolhapur","517a/1,mahabank Building, Kawala Naka, Kolhapur","Kolhapur","-","MAHB0001575","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("17","","STATE BANK OF INDIA","Shirwal","Dist Satara, Maharashtra","Satara","412801","SBIN0002178","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("18","","STATE BANK OF INDIA","Khandala","Khandala,dt Satara,maharashtra ","Satara","423704","SBIN0007734","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("19","","STATE BANK OF INDIA","Chinchwad Gao Branch, Pune","Shop No.4 To 8, Ground Floor, Shop No.67 First Floor, Metropolitan Commercial Compex, Plot No.2, S.no.4270 B,oppo. Darshan Hall, Pimipri Chinchwad Link Road, Chinchwad, Pune, Dist Pune","Chinchwad","411033","SBIN0015706","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("20","","STATE BANK OF INDIA","Midc Area Chinchwad (Pune)","Old Mumbai Pune Road, Dhfc Complex, Chinchwad, Distt. Pune, Maharashtra","Pune","411044","SBIN0007736","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("21","","UNION BANK OF INDIA","Pune Chinchwad","Raka Chambers, Chinchwad Station, Midc Telco Road, Chinchwad,pune","Pimpri Chinchwad","411019","UBIN0904457","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("22","","UNION BANK OF INDIA","Khandala(pargaon)","Khandala Lonand Road Khandala Pargaon Khandala Pargaon Maharashtra","Khandala(pargaon)","-","UBIN0570800","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("23","","UNION BANK OF INDIA","Bhatagalli(lohara)","Lohara Patoda Road Atpostlohara Taluka Osmanabad Dist. Laturmaharashtra Pin","Lohara","413608","UBIN0550469","1","5","2024-10-01","2024-10-01");
INSERT INTO mast_bank VALUES("24","","THANE JANATA SAHAKARI BANK","Sambhaji Nagar Branch","Plot No.-g/p-83, "G" Block, Pimpri Industrial Area,village Akurdi, Opp. Rotary Club, Sambhaji Nagar, Pune ","Pimpri Chinchwad","411019","TJSB0000044","1","5","2024-10-01","2024-10-01");



CREATE TABLE `mast_category` (
  `mast_category_id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `mast_category_name` varchar(150) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`mast_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_category VALUES("1","NOT APPLICABLE","1","5","2024-09-30 03:40:09","2024-09-30 03:40:09");
INSERT INTO mast_category VALUES("2","SKILLED","1","5","2024-09-30 03:40:50","2024-09-30 03:40:50");
INSERT INTO mast_category VALUES("3","SEMI-SKILLED","1","5","2024-09-30 03:40:59","2024-09-30 03:40:59");
INSERT INTO mast_category VALUES("4","UNSKILLED","1","5","2024-09-30 03:41:12","2024-09-30 03:41:12");



CREATE TABLE `mast_client` (
  `mast_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `clientno` varchar(3) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `short_name` varchar(30) DEFAULT NULL,
  `client_add1` varchar(150) NOT NULL,
  `esicode` varchar(50) NOT NULL,
  `pfcode` varchar(25) NOT NULL,
  `tanno` varchar(50) NOT NULL,
  `panno` varchar(50) NOT NULL,
  `gstno` varchar(50) NOT NULL,
  `current_month` date NOT NULL,
  `group_id` int(3) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `valid_users` varchar(50) NOT NULL,
  `daywise_details` enum('Y','N') NOT NULL,
  `ser_charges` decimal(10,2) NOT NULL,
  `lwf_no` varchar(20) DEFAULT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_client VALUES("1","","CHINMAY HOSPITALITY SERVICES,PIMPRI","Pimp","145, Off, Old Mumbai - Pune Hwy, Kharalwadi, Pimpri Colony, Pune, Pimpri-Chinchwad, Maharashtra 411018","33000459910001001","PUPUN1004127000","-","AAJFC5132C","-","2024-11-30","2","1","7","pkhardekar@gmail.com","5,7","N","0.00","-","2024-09-30 03:14:28","2024-11-12 02:46:42");
INSERT INTO mast_client VALUES("2","","CHINMAY HOSPITALITY SERVICES,CHINCHWAD","Chin","Mumbai-Pune Road
Chinchwad, Pune 411 019.","33000459910001001","PUPUN1004127000","-","AAJFC5132C","-","2024-11-30","2","1","7","pkhardekar@gmail.com","5,7","N","0.00","-","2024-09-30 03:22:56","2024-11-12 02:46:32");
INSERT INTO mast_client VALUES("3","","CHINMAY HOSPITALITY SERVICES,KOLHAPUR","Kol.","E-25, M.I.D.C, Gokul Shirgoan, Kolhapur, Maharashtra 416234","33000459910001001","PUPUN1004127000","-","AAJFC5132C","-","2024-11-30","2","1","7","pkhardekar@gmail.com","5,7","N","0.00","-","2024-09-30 03:27:12","2024-11-12 02:46:21");
INSERT INTO mast_client VALUES("4","","CHINMAY HOSPITALITY SERVICES,SHIRWAL","Shir","PLOT NO I-9 & I-10 CHORDIA INDUSTRIAL PARK DHANGARWADI TAL:- KHANDALA ,DIST :- SATARA 415521","33330459910021001","PUPUN1004127000","-","AAJFC5132C","-","2024-11-30","2","1","7","pkhardekar@gmail.com","5,7","N","0.00","-","2024-09-30 03:29:31","2024-11-12 02:46:08");
INSERT INTO mast_client VALUES("5","","V.D.SHETTY","VDS","SAI SIDDHI PLOT NO 247/28 PRADHIKARAN NIGADI 411044","330000805811199","PUPUN0018631000","-","AAEFV5022H","-","2024-11-30","3","1","7","pkhardekar@gmail.com","5,7","N","0.00","-","2024-09-30 03:30:30","2024-11-12 02:46:56");



CREATE TABLE `mast_company` (
  `comp_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `comp_name` varchar(100) NOT NULL,
  `phone_no` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `logo` varchar(20) NOT NULL,
  `bankacno` varchar(25) NOT NULL,
  `td_string` varchar(350) NOT NULL,
  `addr_1` varchar(300) NOT NULL,
  `addr_2` text NOT NULL,
  `tel` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gstin` varchar(50) NOT NULL,
  `pan_no` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`comp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_company VALUES("1","0","Chinmay Hospitality Services","22222","Chinchwad-Pune","","asasa"," present,weeklyoff,  absent, pl,cl,sl , paidholiday,additional, othours, nightshifts,incometax,canteen,extra_inc1, extra_inc2,leave_encash,extra_ded1,extra_ded2, wagediff,Allow_arrears, Ot_arrears,invalid","","","XXXXXXXX","chinmay@gmail.com","27aaaaaaaaaaaaaaaa","AHPP00000","0000-00-00 00:00:00","0000-00-00 00:00:00");



CREATE TABLE `mast_deduct_heads` (
  `mast_deduct_heads_id` int(11) NOT NULL AUTO_INCREMENT,
  `deduct_heads_name` varchar(20) NOT NULL,
  `short_name` varchar(5) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_deduct_heads_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_deduct_heads VALUES("1","E.S.I.","ESI","1","5","2024-10-02 22:28:06","2024-10-02 22:28:06");
INSERT INTO mast_deduct_heads VALUES("2","P.F.","PF","1","5","2024-10-02 22:28:39","2024-10-02 22:28:39");
INSERT INTO mast_deduct_heads VALUES("3","PROF. TAX","PT","1","5","2024-10-02 22:28:54","2024-10-02 22:28:54");
INSERT INTO mast_deduct_heads VALUES("4","L.W.F.","LWF","1","5","2024-10-02 22:29:42","2024-10-02 22:29:42");
INSERT INTO mast_deduct_heads VALUES("5","TDS","TDS","1","5","2024-10-02 22:29:54","2024-10-02 22:29:42");



CREATE TABLE `mast_dept` (
  `mast_dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_dept_name` varchar(150) NOT NULL,
  `dept` varchar(4) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` varchar(50) DEFAULT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mast_dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_dept VALUES("1","NOT APPLICABLEE","","1","5","","2023-02-12 20:23:58","2024-09-16 23:41:38","");
INSERT INTO mast_dept VALUES("2","CANTEEN","","1","5","","2023-05-26 04:36:12","2024-10-19 22:27:34","");



CREATE TABLE `mast_desg` (
  `mast_desg_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_desg_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_desg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_desg VALUES("1","NOT APPLICABLE","1","5","2023-05-26 05:13:39","2024-09-30 03:38:43");
INSERT INTO mast_desg VALUES("2","COOK","1","5","2024-10-19 22:26:25","2024-10-19 22:26:25");
INSERT INTO mast_desg VALUES("3","ASST COOK ","1","5","2024-10-19 22:26:32","2024-10-19 22:26:32");
INSERT INTO mast_desg VALUES("4","HELPER","1","5","2024-10-19 22:26:41","2024-10-19 22:26:41");
INSERT INTO mast_desg VALUES("5","MANAGER","1","5","2024-10-19 22:26:48","2024-10-19 22:26:48");
INSERT INTO mast_desg VALUES("6","SUPERVISOR","1","5","2024-10-19 22:27:01","2024-10-19 22:27:01");
INSERT INTO mast_desg VALUES("7","C.BOY","1","5","2024-10-19 22:27:14","2024-10-19 22:27:14");



CREATE TABLE `mast_income_heads` (
  `mast_income_heads_id` int(11) NOT NULL AUTO_INCREMENT,
  `income_heads_name` varchar(50) NOT NULL,
  `short_name` varchar(5) NOT NULL,
  `deduct_esi` varchar(1) DEFAULT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_addate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`mast_income_heads_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_income_heads VALUES("1","BASIC","BASIC","","1","5","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("2","F.D.A. ","FDA","","1","5","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("3","V.D.A.","VDA","","1","5","2024-10-02 22:17:27","2024-10-02 22:17:27");
INSERT INTO mast_income_heads VALUES("4","H.R.A.","HRA","","1","5","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("5","TECHNICAL ALLOWANCE","TA","","1","5","2024-10-02 22:19:30","2024-10-02 22:19:30");
INSERT INTO mast_income_heads VALUES("6","ATTENDANCE ALLOWANCE","AA","","1","5","2024-10-02 22:20:06","2024-10-02 22:20:06");
INSERT INTO mast_income_heads VALUES("7","WASHING ALLOWANCE","WA","N","1","5","2024-10-02 22:23:09","2024-10-02 22:23:09");
INSERT INTO mast_income_heads VALUES("8","PETROL REIMBURSEMENT","PR","","1","5","2024-10-02 22:24:49","2024-10-02 22:24:49");
INSERT INTO mast_income_heads VALUES("9","COMMISSION","COM","","1","5","2024-10-02 22:25:30","2024-10-02 22:25:30");



CREATE TABLE `mast_leave_type` (
  `mast_leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_type_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_leave_type VALUES("1","Earn Leave","1","2","2017-07-13 11:21:15","2017-07-13 11:21:15");
INSERT INTO mast_leave_type VALUES("2","Casual Leave","1","2","2017-07-13 11:21:32","2017-07-13 11:21:32");
INSERT INTO mast_leave_type VALUES("3","Sick Leave","1","2","2017-07-13 11:21:44","2017-07-13 11:21:44");
INSERT INTO mast_leave_type VALUES("4","EARN LEAVE","2","3","2017-09-14 09:12:52","2017-09-14 09:12:52");
INSERT INTO mast_leave_type VALUES("5","CASUAL LEAVE","2","3","2017-09-14 09:16:48","2017-09-14 09:16:48");
INSERT INTO mast_leave_type VALUES("6","SICK LEAVE","2","3","2017-11-13 12:44:39","2017-11-13 12:44:39");

