

CREATE TABLE `mast_bank` (
  `mast_bank_id` int(11) NOT NULL AUTO_INCREMENT,
  `bankcode` varchar(4) DEFAULT NULL,
  `bank_name` varchar(100) NOT NULL,
  `branch` varchar(100) NOT NULL,
  `add1` text NOT NULL,
  `city` varchar(20) NOT NULL,
  `pin_code` varchar(10) NOT NULL,
  `ifsc_code` varchar(20) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` date NOT NULL,
  `db_update` date NOT NULL,
  PRIMARY KEY (`mast_bank_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_bank VALUES("1","","BOI 1989","miraj-sangli","sangli","sangli_miraj","416411","IFSC25373","1","5","2023-05-28","2024-09-16");
INSERT INTO mast_bank VALUES("2","","rbl","magarpatta city","hadapsar","hadapsar-pune","3432","rbl0056741","1","4","2023-05-28","2023-05-30");
INSERT INTO mast_bank VALUES("3","","axis","dsf","mumbai","dsfsdf","32423","dsfs","1","4","2023-05-28","2023-05-30");
INSERT INTO mast_bank VALUES("4","","state bank of india ","kothrud ","kothud,anand nagar","pun","411038","sbl23456","1","4","2023-05-29","2023-05-29");
INSERT INTO mast_bank VALUES("5","","demo","HGFC GHJBN RETRETGH","GFD TGJH  SRESDGV BHJB TFYVJHBNMX4REDTFG","UYTF","9875421","986521","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("6","","TEST BANK","MIRAJ","test","SANGLI","416410","IFSC1234","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("7","","XYZ","Xb1","X1234","Xsangli","X123455","Xifsc1","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("8","","PQR BANK","PUNE VITTHALWADI","SWAGET","PUNE","456689","IFSC7899","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("9","","ABCDEFG","weq","wqeqw","qq","qq","wwq","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("10","","BANK OF INDIA","SHIVAJI MANDAI","SANGLI","SANGLI","123456","IFSC12345","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("11","","aaaaaaaaaa1111","bbbbb","aa","qqqq","2222","3333333","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("12","","kjdb kjhk","kjhkjh","kjhkjh","3b","6542","57653","1","5","2024-09-16","2024-09-16");
INSERT INTO mast_bank VALUES("13","","test ","test","test","test","1212","1221222","1","5","2024-09-17","2024-09-17");



CREATE TABLE `mast_category` (
  `mast_category_id` tinyint(3) NOT NULL AUTO_INCREMENT,
  `mast_category_name` varchar(150) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`mast_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_category VALUES("1","DEMOQWE","1","5","2024-09-01 22:25:13","2024-09-01 22:32:02");
INSERT INTO mast_category VALUES("2","CATEGORY 2","1","5","2024-09-01 22:32:41","2024-09-01 22:32:41");
INSERT INTO mast_category VALUES("3","CATEGORY 3","1","5","2024-09-01 22:32:46","2024-09-01 22:32:46");
INSERT INTO mast_category VALUES("4","ABCD","1","5","2024-09-01 23:38:59","2024-09-01 23:39:24");
INSERT INTO mast_category VALUES("5","DEMO2","1","5","2024-09-16 03:32:59","2024-09-16 03:33:09");
INSERT INTO mast_category VALUES("6","AIM11","1","5","2024-09-16 23:49:21","2024-09-16 23:49:31");
INSERT INTO mast_category VALUES("7","11112","1","5","2024-09-17 00:47:10","2024-09-17 00:47:22");



CREATE TABLE `mast_client` (
  `mast_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `clientno` varchar(3) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `short_name` varchar(30) DEFAULT NULL,
  `client_add1` varchar(150) NOT NULL,
  `esicode` varchar(50) NOT NULL,
  `pfcode` varchar(25) NOT NULL,
  `tanno` varchar(50) NOT NULL,
  `panno` varchar(50) NOT NULL,
  `gstno` varchar(50) NOT NULL,
  `current_month` date NOT NULL,
  `group_id` int(3) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `valid_users` varchar(50) NOT NULL,
  `daywise_details` enum('Y','N') NOT NULL,
  `ser_charges` decimal(10,2) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_client VALUES("1","","CHINMAY HOSPITALITY SERVICES,PUNE","chinmay_pune","Pune","e1234","p123","t123","pan1234","g123","2023-12-31","1","1","5","","5","Y","0.00","0000-00-00 00:00:00","2024-09-16 03:29:09");
INSERT INTO mast_client VALUES("2","","CHINMAY HOSPITALITY SERVICES,SHIRVAL","chinmay_shirval","Shirval","567890dfsdfs","-","-","13517213","-","2024-09-30","13","1","5","sdddf@gmail.com","5","N","123.00","2023-05-26 04:34:26","2024-09-23 02:33:19");
INSERT INTO mast_client VALUES("3","","CHINMAY HOSPITALITY SERVICES,KOLHAPUR","chinmay_kolhapur","Kolhapur","123456","123","-","1234567","-","2025-12-31","13","1","5","-","5","Y","0.00","2023-05-26 04:49:16","2024-09-23 02:33:31");
INSERT INTO mast_client VALUES("9","","ABCDD","","A","AS1234","P1234","T1234","PAN1234","G1234","2024-09-01","12","1","5","","5","Y","23.30","2024-09-16 02:52:14","2024-09-16 03:22:06");
INSERT INTO mast_client VALUES("10","","ABCDPPP","","e","1234","12345","457","1111111111","111111111111111","2024-05-01","14","1","5","sjafbsd@gmail.om","5","Y","0.00","2024-09-16 23:36:17","2024-09-16 23:38:55");
INSERT INTO mast_client VALUES("11","","DJGHBJN","","kjnm","jhjmn","6512","230512","5132854132","854253","1970-01-01","12","1","0","","5","Y","5465.00","2024-09-17 00:20:05","2024-09-17 00:20:05");
INSERT INTO mast_client VALUES("12","","SKDJNM ","","kjnm ","65412","654321","864531","8766","68","2023-05-01","1","1","0","iejhnkdc@gmail.com","5","Y","0.00","2024-09-17 00:27:20","2024-09-17 00:27:20");
INSERT INTO mast_client VALUES("13","","ABCDEFSK","","ljnm","421","412","45120","2222222222","222222222222222","2024-02-01","1","1","0","lkald@gmail.com","5","Y","0.00","2024-09-17 00:31:15","2024-09-17 00:31:15");
INSERT INTO mast_client VALUES("14","",",KSJMN ","","ljkn,m","74512","8654321","864521","8465321865","865865865485264","2024-04-01","12","1","0","jagtapsakshi1234@gmail.com","5","Y","0.00","2024-09-17 00:33:15","2024-09-17 00:33:15");
INSERT INTO mast_client VALUES("15","","KDJFX","","KJNM ","7541","7541","75421","85421","75421","2022-08-01","12","1","0","DRJGFNVM@GMAIL.COM","5","Y","0.00","2024-09-17 01:21:37","2024-09-17 01:21:37");
INSERT INTO mast_client VALUES("16","","DEMMMMMMDD","","875421","865320","5632","986532985632","56325632","96532632","2022-09-01","12","1","5","UFJKDXN@GMAIL.COM","5","Y","0.00","2024-09-17 01:22:13","2024-09-17 20:11:37");



CREATE TABLE `mast_company` (
  `comp_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `comp_name` varchar(100) NOT NULL,
  `phone_no` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `logo` varchar(20) NOT NULL,
  `bankacno` varchar(25) NOT NULL,
  `td_string` varchar(350) NOT NULL,
  `addr_1` varchar(300) NOT NULL,
  `addr_2` text NOT NULL,
  `tel` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gstin` varchar(50) NOT NULL,
  `pan_no` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`comp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_company VALUES("1","0","Chinmay Hospitality Services","22222","Chinchwad-Pune","","asasa","present,weeklyoff,  absent, pl,cl,sl , paidholiday,additional, othours, nightshifts,incometax,canteen,extra_inc1, extra_inc2,leave_encash,extra_ded1,extra_ded2, wagediff,Allow_arrears, Ot_arrears,invalid","","","XXXXXXXX","chinmay@gmail.com","27aaaaaaaaaaaaaaaa","AHPP00000","0000-00-00 00:00:00","0000-00-00 00:00:00");



CREATE TABLE `mast_deduct_heads` (
  `mast_deduct_heads_id` int(11) NOT NULL AUTO_INCREMENT,
  `deduct_heads_name` varchar(20) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_deduct_heads_id`)
) ENGINE=InnoDB AUTO_INCREMENT=999 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_deduct_heads VALUES("20","P.F.","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("21","E.S.I.","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("22","PROF. TAX","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("23","L.W.F.","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("24","CANTEEN","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("25","TRANSPORT","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("26","SOCIETY","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("27","BANK LOAN","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("28","COMP. LOAN","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("29","DEDUCT-1","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("30","DEDUCT-2","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("34","INCOMETAX","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("998","R.OFF","1","5","2018-07-11 12:54:47","2018-07-11 12:54:47");



CREATE TABLE `mast_dept` (
  `mast_dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_dept_name` varchar(150) NOT NULL,
  `dept` varchar(4) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` varchar(50) DEFAULT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mast_dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_dept VALUES("1","NOT APPLICABLEE","","1","5","","2023-02-12 20:23:58","2024-09-16 23:41:38","");
INSERT INTO mast_dept VALUES("2","Canteen","","1","4","","2023-05-26 04:36:12","2023-05-30 23:00:00","");
INSERT INTO mast_dept VALUES("14","DEMO","","1","5","","2024-09-16 03:27:27","2024-09-16 03:27:48","");
INSERT INTO mast_dept VALUES("15","TESTING DEPT","","1","5","","2024-09-16 23:39:32","2024-09-17 00:16:09","");
INSERT INTO mast_dept VALUES("16","DEM111","","1","5","","2024-09-17 00:12:32","2024-09-17 00:17:54","");
INSERT INTO mast_dept VALUES("17","1234","","1","5","","2024-09-17 00:13:38","2024-09-17 00:13:38","");
INSERT INTO mast_dept VALUES("18","DEMO123","","1","5","","2024-09-17 00:15:04","2024-09-17 00:15:04","");
INSERT INTO mast_dept VALUES("19","1234","","1","5","","2024-09-17 00:15:37","2024-09-17 00:15:37","");



CREATE TABLE `mast_desg` (
  `mast_desg_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_desg_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_desg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_desg VALUES("1","MANAGER123","1","4","2023-05-26 05:13:39","2023-05-26 05:13:54");
INSERT INTO mast_desg VALUES("2","SUPERVISER-MANUFACTURING","1","4","2023-05-28 22:02:18","2023-05-28 22:03:07");
INSERT INTO mast_desg VALUES("3","IT COORDINATOR","1","4","2023-05-30 23:05:36","2023-05-30 23:05:36");
INSERT INTO mast_desg VALUES("4","NETWORK ADMINISTRATOR","1","4","2023-05-30 23:05:55","2023-05-30 23:05:55");
INSERT INTO mast_desg VALUES("5","NETWORK ENGINEER","1","4","2023-05-30 23:06:14","2023-05-30 23:06:14");
INSERT INTO mast_desg VALUES("6","SERVICE DESK ANALYST","1","4","2023-05-30 23:06:58","2023-05-30 23:06:58");
INSERT INTO mast_desg VALUES("7","COMPUTER SYSTEM MANAGER","1","4","2023-05-30 23:07:39","2023-05-30 23:07:39");
INSERT INTO mast_desg VALUES("8","DEMO11","1","5","2024-09-16 03:32:25","2024-09-16 03:32:43");
INSERT INTO mast_desg VALUES("9","TESTING DESIGNATION","1","5","2024-09-16 23:43:34","2024-09-16 23:48:12");
INSERT INTO mast_desg VALUES("10","AIM11","1","5","2024-09-17 00:45:38","2024-09-17 00:45:49");



CREATE TABLE `mast_income_heads` (
  `mast_income_heads_id` int(11) NOT NULL AUTO_INCREMENT,
  `income_heads_name` varchar(50) NOT NULL,
  `deduct_esi` varchar(1) DEFAULT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_addate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`mast_income_heads_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_income_heads VALUES("1","BASIC","","1","5","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("2","D.A. ","","1","5","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("3","H.R.A.","","1","5","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("4","INCENTIVE","","1","5","2017-09-14 00:00:00","2018-08-21 12:06:08");
INSERT INTO mast_income_heads VALUES("5","OTHER ALW","","1","5","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("6","WASHING ALW","","1","5","2017-09-14 00:00:00","2017-12-19 13:13:47");
INSERT INTO mast_income_heads VALUES("7","OVERTIME","","1","5","2017-09-18 00:00:00","2017-09-18 00:00:00");
INSERT INTO mast_income_heads VALUES("8","PAP. ALW","","1","5","2017-09-21 00:00:00","2017-09-21 00:00:00");
INSERT INTO mast_income_heads VALUES("9","NIGHT SFT.","","1","5","2017-09-21 00:00:00","2017-09-21 00:00:00");
INSERT INTO mast_income_heads VALUES("10","CANTEEN ALW","","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("11","CONVEYANCE","","1","5","0000-00-00 00:00:00","2018-08-29 10:51:47");
INSERT INTO mast_income_heads VALUES("12","C.C.ALW","","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("13","ATTEND. ALW","","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("14","EDU. ALW","","1","5","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("15","P.L.P. ALW","","1","5","2017-11-08 18:14:06","2017-12-19 13:12:26");
INSERT INTO mast_income_heads VALUES("16","MEDICAL","","1","5","2017-11-08 18:15:11","2017-11-08 18:15:11");
INSERT INTO mast_income_heads VALUES("34","Income-1","","1","5","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("36","OT. AARREARS","","1","5","2017-11-29 11:09:26","2020-03-12 10:15:28");
INSERT INTO mast_income_heads VALUES("37","ALW ARREARS","","1","5","2017-11-29 11:09:42","2017-11-29 11:09:42");
INSERT INTO mast_income_heads VALUES("38","WAGE DIFF","","1","5","2017-11-29 11:09:57","2017-11-29 11:09:57");
INSERT INTO mast_income_heads VALUES("39","PETROL ALW","","1","5","2018-01-13 12:15:24","2018-01-13 12:15:24");
INSERT INTO mast_income_heads VALUES("41","SUPPLMENT ALW","","1","5","2018-02-21 11:03:07","2018-07-06 13:51:12");
INSERT INTO mast_income_heads VALUES("46","Income-2","N","1","5","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("47","LEAVE ENCASHMENT","N","1","5","2018-08-03 11:47:31","2018-08-03 11:47:31");
INSERT INTO mast_income_heads VALUES("50","BONUS","","1","5","2019-09-04 16:51:28","2019-09-07 10:17:50");
INSERT INTO mast_income_heads VALUES("51","ADDL. ALW.","","1","5","2019-09-09 10:35:32","2019-09-13 14:17:48");
INSERT INTO mast_income_heads VALUES("53","REWARD AMT.","","1","5","2020-02-10 13:46:56","2020-02-10 13:46:56");
INSERT INTO mast_income_heads VALUES("55","LEAVE ENCASH.","","1","5","2020-02-10 13:47:27","2020-02-10 13:47:27");
INSERT INTO mast_income_heads VALUES("56","OVERTIME OCT 2019","","1","5","2020-03-05 13:59:03","2020-03-05 13:59:03");
INSERT INTO mast_income_heads VALUES("57","CONSOLIDATED SALARY ","","1","5","2021-09-01 02:01:34","2021-09-01 02:21:21");



CREATE TABLE `mast_leave_type` (
  `mast_leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_type_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_leave_type VALUES("1","Earn Leave","1","2","2017-07-13 11:21:15","2017-07-13 11:21:15");
INSERT INTO mast_leave_type VALUES("2","Casual Leave","1","2","2017-07-13 11:21:32","2017-07-13 11:21:32");
INSERT INTO mast_leave_type VALUES("3","Sick Leave","1","2","2017-07-13 11:21:44","2017-07-13 11:21:44");
INSERT INTO mast_leave_type VALUES("4","EARN LEAVE","2","3","2017-09-14 09:12:52","2017-09-14 09:12:52");
INSERT INTO mast_leave_type VALUES("5","CASUAL LEAVE","2","3","2017-09-14 09:16:48","2017-09-14 09:16:48");
INSERT INTO mast_leave_type VALUES("6","SICK LEAVE","2","3","2017-11-13 12:44:39","2017-11-13 12:44:39");



CREATE TABLE `mast_location` (
  `mast_location_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_location_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_location VALUES("1","PUNE-AUNDH","1","4","2023-05-26 05:14:10","2023-05-26 05:14:27");
INSERT INTO mast_location VALUES("2","PUNE-SADASHIV PETH","1","4","2023-05-28 22:03:31","2023-05-28 22:04:33");
INSERT INTO mast_location VALUES("3","BANGALORE","1","4","2023-05-30 23:10:37","2023-05-30 23:10:37");
INSERT INTO mast_location VALUES("4","BHUBANESHWAR","1","4","2023-05-30 23:10:56","2023-05-30 23:10:56");
INSERT INTO mast_location VALUES("5","CHANDIGARH","1","4","2023-05-30 23:11:07","2023-05-30 23:11:07");
INSERT INTO mast_location VALUES("6","CHENNAI","1","4","2023-05-30 23:11:22","2023-05-30 23:11:22");
INSERT INTO mast_location VALUES("7","HUBLI","1","4","2023-05-30 23:11:29","2023-05-30 23:11:29");
INSERT INTO mast_location VALUES("8","INDORE","1","4","2023-05-30 23:11:38","2023-05-30 23:11:38");
INSERT INTO mast_location VALUES("9","JAIPUR","1","4","2023-05-30 23:11:49","2023-05-30 23:11:49");
INSERT INTO mast_location VALUES("10","MANGALORE","1","4","2023-05-30 23:11:59","2023-05-30 23:11:59");
INSERT INTO mast_location VALUES("11","MOHALI","1","4","2023-05-30 23:12:11","2023-05-30 23:12:11");
INSERT INTO mast_location VALUES("12","MUMBAI","1","4","2023-05-30 23:12:24","2023-05-30 23:12:24");
INSERT INTO mast_location VALUES("13","TIRUANANTHAPURAM","1","4","2023-05-30 23:12:49","2023-05-30 23:12:49");
INSERT INTO mast_location VALUES("14","MYSORE","1","4","2023-05-30 23:13:11","2023-05-30 23:13:11");

