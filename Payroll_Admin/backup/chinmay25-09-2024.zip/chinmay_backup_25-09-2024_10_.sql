

CREATE TABLE `bonus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_date` date NOT NULL,
  `todate` date NOT NULL,
  `client_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bankacno` varchar(30) NOT NULL,
  `pay_mode` varchar(1) NOT NULL,
  `tot_bonus_amt` float NOT NULL,
  `tot_exgratia_amt` float NOT NULL,
  `tot_payable_days` decimal(10,0) DEFAULT NULL,
  `calc_type` float NOT NULL,
  `apr_wages` float NOT NULL,
  `apr_bonus_wages` float NOT NULL,
  `apr_payable_days` float NOT NULL,
  `apr_bonus_amt` float NOT NULL,
  `apr_exgratia_amt` float NOT NULL,
  `may_wages` float NOT NULL,
  `may_bonus_wages` float NOT NULL,
  `may_payable_days` float NOT NULL,
  `may_bonus_amt` float NOT NULL,
  `may_exgratia_amt` float NOT NULL,
  `jun_wages` float NOT NULL,
  `jun_bonus_wages` float NOT NULL,
  `jun_payable_days` float NOT NULL,
  `jun_bonus_amt` float NOT NULL,
  `jun_exgratia_amt` float NOT NULL,
  `jul_wages` float NOT NULL,
  `jul_bonus_wages` float NOT NULL,
  `jul_payable_days` float NOT NULL,
  `jul_bonus_amt` float NOT NULL,
  `jul_exgratia_amt` float NOT NULL,
  `aug_wages` float NOT NULL,
  `aug_bonus_wages` float NOT NULL,
  `aug_payable_days` float NOT NULL,
  `aug_bonus_amt` float NOT NULL,
  `aug_exgratia_amt` float NOT NULL,
  `sep_wages` float NOT NULL,
  `sep_bonus_wages` float NOT NULL,
  `sep_payable_days` float NOT NULL,
  `sep_bonus_amt` float NOT NULL,
  `sep_exgratia_amt` float NOT NULL,
  `oct_wages` float NOT NULL,
  `oct_bonus_wages` float NOT NULL,
  `oct_payable_days` float NOT NULL,
  `oct_bonus_amt` float NOT NULL,
  `oct_exgratia_amt` float NOT NULL,
  `nov_wages` float NOT NULL,
  `nov_bonus_wages` float NOT NULL,
  `nov_payable_days` float NOT NULL,
  `nov_bonus_amt` float NOT NULL,
  `nov_exgratia_amt` float NOT NULL,
  `dec_wages` float NOT NULL,
  `dec_bonus_wages` float NOT NULL,
  `dec_payable_days` float NOT NULL,
  `dec_bonus_amt` float NOT NULL,
  `dec_exgratia_amt` float NOT NULL,
  `jan_wages` float NOT NULL,
  `jan_bonus_wages` float NOT NULL,
  `jan_payable_days` float NOT NULL,
  `jan_bonus_amt` float NOT NULL,
  `jan_exgratia_amt` float NOT NULL,
  `feb_wages` float NOT NULL,
  `feb_bonus_wages` float NOT NULL,
  `feb_payable_days` float NOT NULL,
  `feb_bonus_amt` float NOT NULL,
  `feb_exgratia_amt` float NOT NULL,
  `mar_wages` float NOT NULL,
  `mar_bonus_wages` float NOT NULL,
  `mar_payable_days` float NOT NULL,
  `mar_bonus_amt` float NOT NULL,
  `mar_exgratia_amt` float NOT NULL,
  `bonus_rate` float NOT NULL,
  `exgratia_rate` float NOT NULL,
  `payment_date` date DEFAULT NULL,
  `locked` varchar(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO bonus VALUES("1","2024-08-01","2024-08-29","2","84","1","1321546548","b","5000","3000","320","1","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","20","0","200","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","2024-08-30","","5","1","2024-08-29 23:21:51");
INSERT INTO bonus VALUES("2","2024-08-01","2024-08-29","3","83","2","1321546548","b","6000","3000","320","1","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","26","0","500","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","2024-08-30","","5","1","2024-08-29 23:21:51");



CREATE TABLE `caltype_bonus` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO caltype_bonus VALUES("1","(Basic + DA)*8.33","2017-11-29 17:36:53","2017-11-29 17:36:53");
INSERT INTO caltype_bonus VALUES("2","Limit to Amount(7000)","2017-12-04 18:34:54","2017-12-04 18:34:54");
INSERT INTO caltype_bonus VALUES("3","Max Wages(Baker)","2018-04-27 15:41:22","2018-04-27 15:41:22");



CREATE TABLE `caltype_deduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO caltype_deduct VALUES("1","Month's Days - Weeklyoff(26/27)","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_deduct VALUES("2","Month's Days - (30/31)","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_deduct VALUES("3","Consolidated","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_deduct VALUES("4","Hourly Basis","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_deduct VALUES("5","Daily Basis","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_deduct VALUES("6","Quarterly","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_deduct VALUES("7","As per Govt. Rules","2017-08-21 11:47:21","2017-08-21 11:47:21");



CREATE TABLE `caltype_income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO caltype_income VALUES("1","Month's Days - Weeklyoff(26/27)","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_income VALUES("2","Month's Days - 30 Fixed","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_income VALUES("3","Consolidated","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_income VALUES("4","Hourly Basis","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_income VALUES("5","Daily Basis","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_income VALUES("6","Quarterly","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_income VALUES("7","Gross Salary/8 *2","2017-08-24 11:13:53","2017-08-24 11:13:53");
INSERT INTO caltype_income VALUES("8","Per Shift Rs.20 if <= 15 else Rs.27 if >15","2017-09-21 13:02:01","2017-09-21 13:02:01");
INSERT INTO caltype_income VALUES("9","Per Shift Rs.25 if <= 15 else Rs.34.5 if >15","2017-09-21 13:02:01","2017-09-21 13:02:01");
INSERT INTO caltype_income VALUES("10","Per Shift","2017-11-27 06:54:24","2017-11-27 06:54:24");
INSERT INTO caltype_income VALUES("11","(GROSS-CONVEYANCE)/8*2","2017-11-27 06:41:01","2017-11-27 06:41:01");
INSERT INTO caltype_income VALUES("12","GORSS SALARY /8","2017-11-27 06:41:38","2017-11-27 06:41:38");
INSERT INTO caltype_income VALUES("13","(BASIC+DA)/8*2","2017-11-27 06:41:01","2017-11-27 06:41:01");
INSERT INTO caltype_income VALUES("14"," 26 Days Per Month","2017-11-29 14:30:08","2017-11-29 14:30:08");
INSERT INTO caltype_income VALUES("15","Per Hour","2017-12-19 14:41:26","2017-12-19 14:41:26");
INSERT INTO caltype_income VALUES("16","Per Present Day","2018-01-13 12:39:39","2018-01-13 12:39:39");



CREATE TABLE `cheque_details` (
  `chk_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `check_no` int(11) NOT NULL,
  `sal_month` date NOT NULL,
  `amount` float NOT NULL,
  `date` date NOT NULL,
  `type` varchar(1) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `bill_no` varchar(30) DEFAULT NULL,
  `db_addate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`chk_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;




CREATE TABLE `client_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `pfcode` varchar(30) NOT NULL,
  `esicode` varchar(30) NOT NULL,
  `created_by` tinyint(2) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_by` tinyint(2) NOT NULL,
  `updated_on` datetime NOT NULL,
  `db_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `db_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO client_group VALUES("1","Not Applicable","","","4","0000-00-00 00:00:00","0","0000-00-00 00:00:00","2024-08-27 03:26:31","2020-06-22 00:00:00");
INSERT INTO client_group VALUES("12","TEST CLIENT","1234","1234","5","2024-09-16 02:38:29","0","0000-00-00 00:00:00","2024-09-17 00:37:59","2024-09-17 00:37:59");
INSERT INTO client_group VALUES("13","PQR1","VWX1","STU1","5","2024-09-16 03:32:30","0","0000-00-00 00:00:00","2024-09-16 03:38:08","2024-09-16 03:38:08");
INSERT INTO client_group VALUES("14","TESTING1","222","1111","5","2024-09-16 23:37:46","0","0000-00-00 00:00:00","2024-09-16 23:37:46","2024-09-16 23:37:46");
INSERT INTO client_group VALUES("15","TEST","1232","12313","5","2024-09-17 00:35:44","0","0000-00-00 00:00:00","2024-09-17 00:35:44","2024-09-17 00:35:44");



CREATE TABLE `emp_advnacen` (
  `emp_advnacen_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` varchar(20) NOT NULL,
  `adv_amount` varchar(20) NOT NULL,
  `adv_installment` varchar(20) NOT NULL,
  `advance_type_id` int(11) NOT NULL,
  `closed_on` date NOT NULL DEFAULT '0000-00-00',
  `received_amt` float NOT NULL,
  `received_amt1` float NOT NULL,
  `db_addate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`emp_advnacen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO emp_advnacen VALUES("1","1","1","4","2021-05-11","10000","9","4","0000-00-00","0","0","2023-05-28 22:28:22","2023-05-28 22:28:22");
INSERT INTO emp_advnacen VALUES("2","1","35","4","2023-03-23","15000","1000","6","0000-00-00","0","0","2023-05-28 23:11:39","2023-05-28 23:11:39");
INSERT INTO emp_advnacen VALUES("4","1","47","4","2023-05-22","2000","1000","6","0000-00-00","0","0","2023-05-29 00:44:49","2023-05-29 00:44:49");
INSERT INTO emp_advnacen VALUES("5","1","47","4","2023-05-23","3000","100","6","0000-00-00","0","0","2023-05-29 00:45:29","2023-05-29 00:46:03");
INSERT INTO emp_advnacen VALUES("6","1","35","4","2023-05-01","2000","1000","6","0000-00-00","0","0","2023-05-29 01:13:34","2023-05-29 01:13:34");
INSERT INTO emp_advnacen VALUES("7","1","68","4","2022-11-05","20000","10","4","0000-00-00","0","0","2023-05-30 23:31:27","2023-05-30 23:31:27");
INSERT INTO emp_advnacen VALUES("8","1","77","4","2020-02-24","15000","8","6","0000-00-00","0","0","2023-05-31 00:15:03","2023-05-31 00:15:03");
INSERT INTO emp_advnacen VALUES("9","1","78","4","2022-11-05","12000","10","4","0000-00-00","0","0","2023-06-01 05:35:23","2023-06-01 05:44:54");
INSERT INTO emp_advnacen VALUES("10","1","79","4","2022-06-01","40000","12","6","0000-00-00","0","0","2023-06-01 06:06:47","2023-06-01 06:06:47");
INSERT INTO emp_advnacen VALUES("11","0","80","0","2023-01-05","40000","12","6","0000-00-00","0","0","2023-06-08 02:58:40","2023-06-08 02:58:40");
INSERT INTO emp_advnacen VALUES("12","1","0","5","2023-03-23","15000","1000","6","0000-00-00","0","0","2024-08-27 23:03:32","2024-08-27 23:03:32");
INSERT INTO emp_advnacen VALUES("13","1","85","5","2024-02-02","2000","2","6","0000-00-00","0","0","2024-08-30 23:16:34","2024-08-30 23:16:34");
INSERT INTO emp_advnacen VALUES("14","1","146","5","2024-09-16","2000","2","6","0000-00-00","0","0","2024-09-15 22:59:24","2024-09-15 22:59:24");
INSERT INTO emp_advnacen VALUES("15","1","147","5","2024-02-02","2000","1","4","0000-00-00","0","0","2024-09-15 23:02:31","2024-09-15 23:02:31");
INSERT INTO emp_advnacen VALUES("16","1","148","5","2024-02-02","2000","2","6","0000-00-00","0","0","2024-09-15 23:10:07","2024-09-15 23:10:07");
INSERT INTO emp_advnacen VALUES("17","1","149","5","2024-09-02","2000","2","6","0000-00-00","0","0","2024-09-15 23:11:26","2024-09-15 23:11:26");
INSERT INTO emp_advnacen VALUES("18","1","150","5","2024-02-02","2000","2","6","0000-00-00","0","0","2024-09-16 03:37:49","2024-09-16 03:37:49");
INSERT INTO emp_advnacen VALUES("19","1","82","5","2024-03-23","1000","100","6","0000-00-00","0","0","2024-09-16 04:21:26","2024-09-16 04:21:26");
INSERT INTO emp_advnacen VALUES("20","1","154","5","2024-02-02","2000","2","6","0000-00-00","0","0","2024-09-16 22:14:42","2024-09-16 22:14:42");
INSERT INTO emp_advnacen VALUES("21","1","155","5","2024-09-23","100","100","6","0000-00-00","0","0","2024-09-16 22:25:37","2024-09-16 22:25:37");
INSERT INTO emp_advnacen VALUES("22","1","82","5","2024-08-08","2000","20000","6","0000-00-00","0","0","2024-09-16 22:42:35","2024-09-16 22:42:56");
INSERT INTO emp_advnacen VALUES("23","1","82","5","2024-02-02","2000","20000","6","0000-00-00","0","0","2024-09-18 00:58:28","2024-09-18 00:58:28");
INSERT INTO emp_advnacen VALUES("24","1","82","5","2024-02-02","2000","9","4","0000-00-00","0","0","2024-09-18 01:28:36","2024-09-18 01:28:36");
INSERT INTO emp_advnacen VALUES("25","1","1","5","2024-08-26","5000","2","4","1970-01-01","0","0","2024-09-18 02:10:56","0000-00-00 00:00:00");
INSERT INTO emp_advnacen VALUES("26","1","82","5","2024-09-01","2000","8000","6","0000-00-00","0","0","2024-09-18 20:23:08","2024-09-18 20:23:28");
INSERT INTO emp_advnacen VALUES("27","1","1","5","2024-09-02","10","1","4","1970-01-01","0","0","2024-09-20 01:51:54","0000-00-00 00:00:00");
INSERT INTO emp_advnacen VALUES("28","1","129","5","2024-09-01","1000","1","4","1970-01-01","0","0","2024-09-20 02:29:04","0000-00-00 00:00:00");



CREATE TABLE `emp_deduct` (
  `emp_deduct_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `head_id` int(11) NOT NULL,
  `calc_type` varchar(20) NOT NULL,
  `std_amt` decimal(15,2) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `db_addate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `ticket_no` varchar(6) NOT NULL,
  PRIMARY KEY (`emp_deduct_id`),
  UNIQUE KEY `Deduct` (`emp_id`,`head_id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO emp_deduct VALUES("2","1","82","5","20","1","10.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("3","1","155","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("4","1","156","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("5","1","157","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("6","1","159","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("7","1","160","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("8","1","162","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("9","1","163","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("10","1","164","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("11","1","165","5","20","1","0.00","","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");
INSERT INTO emp_deduct VALUES("101","1","1","5","20","1","1000.00","abcde","0","2024-09-20 03:22:19","2024-09-23 21:23:34","");



CREATE TABLE `emp_income` (
  `emp_income_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `head_id` int(11) NOT NULL,
  `calc_type` varchar(20) NOT NULL,
  `std_amt` decimal(15,2) NOT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `db_addate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `ticket_no` varchar(6) NOT NULL,
  PRIMARY KEY (`emp_income_id`)
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO emp_income VALUES("13","1","1","5","1","1","1000.00","abcde","2023-05-29 23:19:11","2024-09-20 05:25:55","");
INSERT INTO emp_income VALUES("14","1","1","5","2","1","50.00","","2023-05-29 23:19:28","2024-09-19 20:13:23","");
INSERT INTO emp_income VALUES("15","1","1","4","5","1","1500.00","","2023-05-29 23:19:40","2023-05-29 23:19:40","");
INSERT INTO emp_income VALUES("16","1","47","4","1","1","6000.00","","2023-05-29 23:20:07","2023-05-29 23:20:07","");
INSERT INTO emp_income VALUES("17","1","47","4","2","1","5500.00","","2023-05-29 23:20:18","2023-05-29 23:20:18","");
INSERT INTO emp_income VALUES("18","1","47","4","5","1","1600.00","","2023-05-29 23:20:29","2023-05-29 23:20:29","");
INSERT INTO emp_income VALUES("19","1","49","4","1","1","20000.00","Test","2023-05-29 23:21:51","2023-05-29 23:21:51","");
INSERT INTO emp_income VALUES("20","1","49","4","2","4","300.00","","2023-05-29 23:22:05","2023-05-29 23:22:05","");
INSERT INTO emp_income VALUES("21","1","49","4","5","4","900.00","","2023-05-29 23:22:17","2023-05-29 23:22:17","");
INSERT INTO emp_income VALUES("22","1","0","4","1","1","0.00","Remark","2023-05-30 02:26:38","2023-05-30 02:26:38","");
INSERT INTO emp_income VALUES("23","1","48","4","1","1","8000.00","Test1","2023-05-30 02:26:38","2023-05-30 02:26:38","");
INSERT INTO emp_income VALUES("24","1","49","4","4","2","10000.00","Test","2023-05-30 03:20:03","2023-05-30 03:20:03","");
INSERT INTO emp_income VALUES("25","1","48","4","4","2","9000.00","Test1","2023-05-30 03:20:03","2023-05-30 03:20:03","");
INSERT INTO emp_income VALUES("26","1","48","4","2","1","3232.00","Test1","2023-05-30 05:09:19","2023-05-30 05:09:19","");
INSERT INTO emp_income VALUES("27","1","68","4","1","2","15000.00","basic","2023-05-30 23:27:18","2023-05-30 23:27:18","");
INSERT INTO emp_income VALUES("28","1","68","4","2","2","8000.00","","2023-05-30 23:32:34","2023-05-30 23:32:34","");
INSERT INTO emp_income VALUES("29","1","77","4","1","2","18000.00","basic","2023-05-31 00:10:55","2023-05-31 00:10:55","");
INSERT INTO emp_income VALUES("30","1","77","4","3","2","9000.00","hra","2023-05-31 00:11:19","2023-05-31 00:11:19","");
INSERT INTO emp_income VALUES("31","1","76","4","1","2","20000.00","basic","2023-05-31 00:20:19","2023-05-31 00:20:19","");
INSERT INTO emp_income VALUES("32","1","76","4","4","2","8000.00","inc","2023-05-31 00:20:41","2023-05-31 00:20:41","");
INSERT INTO emp_income VALUES("33","1","74","4","1","2","14000.00","basic","2023-05-31 00:34:50","2023-05-31 00:34:50","");
INSERT INTO emp_income VALUES("34","1","74","4","4","2","8000.00","inc","2023-05-31 00:35:13","2023-05-31 00:35:13","");
INSERT INTO emp_income VALUES("35","1","78","4","1","2","12000.00","basic","2023-06-01 04:26:58","2023-06-01 04:26:58","");
INSERT INTO emp_income VALUES("36","1","78","4","2","2","7000.00","da","2023-06-01 05:19:32","2023-06-01 05:19:32","");
INSERT INTO emp_income VALUES("37","1","79","4","1","2","20000.00","","2023-06-01 06:05:02","2023-06-01 06:05:02","");
INSERT INTO emp_income VALUES("38","1","80","4","1","2","25000.00","basic","2023-06-08 02:28:23","2023-06-08 02:28:23","");
INSERT INTO emp_income VALUES("39","1","0","5","4","2","130.00","test","2024-08-27 23:02:15","2024-08-27 23:02:15","");
INSERT INTO emp_income VALUES("41","1","85","5","1","4","2000.00","gjh","2024-08-30 23:15:58","2024-08-30 23:15:58","");
INSERT INTO emp_income VALUES("42","1","86","5","2","5","1111.00","","2024-08-30 23:37:35","2024-08-30 23:37:35","");
INSERT INTO emp_income VALUES("43","1","145","5","1","2","70.00","","2024-09-15 22:56:20","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("44","1","146","5","2","1","20.00","","2024-09-15 22:58:37","2024-09-20 01:25:07","");
INSERT INTO emp_income VALUES("45","1","147","5","10","2","5000.00","","2024-09-15 23:01:58","2024-09-16 04:02:43","");
INSERT INTO emp_income VALUES("46","1","148","5","1","2","50.00","","2024-09-15 23:09:40","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("47","1","149","5","1","2","60.00","","2024-09-15 23:11:00","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("48","1","150","5","1","2","80.00","","2024-09-16 03:37:22","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("49","1","82","5","1","2","1000.00","","2024-09-16 04:20:39","2024-09-23 02:09:19","");
INSERT INTO emp_income VALUES("50","1","129","5","1","2","90.00","","2024-09-16 04:23:41","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("51","1","129","5","2","2","20.00","","2024-09-16 04:23:49","2024-09-20 01:25:07","");
INSERT INTO emp_income VALUES("52","1","82","5","50","2","0.00","","2024-09-16 04:40:17","2024-09-16 04:40:17","");
INSERT INTO emp_income VALUES("53","1","141","5","50","2","0.00","","2024-09-16 04:40:17","2024-09-16 04:40:17","");
INSERT INTO emp_income VALUES("54","1","152","5","50","2","0.00","","2024-09-16 04:40:17","2024-09-16 04:40:17","");
INSERT INTO emp_income VALUES("55","1","146","5","50","2","0.00","","2024-09-16 04:40:17","2024-09-16 04:40:17","");
INSERT INTO emp_income VALUES("56","1","147","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("57","1","148","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("58","1","149","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("59","1","145","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("60","1","150","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("61","1","129","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("62","1","144","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("63","1","143","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("64","1","142","5","50","2","0.00","","2024-09-16 04:40:18","2024-09-16 04:40:18","");
INSERT INTO emp_income VALUES("65","1","141","5","1","2","100.00","abcdef","2024-09-16 04:44:04","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("66","1","152","5","1","2","20.00","","2024-09-16 04:44:04","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("67","1","146","5","1","2","30.00","","2024-09-16 04:44:04","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("68","1","147","5","1","2","40.00","","2024-09-16 04:44:04","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("69","1","144","5","1","2","100.00","","2024-09-16 04:44:04","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("70","1","143","5","1","2","20.00","","2024-09-16 04:44:04","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("71","1","142","5","1","2","3000.00","","2024-09-16 04:44:04","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("72","1","154","5","1","2","200.00","asas","2024-09-16 22:14:22","2024-09-20 20:46:48","");
INSERT INTO emp_income VALUES("73","1","155","5","1","1","0.00","","2024-09-16 22:24:54","2024-09-20 05:25:55","");
INSERT INTO emp_income VALUES("74","1","82","5","10","2","111.00","","2024-09-17 00:55:35","2024-09-19 03:16:22","");
INSERT INTO emp_income VALUES("75","1","82","5","2","2","50.00","","2024-09-18 03:57:34","2024-09-19 20:13:23","");
INSERT INTO emp_income VALUES("76","1","82","5","3","2","444.00","","2024-09-19 03:12:11","2024-09-19 03:12:11","");
INSERT INTO emp_income VALUES("77","1","161","5","2","2","100.00","","2024-09-19 03:58:14","2024-09-19 03:58:14","");
INSERT INTO emp_income VALUES("78","1","159","5","1","1","0.00","","2024-09-20 20:41:00","2024-09-20 20:41:00","");
INSERT INTO emp_income VALUES("79","1","160","5","1","1","0.00","","2024-09-20 20:41:00","2024-09-20 20:41:00","");
INSERT INTO emp_income VALUES("80","1","164","5","1","1","0.00","","2024-09-20 20:41:00","2024-09-20 20:41:00","");
INSERT INTO emp_income VALUES("81","1","163","5","1","1","0.00","","2024-09-20 20:41:00","2024-09-20 20:41:00","");
INSERT INTO emp_income VALUES("82","1","162","5","1","1","0.00","","2024-09-20 20:41:01","2024-09-20 20:41:01","");
INSERT INTO emp_income VALUES("83","1","165","5","1","1","0.00","","2024-09-20 20:41:01","2024-09-20 20:41:01","");
INSERT INTO emp_income VALUES("84","1","157","5","1","1","0.00","","2024-09-20 20:41:01","2024-09-20 20:41:01","");
INSERT INTO emp_income VALUES("85","1","156","5","1","1","0.00","","2024-09-20 20:41:01","2024-09-20 20:41:01","");



CREATE TABLE `emp_leave` (
  `leave_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `calculated_to` datetime NOT NULL,
  `calculated_from` datetime NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `granted` float NOT NULL,
  `carried_forward` float NOT NULL,
  `calculated` float NOT NULL,
  `ob` decimal(4,1) NOT NULL,
  `enjoyed` decimal(4,1) NOT NULL,
  `encashed` float NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


