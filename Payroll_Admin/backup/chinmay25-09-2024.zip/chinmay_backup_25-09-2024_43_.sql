

CREATE TABLE `tran_income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `sal_month` varchar(20) NOT NULL,
  `head_id` int(11) NOT NULL,
  `calc_type` varchar(20) NOT NULL,
  `std_amt` decimal(20,2) NOT NULL,
  `amount` decimal(20,2) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=373 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tran_income VALUES("1","35","2023-05-31","17","2","15000.00","22500.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("5","48","2023-05-31","1","1","8000.00","7360.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("7","48","2023-05-31","4","2","9000.00","6900.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("14","68","2023-05-31","1","2","15000.00","13500.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("15","68","2023-05-31","2","2","8000.00","7200.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("16","77","2023-05-31","1","2","18000.00","15600.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("17","77","2023-05-31","3","2","9000.00","7800.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("18","76","2023-05-31","1","2","20000.00","17333.33","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("19","76","2023-05-31","4","2","8000.00","6933.33","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("20","74","2023-05-31","1","2","14000.00","13066.67","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("21","74","2023-05-31","4","2","8000.00","7466.67","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("22","78","2023-05-31","1","2","12000.00","10000.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("23","78","2023-05-31","2","2","7000.00","5833.33","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("24","79","2023-05-31","1","2","20000.00","20000.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_income VALUES("25","80","2023-05-31","1","2","25000.00","22500.00","0000-00-00 00:00:00","0000-00-00 00:00:00");



CREATE TABLE `uan_ecr` (
  `UAN` varchar(20) NOT NULL,
  `memname` varchar(60) NOT NULL,
  `gross_wages` decimal(10,0) NOT NULL,
  `epf_wages` decimal(10,0) NOT NULL,
  `eps_wages` decimal(10,0) NOT NULL,
  `edli_wages` decimal(10,0) NOT NULL,
  `epf_contribution` decimal(12,2) NOT NULL,
  `eps_contribution` decimal(12,2) NOT NULL,
  `epf_eps_d` decimal(12,2) NOT NULL,
  `ncp_days` decimal(5,2) NOT NULL,
  `refund` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;




CREATE TABLE `uan_ecr_calc` (
  `UAN` varchar(20) NOT NULL,
  `memname` varchar(60) NOT NULL,
  `gross_wages` decimal(10,0) NOT NULL,
  `epf_wages` decimal(10,0) NOT NULL,
  `eps_wages` decimal(10,0) NOT NULL,
  `edli_wages` decimal(10,0) NOT NULL,
  `epf_contribution` decimal(12,2) NOT NULL,
  `eps_contribution` decimal(12,2) NOT NULL,
  `epf_eps_d` decimal(12,2) NOT NULL,
  `ncp_days` decimal(5,2) NOT NULL,
  `refund` decimal(12,2) NOT NULL,
  `admin_pf` decimal(10,0) DEFAULT NULL,
  `link_ins` decimal(10,0) DEFAULT NULL,
  `client_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


