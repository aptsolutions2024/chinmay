

CREATE TABLE `mast_other_payment` (
  `op_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `op_name` varchar(255) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`op_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_other_payment VALUES("1","2","4","ADVANCE AMT","2022-09-18 20:30:21","2022-09-18 20:30:21");
INSERT INTO mast_other_payment VALUES("2","2","4","TEST","2022-09-18 20:39:02","2022-09-18 20:43:20");
INSERT INTO mast_other_payment VALUES("3","2","4","FUEL CHARGES","2022-09-20 05:05:28","2022-09-20 05:12:58");
INSERT INTO mast_other_payment VALUES("4","2","4","MATERIAL HANDLING","2022-09-24 04:15:43","2022-09-24 04:15:43");
INSERT INTO mast_other_payment VALUES("5","2","4","DRESS","2022-09-24 04:15:49","2022-09-24 04:15:49");
INSERT INTO mast_other_payment VALUES("6","2","4","SUNDAY WORKING","2022-09-24 04:15:58","2022-09-24 04:15:58");
INSERT INTO mast_other_payment VALUES("7","2","4","HOLIDAY WORKING","2022-09-24 04:16:04","2022-09-24 04:16:04");
INSERT INTO mast_other_payment VALUES("8","1","4","BREAKFAST & TEA","2023-05-31 03:01:27","2023-05-31 03:01:40");



CREATE TABLE `mast_paycode` (
  `mast_paycode_id` int(11) NOT NULL AUTO_INCREMENT,
  `paycode` varchar(4) NOT NULL,
  `mast_paycode_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_paycode_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;




CREATE TABLE `mast_qualif` (
  `mast_qualif_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_qualif_name` varchar(50) NOT NULL,
  `qualif` varchar(4) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_qualif_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_qualif VALUES("1","BE 11111","","1","4","2023-02-12 20:24:35","2023-05-26 05:13:13");
INSERT INTO mast_qualif VALUES("2","QUALIFICATION","","1","4","2023-05-26 05:10:13","2023-05-26 05:10:13");
INSERT INTO mast_qualif VALUES("3","ME CHEMICAL","","1","4","2023-05-28 22:00:56","2023-05-28 22:01:43");
INSERT INTO mast_qualif VALUES("4","MBA OPERATIONS ","","1","4","2023-05-29 04:39:57","2023-05-29 04:39:57");
INSERT INTO mast_qualif VALUES("5","GRADUATE","","1","4","2023-05-29 04:40:21","2023-05-29 04:40:21");
INSERT INTO mast_qualif VALUES("6","12TH","","1","4","2023-05-29 04:40:29","2023-05-29 04:40:29");
INSERT INTO mast_qualif VALUES("7","5TH","","1","5","2023-05-29 04:41:13","2024-09-16 23:42:50");
INSERT INTO mast_qualif VALUES("8","8TH","","1","4","2023-05-29 04:41:29","2023-05-29 04:42:17");
INSERT INTO mast_qualif VALUES("9","9TH","","1","4","2023-05-29 04:41:29","2023-05-29 04:42:33");
INSERT INTO mast_qualif VALUES("10","BCS","","1","4","2023-05-29 04:41:29","2023-05-29 04:43:03");
INSERT INTO mast_qualif VALUES("11","PHD","","1","4","2023-05-29 04:41:31","2023-05-30 23:03:17");
INSERT INTO mast_qualif VALUES("12","DIPLOMA","","1","4","2023-05-29 04:41:31","2023-05-29 04:41:31");
INSERT INTO mast_qualif VALUES("13","2ST","","1","5","2024-09-16 03:29:30","2024-09-16 23:45:39");
INSERT INTO mast_qualif VALUES("14","11TH","","1","5","2024-09-16 23:42:31","2024-09-16 23:46:57");
INSERT INTO mast_qualif VALUES("15","3ST","","1","5","2024-09-17 00:39:46","2024-09-17 00:41:48");



CREATE TABLE `op_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `op_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `payment_date` datetime NOT NULL,
  `amount` float NOT NULL,
  `bill_no` varchar(255) NOT NULL,
  `loc` enum('0','1','','') DEFAULT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO op_details VALUES("1","8","8","68","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("2","8","8","69","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("3","8","8","70","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("4","8","8","71","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("5","8","8","72","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("6","8","8","73","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("7","8","8","74","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("8","8","8","75","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("9","8","8","76","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("10","8","8","77","2023-05-30 00:00:00","10","1234","","2023-05-31 03:03:00","2023-05-31 03:03:00");
INSERT INTO op_details VALUES("11","8","8","68","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("12","8","8","69","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("13","8","8","70","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("14","8","8","71","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("15","8","8","72","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("16","8","8","73","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("17","8","8","74","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("18","8","8","75","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("19","8","8","76","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");
INSERT INTO op_details VALUES("20","8","8","77","2023-05-31 00:00:00","10","test","","2023-06-01 03:15:55","2023-06-01 03:15:55");



CREATE TABLE `pf_charges` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_date` date NOT NULL,
  `to_date` date NOT NULL,
  `acno1_employee` decimal(12,2) NOT NULL DEFAULT 12.00,
  `acno1_employer` decimal(12,2) NOT NULL DEFAULT 3.67,
  `acno10` decimal(12,2) NOT NULL DEFAULT 8.33,
  `acno2` decimal(5,3) NOT NULL,
  `acno21` decimal(5,3) NOT NULL,
  `acno22` decimal(5,3) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO pf_charges VALUES("1","2017-04-01","2018-05-31","12.00","3.67","8.33","0.650","0.500","0.000");
INSERT INTO pf_charges VALUES("2","2018-06-01","2025-12-31","12.00","3.67","8.33","0.500","0.500","0.000");



CREATE TABLE `tran_advance` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `tradv_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `sal_month` date NOT NULL,
  `head_id` int(11) NOT NULL,
  `calc_type` varchar(20) NOT NULL,
  `std_amt` decimal(20,0) NOT NULL,
  `amount` decimal(20,0) NOT NULL,
  `paid_amt` decimal(15,2) NOT NULL,
  `emp_advance_id` int(10) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tran_advance VALUES("1","0","35","4","1","2023-05-26","6","0","15000","1000","0.00","2","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_advance VALUES("2","0","68","8","1","2023-05-31","4","0","20000","10","0.00","7","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_advance VALUES("3","0","77","8","1","2023-05-31","6","0","15000","8","0.00","8","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_advance VALUES("4","0","78","8","1","2023-05-31","4","0","12000","10","0.00","9","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_advance VALUES("5","0","79","8","1","2023-05-31","6","0","40000","12","0.00","10","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_advance VALUES("6","0","80","8","1","2023-05-31","6","0","40000","12","0.00","11","0000-00-00 00:00:00","0000-00-00 00:00:00");



CREATE TABLE `tran_days` (
  `trd_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `sal_month` date NOT NULL,
  `fullpay` decimal(5,2) NOT NULL,
  `halfpay` decimal(5,2) NOT NULL,
  `leavewop` decimal(5,2) NOT NULL,
  `present` decimal(5,2) NOT NULL,
  `absent` decimal(5,2) NOT NULL,
  `weeklyoff` decimal(5,2) NOT NULL,
  `pl` decimal(5,2) NOT NULL,
  `sl` decimal(5,2) NOT NULL,
  `cl` decimal(5,2) NOT NULL,
  `otherleave` decimal(5,2) NOT NULL,
  `paidholiday` decimal(5,2) NOT NULL,
  `additional` decimal(5,2) NOT NULL,
  `othours` decimal(5,2) NOT NULL,
  `nightshifts` decimal(5,2) NOT NULL,
  `extra_inc1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `extra_inc2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `leave_encash` int(11) DEFAULT NULL,
  `reward` int(11) DEFAULT NULL,
  `extra_ded1` decimal(10,2) NOT NULL DEFAULT 0.00,
  `extra_ded2` decimal(10,2) NOT NULL DEFAULT 0.00,
  `leftdate` date NOT NULL DEFAULT '0000-00-00',
  `wagediff` decimal(12,2) NOT NULL,
  `Allow_arrears` decimal(12,2) NOT NULL,
  `Ot_arrears` decimal(12,2) NOT NULL,
  `society` float NOT NULL,
  `incometax` float NOT NULL,
  `canteen` float NOT NULL,
  `plbal` decimal(5,2) DEFAULT NULL,
  `clbal` decimal(5,2) DEFAULT NULL,
  `remarks` varchar(150) NOT NULL,
  `invalid` varchar(70) NOT NULL DEFAULT ' ',
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `updated_by` int(11) NOT NULL,
  PRIMARY KEY (`trd_id`)
) ENGINE=InnoDB AUTO_INCREMENT=62 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tran_days VALUES("1","35","4","2023-05-31","0.00","0.00","0.00","25.00","2.00","4.00","2.00","5.00","3.00","0.00","1.00","5.00","65.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","","1","4","2023-05-29 00:01:29","2023-05-29 00:01:29","4");
INSERT INTO tran_days VALUES("3","48","6","2023-05-29","0.00","0.00","0.00","20.00","3.00","4.00","2.00","1.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(N)-","1","4","2023-05-30 03:25:19","2023-05-30 03:25:19","4");
INSERT INTO tran_days VALUES("4","68","8","2023-05-31","0.00","0.00","0.00","20.00","2.00","4.00","2.00","1.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("5","69","8","2023-05-31","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("6","70","8","2023-05-31","0.00","0.00","0.00","22.00","2.00","3.00","1.00","2.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("7","71","8","2023-05-31","0.00","0.00","0.00","23.00","3.00","2.00","3.00","1.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(N)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("8","72","8","2023-05-31","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("9","73","8","2023-05-31","0.00","0.00","0.00","24.00","1.00","4.00","2.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("10","74","8","2023-05-31","0.00","0.00","0.00","25.00","2.00","2.00","0.00","1.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("11","75","8","2023-05-31","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("12","76","8","2023-05-31","0.00","0.00","0.00","23.00","3.00","2.00","1.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("13","77","8","2023-05-31","0.00","0.00","0.00","18.00","3.00","4.00","0.00","4.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-05-31 00:29:21","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("14","78","8","2023-05-31","0.00","0.00","0.00","19.00","2.00","2.00","2.00","2.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-06-01 05:36:20","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("15","79","8","2023-05-31","0.00","0.00","0.00","30.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-06-01 06:08:18","2023-06-08 03:02:49","4");
INSERT INTO tran_days VALUES("16","80","8","2023-05-31","0.00","0.00","0.00","20.00","6.00","4.00","2.00","1.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0.00","0","0","0.00","0.00","0000-00-00","0.00","0.00","0.00","0","0","0","","","","Days Total(R)-","1","4","2023-06-08 03:02:49","2023-06-08 03:02:49","4");



CREATE TABLE `tran_days_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `client_id` int(11) NOT NULL,
  `emp_id` int(11) DEFAULT NULL,
  `sal_month` date DEFAULT NULL,
  `day1` varchar(2) DEFAULT NULL,
  `day2` varchar(2) DEFAULT NULL,
  `day3` varchar(2) DEFAULT NULL,
  `day4` varchar(2) DEFAULT NULL,
  `day5` varchar(2) DEFAULT NULL,
  `day6` varchar(2) DEFAULT NULL,
  `day7` varchar(2) DEFAULT NULL,
  `day8` varchar(2) DEFAULT NULL,
  `day9` varchar(2) DEFAULT NULL,
  `day10` varchar(2) DEFAULT NULL,
  `day11` varchar(2) DEFAULT NULL,
  `day12` varchar(2) DEFAULT NULL,
  `day13` varchar(2) DEFAULT NULL,
  `day14` varchar(2) DEFAULT NULL,
  `day15` varchar(2) DEFAULT NULL,
  `day16` varchar(2) DEFAULT NULL,
  `day17` varchar(2) DEFAULT NULL,
  `day18` varchar(2) DEFAULT NULL,
  `day19` varchar(2) DEFAULT NULL,
  `day20` varchar(2) DEFAULT NULL,
  `day21` varchar(2) DEFAULT NULL,
  `day22` varchar(2) DEFAULT NULL,
  `day23` varchar(2) DEFAULT NULL,
  `day24` varchar(2) DEFAULT NULL,
  `day25` varchar(2) DEFAULT NULL,
  `day26` varchar(2) DEFAULT NULL,
  `day27` varchar(2) DEFAULT NULL,
  `day28` varchar(2) DEFAULT NULL,
  `day29` varchar(2) DEFAULT NULL,
  `day30` varchar(2) DEFAULT NULL,
  `day31` varchar(2) DEFAULT NULL,
  `ot1` varchar(4) DEFAULT NULL,
  `ot2` varchar(4) DEFAULT NULL,
  `ot3` varchar(4) DEFAULT NULL,
  `ot4` varchar(4) DEFAULT NULL,
  `ot5` varchar(4) DEFAULT NULL,
  `ot6` varchar(4) DEFAULT NULL,
  `ot7` varchar(4) DEFAULT NULL,
  `ot8` varchar(4) DEFAULT NULL,
  `ot9` varchar(4) DEFAULT NULL,
  `ot10` varchar(4) DEFAULT NULL,
  `ot11` varchar(4) DEFAULT NULL,
  `ot12` varchar(4) DEFAULT NULL,
  `ot13` varchar(4) DEFAULT NULL,
  `ot14` varchar(4) DEFAULT NULL,
  `ot15` varchar(4) DEFAULT NULL,
  `ot16` varchar(4) DEFAULT NULL,
  `ot17` varchar(4) DEFAULT NULL,
  `ot18` varchar(4) DEFAULT NULL,
  `ot19` varchar(4) DEFAULT NULL,
  `ot20` varchar(4) DEFAULT NULL,
  `ot21` varchar(4) DEFAULT NULL,
  `ot22` varchar(4) DEFAULT NULL,
  `ot23` varchar(4) DEFAULT NULL,
  `ot24` varchar(4) DEFAULT NULL,
  `ot25` varchar(4) DEFAULT NULL,
  `ot26` varchar(4) DEFAULT NULL,
  `ot27` varchar(4) DEFAULT NULL,
  `ot28` varchar(4) DEFAULT NULL,
  `ot29` varchar(4) DEFAULT NULL,
  `ot30` varchar(4) DEFAULT NULL,
  `ot31` varchar(4) DEFAULT NULL,
  `ot_total` varchar(6) DEFAULT NULL,
  `day_total` varchar(6) DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_on` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `updated_on` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Unique` (`emp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;




CREATE TABLE `tran_deduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `sal_month` date NOT NULL,
  `head_id` int(11) NOT NULL,
  `calc_type` varchar(20) NOT NULL,
  `std_amt` decimal(20,2) NOT NULL,
  `amount` decimal(20,2) NOT NULL,
  `employer_contri_1` decimal(15,2) NOT NULL,
  `employer_contri_2` decimal(20,2) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=392 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tran_deduct VALUES("1","35","2023-05-31","20","7","15000.00","1800.00","550.00","1250.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("2","48","2023-05-31","20","2","7360.00","5837.00","270.00","613.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("9","68","2023-05-31","20","7","15000.00","1800.00","550.00","1250.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("10","69","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("11","69","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("12","69","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("13","69","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("14","70","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("15","70","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("16","70","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("17","70","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("18","71","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("19","71","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("20","71","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("21","71","2023-05-31","0","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("22","72","2023-05-31","21","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("23","72","2023-05-31","23","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("24","72","2023-05-31","20","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("25","72","2023-05-31","22","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("26","73","2023-05-31","21","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("27","73","2023-05-31","23","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("28","73","2023-05-31","20","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("29","73","2023-05-31","22","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("30","74","2023-05-31","21","7","20533.00","154.00","667.33","0.00","3","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("31","74","2023-05-31","20","7","13067.00","1568.00","480.00","1088.00","3","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("32","75","2023-05-31","21","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("33","75","2023-05-31","23","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("34","75","2023-05-31","20","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("35","75","2023-05-31","22","7","0.00","0.00","0.00","0.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("36","76","2023-05-31","21","7","24267.00","182.00","788.67","0.00","2","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("37","76","2023-05-31","23","7","700.00","0.00","0.00","0.00","2","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("38","76","2023-05-31","20","7","15000.00","1800.00","550.00","1250.00","2","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("39","77","2023-05-31","21","7","23400.00","176.00","760.50","0.00","1","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("40","77","2023-05-31","23","7","500.00","0.00","0.00","0.00","1","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("41","77","2023-05-31","20","7","15000.00","1800.00","550.00","1250.00","1","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("42","77","2023-05-31","22","7","1000.00","200.00","0.00","0.00","1","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("43","78","2023-05-31","20","7","15000.00","1800.00","550.00","1250.00","2","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("44","78","2023-05-31","21","7","15833.00","119.00","514.58","0.00","2","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("45","79","2023-05-31","20","7","15000.00","1800.00","550.00","1250.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO tran_deduct VALUES("46","80","2023-05-31","20","7","15000.00","1800.00","550.00","1250.00","0","0000-00-00 00:00:00","0000-00-00 00:00:00");



CREATE TABLE `tran_employee` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `sal_month` date NOT NULL,
  `client_id` int(11) NOT NULL,
  `desg_id` int(11) NOT NULL,
  `dept_id` int(11) NOT NULL,
  `qualif_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `loc_id` int(11) NOT NULL,
  `paycode_id` int(11) NOT NULL,
  `bankacno` text NOT NULL,
  `middlename_relation` varchar(30) NOT NULL,
  `esistatus` varchar(1) NOT NULL,
  `esino` varchar(20) NOT NULL,
  `pfno` varchar(20) NOT NULL,
  `comp_ticket_no` varchar(20) NOT NULL,
  `married_status` varchar(1) NOT NULL,
  `pay_mode` varchar(1) NOT NULL,
  `handicap` enum('1','2','3','4') NOT NULL COMMENT '''1''-Not Applicable,''2''-locomotive,''3''-hearing,''4''-visual',
  `payabledays` decimal(6,2) NOT NULL,
  `gross_salary` decimal(20,2) NOT NULL,
  `tot_deduct` decimal(20,2) NOT NULL,
  `netsalary` decimal(20,2) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=343 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO tran_employee VALUES("1","35","2023-05-31","4","1","6","1","1","1","0","5556565655554","","Y","3332323","","989900","U","T","1","45.00","22500.00","2800.00","19700.00","1","4","2023-05-29 00:01:43","2023-05-29 00:01:43");
INSERT INTO tran_employee VALUES("11","48","2023-05-31","6","2","7","1","1","0","0","3423432432423","","Y","324324","","","U","T","1","23.00","14260.00","5837.00","8423.00","1","4","2023-05-30 03:25:32","2023-05-30 03:25:32");
INSERT INTO tran_employee VALUES("145","68","2023-05-31","8","1","10","5","3","12","0","8765432345678","","Y","09877655544","234567","23853","U","N","1","27.00","20700.00","1810.00","18890.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("146","69","2023-05-31","8","0","0","0","0","0","0","Bank Ac No","","Y","ESI No","PF No","Comp Ticket No","M","P","1","0.00","0.00","0.00","0.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("147","70","2023-05-31","8","0","0","0","0","0","0","35658789653","","Y","","30-03-5","","m","c","1","0.00","0.00","0.00","0.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("148","71","2023-05-31","8","0","0","0","0","0","0","9876545767","","Y","","678754","","u","n","1","0.00","0.00","0.00","0.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("149","72","2023-05-31","8","0","0","2","0","0","0","Bank Ac No","","Y","ESI No","PF No","Comp Ticket No","M","P","1","0.00","0.00","0.00","0.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("150","73","2023-05-31","8","2","8","4","2","0","0","35658789653","","Y","","30-03-5","","m","c","1","0.00","0.00","0.00","0.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("151","74","2023-05-31","8","4","9","3","3","0","0","9876545777","","Y","","678754","","M","T","1","28.00","20533.34","1722.00","18811.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("152","75","2023-05-31","8","0","0","2","0","0","0","Bank Ac No","","Y","ESI No","PF No","Comp Ticket No","M","P","1","0.00","0.00","0.00","0.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("153","76","2023-05-31","8","3","1","11","2","12","0","35658789663","","Y","","30-03-5","","M","C","1","26.00","24266.66","1982.00","22285.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("154","77","2023-05-31","8","7","5","1","1","11","0","9876545768","","Y","","678754","","-","N","1","26.00","23400.00","2184.00","21216.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("155","78","2023-05-31","8","6","6","5","2","2","0","0876787665654343","","Y","","","77878","U","C","1","25.00","15833.33","1929.00","13904.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("156","79","2023-05-31","8","2","8","5","2","1","0","","","Y","","","","U","N","1","30.00","20000.00","1812.00","18188.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");
INSERT INTO tran_employee VALUES("157","80","2023-05-31","8","7","4","11","3","12","0","8967465463443","","Y","","","","M","N","1","27.00","22500.00","1812.00","20688.00","1","4","2023-06-08 03:10:13","2023-06-08 03:10:13");

