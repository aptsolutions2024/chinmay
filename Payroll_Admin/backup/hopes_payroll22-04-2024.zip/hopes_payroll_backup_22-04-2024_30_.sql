

CREATE TABLE `mast_client` (
  `mast_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `clientno` varchar(3) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_add1` varchar(150) NOT NULL,
  `esicode` varchar(50) NOT NULL,
  `pfcode` varchar(25) NOT NULL,
  `tanno` varchar(50) NOT NULL,
  `panno` varchar(50) NOT NULL,
  `gstno` varchar(50) NOT NULL,
  `current_month` date NOT NULL,
  `parent_comp` enum('Y','N') NOT NULL DEFAULT 'N' COMMENT 'Y-Yes,N-No',
  `parentId` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `valid_users` varchar(50) NOT NULL,
  `ser_charges` decimal(10,2) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_client VALUES("3","102","ELECTRONICA PLASTIC MACHINES LTD.,","GAT NO. 399, HISSA NO. 1 & 2 BHARETAL MULSHIPUNE412 111","","","","","","2023-12-31","N","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client VALUES("5","104","HOPES OFFICE CONSULTANCY SERVICES","MAULI KRUPA HSG SOC, B11, S. NO. 87/3B/1A, AZAD NAGAR, KOTHRUDPUNE411 029","","","","","","2023-12-31","N","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client VALUES("9","108","BLUE DART EXPRESS LTD.,","PUNE (PNQ)TAL HAVELI DIST PUNE","-","-","-","AAACB0446L","27AAACB0446L1ZS","2023-12-31","N","40","1","5","","5","0.00","0000-00-00 00:00:00","2024-04-08 00:56:35");
INSERT INTO mast_client VALUES("10","109","BLUE DART EXPRESS LTD., [HOUSE KEEPING]","PUNE (PNQ)TAL HAVELI DIST PUNE","-","-","-","-","-","2023-12-31","N","40","1","5","","5","0.00","0000-00-00 00:00:00","2024-04-08 00:41:10");
INSERT INTO mast_client VALUES("11","110","BLUE DART EXPRESS LTD., KOLHAPUR","PULACHI SHIROLIOFF BANGALORE PUNE HIGHWAYKOLHAPUR","","","","","","2023-12-31","N","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client VALUES("14","113","BLUE DART EXPRESS LTD., KOLHAPUR (HOUSE KEEP)","PULACHI SHIROLIOFF BANGALORE PUNE HIGHWAYKOLHAPUR","","","","","","2023-12-31","N","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client VALUES("21","117","BLUE DART EXPRESS LTD., SATARA","-","-","-","-","-","-","2023-12-31","N","0","1","5","","5","0.00","0000-00-00 00:00:00","2024-04-08 02:53:45");
INSERT INTO mast_client VALUES("23","119","BLUE DART EXPRESS LTD., FESTIVAL","-","-","-","-","-","-","2023-12-31","N","40","1","5","-","5","0.00","0000-00-00 00:00:00","2024-04-08 02:52:17");
INSERT INTO mast_client VALUES("24","120","BLUE DART EXPRESS LTD., O/S","ACD","-","-","-","PAN12346","-","2023-12-31","N","40","1","5","-","5","0.00","0000-00-00 00:00:00","2024-04-08 02:51:41");
INSERT INTO mast_client VALUES("25","121","BLUE DART EXPRESS LTD., (AUR DIV)","AURANGAVAD","","","","","","2023-12-31","N","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client VALUES("26","201","BLUE DART EXPRESS LTD.,PUNE","aaa","aaa","aaa","aaa","aaa","aaa","2023-12-31","N","38","2","4","aaa","4","0.00","0000-00-00 00:00:00","2023-03-27 23:19:03");
INSERT INTO mast_client VALUES("27","202","BLUE DART EXPRESS LTD.,PUNE FESTIVAL","aaa","aaa","aaa","aaa","aaa","aaa","2023-12-31","N","38","2","4","aaa","4","0.00","0000-00-00 00:00:00","2023-03-27 23:18:24");
INSERT INTO mast_client VALUES("28","122","BLUE DART EXPRESS LTD., O/S FESTIVAL","-","-","-","-","-","-","2023-12-31","N","40","1","5","","5","0.00","0000-00-00 00:00:00","2024-04-08 00:36:37");
INSERT INTO mast_client VALUES("29","123","BLUE DART EXPRESS LTD., O/S(II)","-","-","-","-","-","-","2023-12-31","N","40","1","5","","5","0.00","0000-00-00 00:00:00","2024-04-08 00:35:51");
INSERT INTO mast_client VALUES("30","203","KHALIPE HOPES SOLUTIONS PVT LTD.,","aaa","aaa","aaa","aaa","aaa","aaa","2023-12-31","N","38","2","4","aaa","4","0.00","0000-00-00 00:00:00","2023-03-27 23:17:33");
INSERT INTO mast_client VALUES("31","204","GEISSEL INDIA PRIVATE LIMITED","GAT NO.1102 MUTHA ROAD PIRANGUTTALUKA MULSHI PUNEPUNE412 115","aaa","aaa","aaa","aaa","aaa","2023-12-31","N","38","2","4","aaa","4","0.00","0000-00-00 00:00:00","2023-03-27 23:16:53");
INSERT INTO mast_client VALUES("32","124","BLUE DART EXPRESS LTD., O/S(II) FES","-","-","-","-","-","-","2023-12-31","N","40","1","5","","5","0.00","0000-00-00 00:00:00","2024-04-08 00:35:15");
INSERT INTO mast_client VALUES("33","125","BLUE DART EXPRESS LTD.,(AUR) FESTIV","","","","","","","2023-12-31","N","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client VALUES("34","205","BLUE DART EXP.LTD.(UFO)","aaa","aaa","aaa","aaa","aaa","aaa","2023-12-31","N","38","2","4","aaa","4","0.00","0000-00-00 00:00:00","2023-03-27 23:15:55");
INSERT INTO mast_client VALUES("35","206","BLUE DART EXP.LTD.(UFO FES)","add1","csd","sdfdsfds","dfssf","dsfsd","sdfds","2023-12-31","N","38","2","4","sdfds@gm.com","4","11.22","0000-00-00 00:00:00","2023-03-27 23:15:00");
INSERT INTO mast_client VALUES("37","","TRIAL","","aa","bb","cc","dd","ee","2023-12-31","N","35","1","5","aa@gmail.com","5","12.00","2022-08-08 17:09:21","2022-08-17 03:10:32");
INSERT INTO mast_client VALUES("38",""," KHALIPE HOPES SOLUTIONS PVT.LTD.(P)","Shivajinagar","0000","0000","0000","000000","00000","2023-12-31","N","38","2","4","test@0000.in","4","0.00","2023-03-27 23:12:39","2023-03-27 23:14:08");
INSERT INTO mast_client VALUES("39","","BLUE DART UDGIR","UDGIR","25330346540051001","PUPUN0034564000","0","0","0","2023-12-31","N","9","1","0","khalipehopes@gmail.com","5","7.00","2024-02-19 05:30:13","2024-02-19 05:30:13");
INSERT INTO mast_client VALUES("40","","BLUE DART GROUP","test address","123456","PFTEST123456","TAN123456","PAN12346","GST12356","2024-06-30","Y","0","1","5","TEST1234@GMAIL.COM","5","0.00","2024-04-07 23:36:34","2024-04-08 00:33:10");



CREATE TABLE `mast_client_org` (
  `mast_client_id` int(11) NOT NULL AUTO_INCREMENT,
  `clientno` varchar(3) NOT NULL,
  `client_name` varchar(50) NOT NULL,
  `client_add1` varchar(150) NOT NULL,
  `esicode` varchar(50) NOT NULL,
  `pfcode` varchar(25) NOT NULL,
  `tanno` varchar(50) NOT NULL,
  `panno` varchar(50) NOT NULL,
  `gstno` varchar(50) NOT NULL,
  `current_month` date NOT NULL,
  `parentId` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `email` varchar(30) NOT NULL,
  `valid_users` varchar(50) NOT NULL,
  `ser_charges` decimal(10,2) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_client_org VALUES("1","101","SUMA SOFT PVT LTD","ERANDAWANAPUNE","33-11955-64","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("3","102","ELECTRONICA PLASTIC MACHINES LTD.,","GAT NO. 399, HISSA NO. 1 & 2 BHARETAL MULSHIPUNE412 111","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("4","103","MINDTREE LTD.","PLOT NO.37, RAJIV GANDHI INFOTECHPARK,PHASE 1,MIDC HINJEWADI PUNE411 057","33/11214/100","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("5","104","HOPES OFFICE CONSULTANCY SERVICES","MAULI KRUPA HSG SOC, B11, S. NO. 87/3B/1A, AZAD NAGAR, KOTHRUDPUNE411 029","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("6","105","FINOLEX CABLES LTD., URSE","AT POST URSE,TAL MAVALDIST PUNE","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("7","106","FINOLEX CABLES LTD., PIMPRI","16/17 PUNE BOMBAY ROAD,PIMPRI PUNEPUNE411 018","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("8","107","DA VINCI DESIGN SOLUTIONS PVT.LTD.,","S114  MIDC  BHOSARI,PUNE411 026","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("9","108","BLUE DART EXPRESS LTD.,","PUNE (PNQ)TAL HAVELI DIST PUNE","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("10","109","BLUE DART EXPRESS LTD., [HOUSE KEEPING]","PUNE (PNQ)TAL HAVELI DIST PUNE","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("11","110","BLUE DART EXPRESS LTD., KOLHAPUR","PULACHI SHIROLIOFF BANGALORE PUNE HIGHWAYKOLHAPUR","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("12","111","M/S ADITYA MOULDING","GAT NO. 2588435, AT BHARE,POST GHOTHWADE,TAL MULSHI DIST PUNE412 111","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("13","112","BIJUR DELIMON (I) PVT.LTD.,","PLOT NO.1-56/1 H BLOCK, PIMPRIPUNE411 018","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("14","113","BLUE DART EXPRESS LTD., KOLHAPUR (HOUSE KEEP)","PULACHI SHIROLIOFF BANGALORE PUNE HIGHWAYKOLHAPUR","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("15","114","ESSAR OIL LTD","P.B.NO.24,39KM,OKHA HIGHWAY,VADINAR, JAMNAGAR 361305.361 305","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("19","115","ELECTRONICA PLASTIC MACHINE LTD [PUNE OFFICE]","UNIT NO.28, 2ND FLOOR ELECTRONICCO-OP INDUSTRIAL ESTATE,PUNE SATARAROAD PUNE","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("20","116","ONE NETWORK ENTERPRISES","WESTEND CENTER III,SURVEY NO.169/12ND FLOOR, SOUTH WING,SECTOR II,AUNDH PUNE411 007","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("21","117","BLUE DART EXPRESS LTD., SATARA","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("22","118","BLUE DART EXPRESS LTD. ICHALKARANJI","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("23","119","BLUE DART EXPRESS LTD., FESTIVAL","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("24","120","BLUE DART EXPRESS LTD., O/S","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("25","121","BLUE DART EXPRESS LTD., (AUR DIV)","AURANGAVAD","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("26","201","BLUE DART EXPRESS LTD.,PUNE","","","","","","","2022-07-31","0","2","4","","4","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("27","202","BLUE DART EXPRESS LTD.,PUNE FESTIVAL","","","","","","","2022-07-31","0","2","4","","4","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("28","122","BLUE DART EXPRESS LTD., O/S FESTIVAL","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("29","123","BLUE DART EXPRESS LTD., O/S(II)","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("30","203","KHALIPE HOPES SOLUTIONS PVT LTD.,","","","","","","","2022-07-31","0","2","4","","4","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("31","204","GEISSEL INDIA PRIVATE LIMITED","GAT NO.1102 MUTHA ROAD PIRANGUTTALUKA MULSHI PUNEPUNE412 115","","","","","","2022-07-31","0","2","4","","4","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("32","124","BLUE DART EXPRESS LTD., O/S(II) FES","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("33","125","BLUE DART EXPRESS LTD.,(AUR) FESTIV","","","","","","","2022-07-31","0","1","5","","5","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("34","205","BLUE DART EXP.LTD.(UFO)","","","","","","","2022-07-31","0","2","4","","4","0.00","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_client_org VALUES("35","206","BLUE DART EXP.LTD.(UFO FES)","","csd","sdfdsfds","dfssf","dsfsd","sdfds","2022-07-31","0","2","4","sdfds@gm.com","4","11.22","0000-00-00 00:00:00","2022-08-03 09:10:34");
INSERT INTO mast_client_org VALUES("37","","TRIAL","","aa","bb","cc","dd","ee","2022-08-31","35","1","5","aa@gmail.com","5","12.00","2022-08-08 17:09:21","2022-08-17 03:10:32");



CREATE TABLE `mast_company` (
  `comp_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `comp_name` varchar(100) NOT NULL,
  `phone_no` int(11) NOT NULL,
  `address` varchar(200) NOT NULL,
  `logo` varchar(20) NOT NULL,
  `bankacno` varchar(25) NOT NULL,
  `td_string` varchar(350) NOT NULL,
  `addr_1` varchar(300) NOT NULL,
  `addr_2` text NOT NULL,
  `tel` varchar(50) NOT NULL,
  `email` varchar(255) NOT NULL,
  `gstin` varchar(50) NOT NULL,
  `pan_no` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`comp_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_company VALUES("1","0","HOPES CONSULTANCY SERVICES","22222","Shivajinagar","","asasa",",present,weeklyoff,  absent,pl,cl,sl, paidholiday,additional,othours, nightshifts,incometax,canteen,extra_inc1, extra_inc2,leave_encash,extra_ded1,extra_ded2, wagediff,Allow_arrears, Ot_arrears,invalid","","","","hrhopes@gmail.com","27AHPPK9046A1Z8","AHPPK9046A","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_company VALUES("2","0","KHALIPE HOPES SOLUTIONS PVT.LTD.","22222","Shivajinagar","","asasa",",present,weeklyoff,  absent,pl,cl,sl , paidholiday,additional, othours, nightshifts,incometax,canteen,extra_inc1, extra_inc2,leave_encash,extra_ded1,extra_ded2, wagediff,Allow_arrears, Ot_arrears,invalid","","","","hrhopes@gmail.com","27AAGCK7001G1ZR","AAGCK7001G","0000-00-00 00:00:00","0000-00-00 00:00:00");



CREATE TABLE `mast_deduct_heads` (
  `mast_deduct_heads_id` int(11) NOT NULL AUTO_INCREMENT,
  `deduct_heads_name` varchar(20) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_deduct_heads_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1001 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_deduct_heads VALUES("1","P.F.","2","4","2017-09-14 09:10:48","2017-09-14 09:10:48");
INSERT INTO mast_deduct_heads VALUES("2","E.S.I.","2","4","2017-09-14 09:10:55","2017-09-14 09:10:55");
INSERT INTO mast_deduct_heads VALUES("3","PROF. TAX","2","4","2017-09-14 09:11:08","2017-09-14 09:11:08");
INSERT INTO mast_deduct_heads VALUES("4","L.W.F.","2","4","2017-09-14 09:11:19","2017-09-14 09:11:19");
INSERT INTO mast_deduct_heads VALUES("13","CANTEEN","2","4","2017-09-14 12:27:06","2017-09-14 12:27:06");
INSERT INTO mast_deduct_heads VALUES("14","TRANSPORT","2","4","2017-09-14 12:27:11","2017-09-14 12:27:11");
INSERT INTO mast_deduct_heads VALUES("15","BANK LOAN","2","4","2017-09-14 12:28:10","2017-12-15 12:48:36");
INSERT INTO mast_deduct_heads VALUES("16","SOCIETY ","2","4","2017-09-25 11:55:05","2017-12-15 12:48:16");
INSERT INTO mast_deduct_heads VALUES("17","COMP. LOAN","2","4","2017-09-25 12:09:52","2017-11-28 15:35:04");
INSERT INTO mast_deduct_heads VALUES("20","P.F.","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("21","E.S.I.","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("22","PROF. TAX","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("23","L.W.F.","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("24","CANTEEN","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("25","TRANSPORT","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("26","SOCIETY","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("27","BANK LOAN","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("28","COMP. LOAN","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("29","DEDUCT-1","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("30","DEDUCT-2","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("31","DEDUCT-1","2","4","2017-11-28 15:53:37","2017-11-28 15:53:37");
INSERT INTO mast_deduct_heads VALUES("32","DEDUCT-2","2","4","2017-11-28 15:53:42","2017-11-28 15:53:42");
INSERT INTO mast_deduct_heads VALUES("33","INCOMETAX","2","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("34","INCOMETAX","1","4","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_deduct_heads VALUES("998","R.OFF","1","4","2018-07-11 12:54:47","2018-07-11 12:54:47");
INSERT INTO mast_deduct_heads VALUES("999","R.OFF","2","4","2018-07-11 12:55:04","2018-07-11 12:55:04");
INSERT INTO mast_deduct_heads VALUES("1000","DIFF PF REFUND ","2","4","2020-01-03 12:56:29","2020-01-03 12:56:29");



CREATE TABLE `mast_dept` (
  `mast_dept_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_dept_name` varchar(150) NOT NULL,
  `dept` varchar(4) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `client_id` varchar(50) DEFAULT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `name` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`mast_dept_id`)
) ENGINE=InnoDB AUTO_INCREMENT=200 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_dept VALUES("1","MCW","MCW","2","4","","2022-07-23 16:52:20","2022-08-08 17:31:52","");
INSERT INTO mast_dept VALUES("2","PWH","PWH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("3","HJW","HJW","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("4","SWH","SWH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("5","FINAL QUALITY CONTROL","FQC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("6","SUPPORT","SUPP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("7","QUALITY CONTROL","QC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("8","SE","SE","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("9","ACCOUNTS","A/C","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("10","PRODUCTION","PROD","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("11","HELPER","HLP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("12","DIRECTOR PERSONNEL","DIR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("13","MARKETING","MKT.","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("14","LABORATERY","LAB","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("15","BILLING","BILL","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("16","CONDUCTOR","COND","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("17","XLPE","XLPE","2","4","","2022-07-23 16:52:20","2023-05-26 04:44:12","");
INSERT INTO mast_dept VALUES("18","PCD","PCD","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("19","ADMIN","ADM","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("20","INTERNET RESERCHER (MARKETING)","INTE","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("21","ADMINSTRATION","ADM1","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("22","PROJECT (ADMIN)","PRO","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("23","COMPONDING","COMP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("24","EXTRUSION","EXTR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("25","COILING","COIL","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("26","W/W","WW","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("27","STORE","STOR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("28","EXPORT","EXP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("29","KHADAKI","KHA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("30","HINJWADI","HINJ","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("31","PIMPRI","PIMP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("32","WAGHOLI","WAG","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("33","MARKETING","MARK","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("34","MAINTANCE","MAIN","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("35","OTHER ENGINEERING","OTH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("36","SYS ADMIN","SYS","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("37","HR","HR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("38","BUSINESS DEVELOPMENT","BUS","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("39","CO-AXIAL","CO-A","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("40","F.G. STORE","F.G.","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("41","MECHANICAL MAINTANCE","MECH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("42","TECH.SUPORT","TECH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("43","RECRUITMENT","REQ","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("44","CIS PUNE","SUP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("45","AP","AP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("46","CPT","CPT","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("47","CCH INCORPORATED","CCH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("48","CONSULTANT","CONS","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("49","FINANCE","FIN","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("50","TRAINING","TRA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("51","MS","MS","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("52","DELIVERY","DELI","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("53","HOUSE KEEPTING","HK","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("54","CHAKAN","CH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("55","I8 COMPATIBILITY TESTING","I8","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("56","MARKETYARD","MAR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("57","JM ROAD","JM","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("58","VIMANNAGAR","VIMA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("59","VISHRANTWADI","VISH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("60","TALEGAON DABHADE","TALE","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("61","LORREL CHAKAN","LORR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("62","MAHINDRA & MAHINDRA KANEPHATA","M&M","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("63","BUND GARDEN","BRG","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("64","VMC","VMC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("65","ELECTRICAL MAINTANCE","ELEC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("66","MARUNJI W/H","MARU","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("67","ASSEMBLY","ASSE","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("68","CHIMBALI PHATA","CHIM","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("69","TML WAKI","CHAT","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("70","H.M.W.","HINM","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("71","FIYAT CHAKAN","TATA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("72","OFFICE BOY","OFF","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("73","TLW","TLW","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("74","HID","HID","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("75","MERCHANDISE BENZ CHAKAN","MERC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("76","TATA MOTERS","TAM","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("77","TWH","TWH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("78","TATA/EMCORE","PCH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("79","EDP","EDP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("80","APEX/SFC","APEX","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("81","BANER","BAN","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("82","CORPO","CORP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("83","GENERAL MOTOR TALEGAON DABHADE","GM","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("84","JCB TALEGAON","JCB","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("85","TATA MOTOR PIMPRI","TATP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("86","GENERAL MOTOR","GEN","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("87","HADAPSAR","HAD","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("88","SCHINDLER","SCHI","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("89","HONEYWELL & FIRSTCRY CHAKAN","HONE","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("90","ICHALKARANJI","ICH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("91","LONAVALA","LONA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("92","SANASWADI","SANA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("93","PUB/OB","PUB","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("94","PUB/HUB","HUB","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("95","KHP","KHP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("96","SATARA","SAT","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("97","KOL H.K.","KOH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("98","PUNE H.K.","PUH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("99","SANGVI","SANG","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("100","FC ROAD","FC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("101","VEC","VEC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("102","KHW","KHW","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("103","SINHGAD ROAD","SID","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("104","AUNDH OFFICE","AUND","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("105","PCH","PC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("106","LEC","LEC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("107","SWH","SWH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("108","TINGARE NAGAR","TIN","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("109","HMC","HMC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("110","NARAYANGAON","NARA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("111","SHRIGONDA","SHRI","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("112","SHEVGAON","SHEV","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("113","UDGIR","UDG","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("114","OSMANABAD","OSM","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("115","KARAD","KAR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("116","KAGAL","KAG","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("117","PARALI -VAIJANATH","PARA","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("118","WAI SATARA","WAI","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("119","GADHINGALAS","GAD","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("120","KONDI SOLAPUR","KOND","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("121","BHIGWAN","BHIG","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("122","AMBEJOGAI","AMBE","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("123","KHED","KHED","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("124","KTD","KTD","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("125","PIMPRI CHINCHWAD","PMC","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("126","PIRANGUT","PIR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("127","BARSHI","BAR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("128","SHRIRAMPUR","SPUR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("129","SHIRUR","SHIR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("130","PALUS","PALU","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("131","SANGALI","SAN","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("132","JATH","JATH","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("133","TASGAON","TAS","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("134","MANJARI","MAN","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("135","GARGOTI","GAR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("136","DESPATCH","DES","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("137","SKODA-VW CHAKAN","SKVW","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("138","AKLUJ","AKJ","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("139","LATUR","LTR","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("140","PHALTAN","PHL","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("141","SOLAPUR CITY","SHP","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("142","LONAND","LND","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("143","GENRAL MOTORS","GMI","2","4","","2022-07-23 16:52:20","2022-07-23 16:52:20","");
INSERT INTO mast_dept VALUES("144","IT SAGAR","","2","4","","2022-08-03 05:59:46","2022-08-03 05:59:46","");
INSERT INTO mast_dept VALUES("147","TEST 1","","2","4","","2022-08-08 20:43:36","2022-08-08 20:44:15","");
INSERT INTO mast_dept VALUES("148","FGFG","","2","4","","2022-08-09 07:01:56","2022-08-09 07:01:56","");
INSERT INTO mast_dept VALUES("149","FGHJK121212","","2","4","","2022-08-09 07:26:53","2022-08-09 07:28:57","");
INSERT INTO mast_dept VALUES("150","ZZZWWW","","0","0","","2022-08-09 07:29:18","2022-08-17 03:11:53","");
INSERT INTO mast_dept VALUES("151","TTT 4","","0","0","","2022-08-09 09:31:22","2022-08-17 03:12:19","");
INSERT INTO mast_dept VALUES("152","TTT 4","","2","4","","2022-08-09 09:35:27","2022-08-17 03:12:49","");
INSERT INTO mast_dept VALUES("153","SAGAR","","0","0","","2022-08-17 03:13:29","2022-08-17 03:13:29","");
INSERT INTO mast_dept VALUES("154","BRN","","1","5","","2022-09-08 23:27:50","2022-09-08 23:30:58","");
INSERT INTO mast_dept VALUES("155","CAH","","1","5","","2022-09-08 23:27:57","2022-09-08 23:31:11","");
INSERT INTO mast_dept VALUES("156","HDP","","1","5","","2022-09-08 23:28:08","2022-09-08 23:31:27","");
INSERT INTO mast_dept VALUES("157","HNW","","1","5","","2022-09-08 23:28:15","2022-09-08 23:31:38","");
INSERT INTO mast_dept VALUES("158","BRG","","1","5","","2022-09-08 23:28:22","2022-09-08 23:30:20","");
INSERT INTO mast_dept VALUES("159","KTD","","1","5","","2022-09-08 23:31:51","2022-09-08 23:31:51","");
INSERT INTO mast_dept VALUES("160","PCH","","1","5","","2022-09-08 23:32:08","2022-09-08 23:32:08","");
INSERT INTO mast_dept VALUES("161","PMC","","1","5","","2022-09-08 23:32:15","2022-09-08 23:32:15","");
INSERT INTO mast_dept VALUES("162","PUB","","1","5","","2022-09-08 23:32:20","2022-09-08 23:32:20","");
INSERT INTO mast_dept VALUES("163","PBT","","1","5","","2022-09-08 23:32:32","2022-09-08 23:32:32","");
INSERT INTO mast_dept VALUES("164","SAA","","1","5","","2022-09-08 23:32:48","2022-09-08 23:32:48","");
INSERT INTO mast_dept VALUES("165","SGB","","1","5","","2022-09-08 23:33:01","2022-09-08 23:33:01","");
INSERT INTO mast_dept VALUES("166","SID","","1","5","","2022-09-08 23:33:10","2022-09-08 23:33:10","");
INSERT INTO mast_dept VALUES("167","TGR","","1","5","","2022-09-08 23:33:19","2022-09-08 23:33:19","");
INSERT INTO mast_dept VALUES("168","TLW","","1","5","","2022-09-08 23:33:23","2022-09-08 23:33:23","");
INSERT INTO mast_dept VALUES("169","TWH","","1","5","","2022-09-08 23:33:31","2022-09-08 23:33:31","");
INSERT INTO mast_dept VALUES("170","VEC","","1","5","","2022-09-08 23:33:54","2022-09-08 23:33:54","");
INSERT INTO mast_dept VALUES("171","VIN","","1","5","","2022-09-08 23:33:58","2022-09-08 23:33:58","");
INSERT INTO mast_dept VALUES("172","WGH","","1","5","","2022-09-08 23:34:03","2022-09-08 23:34:03","");
INSERT INTO mast_dept VALUES("173","KHW","","1","5","","2022-09-08 23:34:26","2022-09-08 23:34:26","");
INSERT INTO mast_dept VALUES("174","SVG AURANGABAD","","1","5","","2022-09-16 04:33:45","2022-09-16 04:33:45","");
INSERT INTO mast_dept VALUES("175","PUC","","1","5","","2023-01-28 00:59:31","2023-01-28 00:59:31","");
INSERT INTO mast_dept VALUES("176","SHG","","1","5","","2023-01-30 22:44:51","2023-01-30 22:44:51","");
INSERT INTO mast_dept VALUES("177","KON","","1","5","","2023-01-30 22:54:13","2023-01-30 22:54:13","");
INSERT INTO mast_dept VALUES("178","UDG","","1","5","","2023-01-30 23:01:33","2023-01-30 23:01:33","");
INSERT INTO mast_dept VALUES("179","PLV","","1","5","","2023-01-30 23:15:13","2023-01-30 23:15:13","");
INSERT INTO mast_dept VALUES("180","KCT (KHED CITY)","","1","5","","2023-01-30 23:44:06","2023-01-30 23:44:06","");
INSERT INTO mast_dept VALUES("181","GAD","","1","5","","2023-01-31 00:23:04","2023-01-31 00:23:04","");
INSERT INTO mast_dept VALUES("182","WAI","","1","5","","2023-01-31 00:36:57","2023-01-31 00:36:57","");
INSERT INTO mast_dept VALUES("183","KRC (KARAD)","","1","5","","2023-01-31 02:05:43","2023-01-31 02:05:43","");
INSERT INTO mast_dept VALUES("184","ELECTRONICA","","1","5","","2023-01-31 03:31:38","2023-01-31 03:31:38","");
INSERT INTO mast_dept VALUES("185","HOPES OFFICE","","1","5","","2023-01-31 04:06:06","2023-01-31 04:06:06","");
INSERT INTO mast_dept VALUES("186","SWH","","1","5","","2023-01-31 04:44:21","2023-01-31 04:44:21","");
INSERT INTO mast_dept VALUES("187","TRIAL1","","2","4","","2023-02-12 17:56:21","2023-02-12 17:57:42","");
INSERT INTO mast_dept VALUES("188","PIR","","1","5","","2023-02-19 01:49:53","2023-02-19 01:49:53","");
INSERT INTO mast_dept VALUES("189","TSG","","1","5","","2023-02-19 03:43:20","2023-02-19 03:43:20","");
INSERT INTO mast_dept VALUES("190","SSC","","2","4","","2023-04-03 00:22:57","2023-04-03 00:22:57","");
INSERT INTO mast_dept VALUES("191","ADC","","1","5","","2023-04-17 23:07:28","2023-04-17 23:07:28","");
INSERT INTO mast_dept VALUES("192","UND","","1","5","","2023-04-17 23:08:00","2023-04-17 23:08:00","");
INSERT INTO mast_dept VALUES("193","SRL","","1","5","","2023-04-17 23:09:56","2023-04-17 23:09:56","");
INSERT INTO mast_dept VALUES("194","SGV","","1","5","","2023-04-17 23:10:29","2023-04-17 23:10:29","");
INSERT INTO mast_dept VALUES("195","PVT","","1","5","","2023-04-17 23:11:01","2023-04-17 23:11:01","");
INSERT INTO mast_dept VALUES("196","PCH","","1","5","","2023-04-17 23:12:11","2023-04-17 23:12:11","");
INSERT INTO mast_dept VALUES("197","LEC","","1","5","","2023-04-17 23:12:35","2023-04-17 23:12:35","");
INSERT INTO mast_dept VALUES("198","KHP","","1","5","","2023-04-17 23:13:04","2023-04-17 23:13:04","");
INSERT INTO mast_dept VALUES("199","KGL","","1","5","","2024-04-06 23:33:21","2024-04-06 23:33:21","");



CREATE TABLE `mast_desg` (
  `mast_desg_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_desg_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_desg_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_desg VALUES("1","N.A.","2","4","2022-08-17 04:19:01","2023-02-12 18:14:27");
INSERT INTO mast_desg VALUES("2","OPS","1","5","2022-09-08 23:43:41","2022-09-08 23:43:41");
INSERT INTO mast_desg VALUES("3","COUNTER","1","5","2022-09-08 23:43:49","2022-09-08 23:43:49");
INSERT INTO mast_desg VALUES("4","EDP","1","5","2022-09-08 23:43:52","2022-09-08 23:43:52");
INSERT INTO mast_desg VALUES("5","HOUSEKEEPING","1","5","2022-09-08 23:43:59","2022-09-08 23:43:59");
INSERT INTO mast_desg VALUES("6","N.A.","1","5","2022-08-17 04:19:01","2022-08-17 04:19:01");
INSERT INTO mast_desg VALUES("7","MANAGER","2","4","2023-03-28 22:38:44","2023-03-28 22:39:44");



CREATE TABLE `mast_income_heads` (
  `mast_income_heads_id` int(11) NOT NULL AUTO_INCREMENT,
  `income_heads_name` varchar(50) NOT NULL,
  `deduct_esi` varchar(1) DEFAULT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_addate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`mast_income_heads_id`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_income_heads VALUES("1","BASIC","","2","3","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("2","D.A. ","","2","3","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("3","H.R.A.","","2","3","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("4","INCENTIVE","","2","3","2017-09-14 00:00:00","2018-08-21 12:06:08");
INSERT INTO mast_income_heads VALUES("5","OTHER ALW","","2","3","2017-09-14 00:00:00","2017-09-14 00:00:00");
INSERT INTO mast_income_heads VALUES("6","WASHING ALW","","2","3","2017-09-14 00:00:00","2017-12-19 13:13:47");
INSERT INTO mast_income_heads VALUES("7","OVERTIME","","2","3","2017-09-18 00:00:00","2017-09-18 00:00:00");
INSERT INTO mast_income_heads VALUES("8","PAP. ALW","","2","3","2017-09-21 00:00:00","2017-09-21 00:00:00");
INSERT INTO mast_income_heads VALUES("9","NIGHT SFT.","","2","3","2017-09-21 00:00:00","2017-09-21 00:00:00");
INSERT INTO mast_income_heads VALUES("10","CANTEEN ALW","","2","3","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("11","CONVEYANCE","","2","3","0000-00-00 00:00:00","2018-08-29 10:51:47");
INSERT INTO mast_income_heads VALUES("12","C.C.ALW","","2","3","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("13","ATTEND. ALW","","2","3","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("14","EDU. ALW","","2","3","0000-00-00 00:00:00","0000-00-00 00:00:00");
INSERT INTO mast_income_heads VALUES("15","P.L.P. ALW","","2","3","2017-11-08 18:14:06","2017-12-19 13:12:26");
INSERT INTO mast_income_heads VALUES("16","MEDICAL","","2","3","2017-11-08 18:15:11","2017-11-08 18:15:11");
INSERT INTO mast_income_heads VALUES("17","BASIC","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("18","D.A. ","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("19","H.R.A.","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("20","TRAVEL ","","1","2","2017-11-08 18:41:59","2019-04-08 14:59:30");
INSERT INTO mast_income_heads VALUES("21","OTHER ALW","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("22","PLP ALL.","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("23","OVERTIME","","1","2","2017-11-08 18:41:59","2018-06-23 10:54:55");
INSERT INTO mast_income_heads VALUES("24","PAP. ALW.","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("25","NIGHT SFT.","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("26","CANTEEN ALW","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("27","CONVEYANCE","","1","2","2017-11-08 18:41:59","2019-04-08 14:59:10");
INSERT INTO mast_income_heads VALUES("28","C.C.ALW","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("29","ATTEND. ALW","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("30","EDU. ALW","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("31","WASHING ALW","N","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("32","MEDICAL","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("33","Income-1","","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("34","Income-1","","2","3","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("35","BONUS","","1","2","2017-11-16 11:56:45","2017-11-16 11:56:45");
INSERT INTO mast_income_heads VALUES("36","OT. AARREARS","","2","3","2017-11-29 11:09:26","2020-03-12 10:15:28");
INSERT INTO mast_income_heads VALUES("37","ALW ARREARS","","2","3","2017-11-29 11:09:42","2017-11-29 11:09:42");
INSERT INTO mast_income_heads VALUES("38","WAGE DIFF","","2","3","2017-11-29 11:09:57","2017-11-29 11:09:57");
INSERT INTO mast_income_heads VALUES("39","PETROL ALW","","2","3","2018-01-13 12:15:24","2018-01-13 12:15:24");
INSERT INTO mast_income_heads VALUES("40","PETROL ALW","","1","2","2018-01-22 15:08:21","2018-01-22 15:08:21");
INSERT INTO mast_income_heads VALUES("41","SUPPLMENT ALW","","2","3","2018-02-21 11:03:07","2018-07-06 13:51:12");
INSERT INTO mast_income_heads VALUES("42","WAGE DIFF","","1","2","2018-03-13 10:23:29","2018-03-13 10:23:29");
INSERT INTO mast_income_heads VALUES("43","ALW ARREARS","","1","2","2018-05-22 14:02:49","2018-05-22 14:14:46");
INSERT INTO mast_income_heads VALUES("44","HELPDESK ALW","","1","2","2018-05-23 12:28:30","2018-05-23 12:28:30");
INSERT INTO mast_income_heads VALUES("45","Income-2","N","1","2","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("46","Income-2","N","2","3","2017-11-08 18:41:59","2017-11-08 18:41:59");
INSERT INTO mast_income_heads VALUES("47","LEAVE ENCASHMENT","N","2","3","2018-08-03 11:47:31","2018-08-03 11:47:31");
INSERT INTO mast_income_heads VALUES("48","LEAVE ENCASHMENT","N","1","2","2018-08-03 12:22:58","2018-08-03 12:22:58");
INSERT INTO mast_income_heads VALUES("49","OT. AARREARS","","1","3","2017-11-29 11:09:26","2017-11-29 11:09:26");
INSERT INTO mast_income_heads VALUES("50","BONUS","","2","3","2019-09-04 16:51:28","2019-09-07 10:17:50");
INSERT INTO mast_income_heads VALUES("51","ADDL. ALW.","","2","3","2019-09-09 10:35:32","2019-09-13 14:17:48");
INSERT INTO mast_income_heads VALUES("52","REWARD AMT.","","1","0","2020-02-10 13:46:56","2020-02-10 13:46:56");
INSERT INTO mast_income_heads VALUES("53","REWARD AMT.","","2","0","2020-02-10 13:46:56","2020-02-10 13:46:56");
INSERT INTO mast_income_heads VALUES("54","LEAVE ENCASH.","","1","0","2020-02-10 13:47:27","2020-02-10 13:47:27");
INSERT INTO mast_income_heads VALUES("55","LEAVE ENCASH.","","2","0","2020-02-10 13:47:27","2020-02-10 13:47:27");
INSERT INTO mast_income_heads VALUES("56","OVERTIME OCT 2019","","2","3","2020-03-05 13:59:03","2020-03-05 13:59:03");
INSERT INTO mast_income_heads VALUES("57","CONSOLIDATED SALARY ","","2","3","2021-09-01 02:01:34","2021-09-01 02:21:21");



CREATE TABLE `mast_leave_type` (
  `mast_leave_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `leave_type_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_leave_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_leave_type VALUES("1","Earn Leave","1","2","2017-07-13 11:21:15","2017-07-13 11:21:15");
INSERT INTO mast_leave_type VALUES("2","Casual Leave","1","2","2017-07-13 11:21:32","2017-07-13 11:21:32");
INSERT INTO mast_leave_type VALUES("3","Sick Leave","1","2","2017-07-13 11:21:44","2017-07-13 11:21:44");
INSERT INTO mast_leave_type VALUES("4","EARN LEAVE","2","3","2017-09-14 09:12:52","2017-09-14 09:12:52");
INSERT INTO mast_leave_type VALUES("5","CASUAL LEAVE","2","3","2017-09-14 09:16:48","2017-09-14 09:16:48");
INSERT INTO mast_leave_type VALUES("6","SICK LEAVE","2","3","2017-11-13 12:44:39","2017-11-13 12:44:39");



CREATE TABLE `mast_location` (
  `mast_location_id` int(11) NOT NULL AUTO_INCREMENT,
  `mast_location_name` varchar(50) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`mast_location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_location VALUES("1","PUNE","2","4","2017-09-20 17:05:32","2023-02-12 18:15:00");
INSERT INTO mast_location VALUES("2","PUNE","1","5","2022-09-15 03:05:50","2022-09-15 03:05:50");
INSERT INTO mast_location VALUES("3","SATARA","1","5","2022-09-15 03:05:56","2022-09-15 03:05:56");
INSERT INTO mast_location VALUES("4","KOLHAPUR","1","5","2022-09-15 03:06:05","2022-09-15 03:06:05");
INSERT INTO mast_location VALUES("5","SANGLI","2","4","2023-03-28 22:24:16","2023-03-28 22:40:24");



CREATE TABLE `mast_other_payment` (
  `op_id` bigint(20) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `op_name` varchar(255) NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`op_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO mast_other_payment VALUES("1","2","4","ADVANCE AMT","2022-09-18 20:30:21","2022-09-18 20:30:21");
INSERT INTO mast_other_payment VALUES("2","2","4","TEST","2022-09-18 20:39:02","2022-09-18 20:43:20");
INSERT INTO mast_other_payment VALUES("3","2","4","FUEL CHARGES","2022-09-20 05:05:28","2022-09-20 05:12:58");
INSERT INTO mast_other_payment VALUES("4","2","4","MATERIAL HANDLING","2022-09-24 04:15:43","2022-09-24 04:15:43");
INSERT INTO mast_other_payment VALUES("5","2","4","DRESS","2022-09-24 04:15:49","2022-09-24 04:15:49");
INSERT INTO mast_other_payment VALUES("6","2","4","SUNDAY WORKING","2022-09-24 04:15:58","2022-09-24 04:15:58");
INSERT INTO mast_other_payment VALUES("7","2","4","HOLIDAY WORKING","2022-09-24 04:16:04","2022-09-24 04:16:04");
INSERT INTO mast_other_payment VALUES("8","1","5","RE DRESS","2023-08-03 05:25:53","2023-08-03 05:25:53");
INSERT INTO mast_other_payment VALUES("9","2","4","CLEANING","2023-08-03 23:11:33","2023-08-03 23:11:33");
INSERT INTO mast_other_payment VALUES("10","1","5","TESTBYASHA","2023-08-04 00:19:29","2023-08-04 00:19:48");

