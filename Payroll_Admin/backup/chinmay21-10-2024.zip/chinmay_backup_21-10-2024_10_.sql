

CREATE TABLE `bonus` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `from_date` date NOT NULL,
  `todate` date NOT NULL,
  `client_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `bankacno` varchar(30) NOT NULL,
  `pay_mode` varchar(1) NOT NULL,
  `tot_bonus_amt` float NOT NULL,
  `tot_exgratia_amt` float NOT NULL,
  `tot_payable_days` decimal(10,0) DEFAULT NULL,
  `calc_type` float NOT NULL,
  `apr_wages` float NOT NULL,
  `apr_bonus_wages` float NOT NULL,
  `apr_payable_days` float NOT NULL,
  `apr_bonus_amt` float NOT NULL,
  `apr_exgratia_amt` float NOT NULL,
  `may_wages` float NOT NULL,
  `may_bonus_wages` float NOT NULL,
  `may_payable_days` float NOT NULL,
  `may_bonus_amt` float NOT NULL,
  `may_exgratia_amt` float NOT NULL,
  `jun_wages` float NOT NULL,
  `jun_bonus_wages` float NOT NULL,
  `jun_payable_days` float NOT NULL,
  `jun_bonus_amt` float NOT NULL,
  `jun_exgratia_amt` float NOT NULL,
  `jul_wages` float NOT NULL,
  `jul_bonus_wages` float NOT NULL,
  `jul_payable_days` float NOT NULL,
  `jul_bonus_amt` float NOT NULL,
  `jul_exgratia_amt` float NOT NULL,
  `aug_wages` float NOT NULL,
  `aug_bonus_wages` float NOT NULL,
  `aug_payable_days` float NOT NULL,
  `aug_bonus_amt` float NOT NULL,
  `aug_exgratia_amt` float NOT NULL,
  `sep_wages` float NOT NULL,
  `sep_bonus_wages` float NOT NULL,
  `sep_payable_days` float NOT NULL,
  `sep_bonus_amt` float NOT NULL,
  `sep_exgratia_amt` float NOT NULL,
  `oct_wages` float NOT NULL,
  `oct_bonus_wages` float NOT NULL,
  `oct_payable_days` float NOT NULL,
  `oct_bonus_amt` float NOT NULL,
  `oct_exgratia_amt` float NOT NULL,
  `nov_wages` float NOT NULL,
  `nov_bonus_wages` float NOT NULL,
  `nov_payable_days` float NOT NULL,
  `nov_bonus_amt` float NOT NULL,
  `nov_exgratia_amt` float NOT NULL,
  `dec_wages` float NOT NULL,
  `dec_bonus_wages` float NOT NULL,
  `dec_payable_days` float NOT NULL,
  `dec_bonus_amt` float NOT NULL,
  `dec_exgratia_amt` float NOT NULL,
  `jan_wages` float NOT NULL,
  `jan_bonus_wages` float NOT NULL,
  `jan_payable_days` float NOT NULL,
  `jan_bonus_amt` float NOT NULL,
  `jan_exgratia_amt` float NOT NULL,
  `feb_wages` float NOT NULL,
  `feb_bonus_wages` float NOT NULL,
  `feb_payable_days` float NOT NULL,
  `feb_bonus_amt` float NOT NULL,
  `feb_exgratia_amt` float NOT NULL,
  `mar_wages` float NOT NULL,
  `mar_bonus_wages` float NOT NULL,
  `mar_payable_days` float NOT NULL,
  `mar_bonus_amt` float NOT NULL,
  `mar_exgratia_amt` float NOT NULL,
  `bonus_rate` float NOT NULL,
  `exgratia_rate` float NOT NULL,
  `payment_date` date DEFAULT NULL,
  `locked` varchar(1) NOT NULL,
  `user_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `updated` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO bonus VALUES("1","2024-08-01","2024-08-29","2","84","1","1321546548","b","5000","3000","320","1","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","20","0","200","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","2024-08-30","","5","1","2024-08-29 23:21:51");
INSERT INTO bonus VALUES("2","2024-08-01","2024-08-29","3","83","2","1321546548","b","6000","3000","320","1","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","26","0","500","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","0","2024-08-30","","5","1","2024-08-29 23:21:51");



CREATE TABLE `caltype_bonus` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO caltype_bonus VALUES("1","(Basic + DA)*8.33","2017-11-29 17:36:53","2017-11-29 17:36:53");
INSERT INTO caltype_bonus VALUES("2","Limit to Amount(7000)","2017-12-04 18:34:54","2017-12-04 18:34:54");
INSERT INTO caltype_bonus VALUES("3","Max Wages(Baker)","2018-04-27 15:41:22","2018-04-27 15:41:22");



CREATE TABLE `caltype_deduct` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO caltype_deduct VALUES("1","Month's Days - Weeklyoff(26/27)","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_deduct VALUES("2","Month's Days - (30/31)","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_deduct VALUES("3","Consolidated","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_deduct VALUES("4","Hourly Basis","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_deduct VALUES("5","Daily Basis","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_deduct VALUES("6","Quarterly","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_deduct VALUES("7","As per Govt. Rules","2017-08-21 11:47:21","2017-08-21 11:47:21");



CREATE TABLE `caltype_income` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `db_adddate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO caltype_income VALUES("1","Month's Days - Weeklyoff(26/27)","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_income VALUES("2","Month's Days - 30 Fixed","2017-08-21 11:45:04","2017-08-21 11:45:04");
INSERT INTO caltype_income VALUES("3","Consolidated","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_income VALUES("4","Hourly Basis","2017-08-21 11:45:34","2017-08-21 11:45:34");
INSERT INTO caltype_income VALUES("5","Daily Basis","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_income VALUES("6","Quarterly","2017-08-21 11:45:58","2017-08-21 11:45:58");
INSERT INTO caltype_income VALUES("7","Gross Salary/8 *2","2017-08-24 11:13:53","2017-08-24 11:13:53");
INSERT INTO caltype_income VALUES("8","Per Shift Rs.20 if <= 15 else Rs.27 if >15","2017-09-21 13:02:01","2017-09-21 13:02:01");
INSERT INTO caltype_income VALUES("9","Per Shift Rs.25 if <= 15 else Rs.34.5 if >15","2017-09-21 13:02:01","2017-09-21 13:02:01");
INSERT INTO caltype_income VALUES("10","Per Shift","2017-11-27 06:54:24","2017-11-27 06:54:24");
INSERT INTO caltype_income VALUES("11","(GROSS-CONVEYANCE)/8*2","2017-11-27 06:41:01","2017-11-27 06:41:01");
INSERT INTO caltype_income VALUES("12","GORSS SALARY /8","2017-11-27 06:41:38","2017-11-27 06:41:38");
INSERT INTO caltype_income VALUES("13","(BASIC+DA)/8*2","2017-11-27 06:41:01","2017-11-27 06:41:01");
INSERT INTO caltype_income VALUES("14"," 26 Days Per Month","2017-11-29 14:30:08","2017-11-29 14:30:08");
INSERT INTO caltype_income VALUES("15","Per Hour","2017-12-19 14:41:26","2017-12-19 14:41:26");
INSERT INTO caltype_income VALUES("16","Per Present Day","2018-01-13 12:39:39","2018-01-13 12:39:39");



CREATE TABLE `cheque_details` (
  `chk_detail_id` int(11) NOT NULL AUTO_INCREMENT,
  `emp_id` int(11) NOT NULL,
  `check_no` int(11) NOT NULL,
  `sal_month` date NOT NULL,
  `amount` float NOT NULL,
  `date` date NOT NULL,
  `type` varchar(1) DEFAULT NULL,
  `payment_date` date DEFAULT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `bill_no` varchar(30) DEFAULT NULL,
  `db_addate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`chk_detail_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;




CREATE TABLE `client_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `group_name` varchar(100) NOT NULL,
  `pfcode` varchar(30) NOT NULL,
  `esicode` varchar(30) NOT NULL,
  `created_by` tinyint(2) NOT NULL,
  `created_on` datetime NOT NULL,
  `updated_by` tinyint(2) NOT NULL,
  `updated_on` datetime NOT NULL,
  `db_date` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `db_update` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=4 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO client_group VALUES("1","Not Applicable","","","4","0000-00-00 00:00:00","0","0000-00-00 00:00:00","2024-08-27 03:26:31","2020-06-22 00:00:00");
INSERT INTO client_group VALUES("2","CHINMAY HOSPITALITY SERVICES","PUPUN1004127000","33000459910001001","5","2024-09-30 03:09:26","0","2024-09-30 03:09:26","2024-10-20 00:32:25","2024-10-20 00:32:25");
INSERT INTO client_group VALUES("3","V D SHETTY","PUPUN0018631000","330000805811199","5","2024-10-20 00:31:49","0","0000-00-00 00:00:00","2024-10-20 00:31:49","2024-10-20 00:31:49");



CREATE TABLE `emp_advnacen` (
  `emp_advnacen_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` varchar(20) NOT NULL,
  `adv_amount` varchar(20) NOT NULL,
  `adv_installment` varchar(20) NOT NULL,
  `advance_type_id` int(11) NOT NULL,
  `closed_on` date NOT NULL DEFAULT '0000-00-00',
  `received_amt` float NOT NULL,
  `received_amt1` float NOT NULL,
  `db_addate` datetime NOT NULL,
  `db_update` datetime NOT NULL,
  PRIMARY KEY (`emp_advnacen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO emp_advnacen VALUES("1","1","22","5","1970-01-01","1","1","1","1970-01-01","0","0","2024-10-10 22:40:12","0000-00-00 00:00:00");



CREATE TABLE `emp_deduct` (
  `emp_deduct_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `head_id` int(11) NOT NULL,
  `calc_type` varchar(20) NOT NULL,
  `std_amt` decimal(15,2) NOT NULL,
  `remark` varchar(100) NOT NULL,
  `bank_id` int(11) NOT NULL,
  `db_addate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `ticket_no` varchar(6) NOT NULL,
  PRIMARY KEY (`emp_deduct_id`),
  UNIQUE KEY `Deduct` (`emp_id`,`head_id`)
) ENGINE=InnoDB AUTO_INCREMENT=710 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO emp_deduct VALUES("1","1","1","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("2","1","1","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("3","1","1","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("4","1","1","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("5","1","1","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("6","1","2","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("7","1","2","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("8","1","2","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("9","1","2","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("10","1","2","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("11","1","3","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("12","1","3","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("13","1","3","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("14","1","3","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("15","1","3","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("16","1","4","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("17","1","4","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("18","1","4","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("19","1","4","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("20","1","4","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("21","1","5","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("22","1","5","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("23","1","5","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("24","1","5","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("25","1","5","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("26","1","6","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("27","1","6","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("28","1","6","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("29","1","6","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("30","1","6","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("31","1","7","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("32","1","7","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("33","1","7","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("34","1","7","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("35","1","7","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("36","1","8","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("37","1","8","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("38","1","8","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("39","1","8","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("40","1","8","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("41","1","9","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("42","1","9","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("43","1","9","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("44","1","9","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("45","1","9","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("46","1","10","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("47","1","10","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("48","1","10","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("49","1","10","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("50","1","10","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("51","1","11","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("52","1","11","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("53","1","11","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("54","1","11","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("55","1","11","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("56","1","12","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("57","1","12","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("58","1","12","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("59","1","12","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("60","1","12","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("61","1","13","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("62","1","13","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("63","1","13","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("64","1","13","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("65","1","13","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("66","1","14","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("67","1","14","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("68","1","14","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("69","1","14","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("70","1","14","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("71","1","15","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("72","1","15","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("73","1","15","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("74","1","15","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("75","1","15","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("76","1","16","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("77","1","16","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("78","1","16","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("79","1","16","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("80","1","16","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("81","1","17","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("82","1","17","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("83","1","17","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("84","1","17","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("85","1","17","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("86","1","18","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("87","1","18","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("88","1","18","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("89","1","18","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("90","1","18","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("91","1","19","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("92","1","19","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("93","1","19","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("94","1","19","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("95","1","19","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("96","1","20","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("97","1","20","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("98","1","20","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("99","1","20","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("100","1","20","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("101","1","21","6","1","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("102","1","21","6","2","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("103","1","21","6","3","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("104","1","21","6","4","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("105","1","21","6","5","7","0.00","","0","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_deduct VALUES("106","1","22","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("107","1","22","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("108","1","22","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("109","1","22","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("110","1","22","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("111","1","23","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("112","1","23","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("113","1","23","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("114","1","23","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("115","1","23","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("116","1","24","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("117","1","24","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("118","1","24","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("119","1","24","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("120","1","24","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("121","1","25","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("122","1","25","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("123","1","25","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("124","1","25","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("125","1","25","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("126","1","26","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("127","1","26","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("128","1","26","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("129","1","26","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("130","1","26","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("131","1","27","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("132","1","27","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("133","1","27","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("134","1","27","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("135","1","27","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("136","1","28","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("137","1","28","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("138","1","28","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("139","1","28","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("140","1","28","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("141","1","29","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("142","1","29","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("143","1","29","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("144","1","29","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("145","1","29","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("146","1","30","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("147","1","30","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("148","1","30","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("149","1","30","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("150","1","30","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("151","1","31","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("152","1","31","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("153","1","31","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("154","1","31","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("155","1","31","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("156","1","32","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("157","1","32","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("158","1","32","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("159","1","32","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("160","1","32","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("161","1","33","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("162","1","33","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("163","1","33","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("164","1","33","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("165","1","33","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("166","1","34","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("167","1","34","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("168","1","34","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("169","1","34","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("170","1","34","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("171","1","35","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("172","1","35","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("173","1","35","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("174","1","35","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("175","1","35","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("176","1","36","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("177","1","36","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("178","1","36","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("179","1","36","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("180","1","36","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("181","1","37","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("182","1","37","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("183","1","37","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("184","1","37","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("185","1","37","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("186","1","38","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("187","1","38","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("188","1","38","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("189","1","38","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("190","1","38","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("191","1","39","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("192","1","39","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("193","1","39","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("194","1","39","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("195","1","39","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("196","1","40","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("197","1","40","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("198","1","40","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("199","1","40","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("200","1","40","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("201","1","41","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("202","1","41","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("203","1","41","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("204","1","41","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("205","1","41","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("206","1","42","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("207","1","42","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("208","1","42","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("209","1","42","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("211","1","43","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("212","1","43","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("213","1","43","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("214","1","43","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("215","1","43","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("216","1","44","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("217","1","44","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("218","1","44","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("219","1","44","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("220","1","44","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("221","1","45","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("222","1","45","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("223","1","45","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("224","1","45","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("225","1","45","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("226","1","46","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("227","1","46","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("228","1","46","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("229","1","46","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("230","1","46","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("231","1","47","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("232","1","47","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("233","1","47","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("234","1","47","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("235","1","47","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("236","1","48","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("237","1","48","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("238","1","48","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("239","1","48","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("240","1","48","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("241","1","49","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("242","1","49","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("243","1","49","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("244","1","49","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("245","1","49","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("246","1","50","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("247","1","50","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("248","1","50","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("249","1","50","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("250","1","50","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("251","1","51","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("252","1","51","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("253","1","51","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("254","1","51","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("255","1","51","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("256","1","52","6","1","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("257","1","52","6","2","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("258","1","52","6","3","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("259","1","52","6","4","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("260","1","52","6","5","7","0.00","","0","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_deduct VALUES("381","1","53","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("382","1","53","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("383","1","53","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("384","1","53","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("385","1","53","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("386","1","54","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("387","1","54","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("388","1","54","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("389","1","54","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("390","1","54","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("391","1","55","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("392","1","55","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("393","1","55","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("394","1","55","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("395","1","55","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("396","1","56","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("397","1","56","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("398","1","56","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("399","1","56","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("400","1","56","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("401","1","57","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("402","1","57","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("403","1","57","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("404","1","57","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("405","1","57","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("406","1","58","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("407","1","58","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("408","1","58","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("409","1","58","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("410","1","58","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("411","1","59","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("412","1","59","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("413","1","59","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("414","1","59","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("415","1","59","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("416","1","60","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("417","1","60","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("418","1","60","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("419","1","60","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("420","1","60","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("421","1","61","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("422","1","61","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("423","1","61","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("424","1","61","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("425","1","61","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("426","1","62","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("427","1","62","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("428","1","62","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("429","1","62","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("430","1","62","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("431","1","63","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("432","1","63","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("433","1","63","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("434","1","63","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("435","1","63","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("436","1","64","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("437","1","64","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("438","1","64","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("439","1","64","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("440","1","64","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("441","1","65","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("442","1","65","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("443","1","65","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("444","1","65","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("445","1","65","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("446","1","66","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("447","1","66","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("448","1","66","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("449","1","66","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("450","1","66","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("451","1","67","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("452","1","67","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("453","1","67","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("454","1","67","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("455","1","67","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("456","1","68","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("457","1","68","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("458","1","68","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("459","1","68","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("460","1","68","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("461","1","69","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("462","1","69","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("463","1","69","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("464","1","69","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("465","1","69","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("466","1","70","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("467","1","70","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("468","1","70","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("469","1","70","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("470","1","70","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("471","1","71","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("472","1","71","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("473","1","71","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("474","1","71","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("475","1","71","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("476","1","72","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("477","1","72","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("478","1","72","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("479","1","72","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("480","1","72","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("481","1","73","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("482","1","73","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("483","1","73","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("484","1","73","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("485","1","73","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("486","1","74","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("487","1","74","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("488","1","74","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("489","1","74","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("490","1","74","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("491","1","75","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("492","1","75","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("493","1","75","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("494","1","75","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("495","1","75","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("496","1","76","6","1","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("497","1","76","6","2","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("498","1","76","6","3","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("499","1","76","6","4","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("500","1","76","6","5","7","0.00","","0","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_deduct VALUES("501","1","77","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("502","1","77","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("503","1","77","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("504","1","77","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("505","1","77","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("506","1","78","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("507","1","78","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("508","1","78","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("509","1","78","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("510","1","78","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("511","1","79","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("512","1","79","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("513","1","79","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("514","1","79","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("515","1","79","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("516","1","80","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("517","1","80","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("518","1","80","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("519","1","80","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("520","1","80","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("521","1","81","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("522","1","81","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("523","1","81","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("524","1","81","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("525","1","81","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("526","1","82","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("527","1","82","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("528","1","82","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("529","1","82","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("530","1","82","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("531","1","83","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("532","1","83","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("533","1","83","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("534","1","83","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("535","1","83","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("536","1","84","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("537","1","84","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("538","1","84","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("539","1","84","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("540","1","84","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("541","1","85","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("542","1","85","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("543","1","85","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("544","1","85","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("545","1","85","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("546","1","86","6","1","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("547","1","86","6","2","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("548","1","86","6","3","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("549","1","86","6","4","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("550","1","86","6","5","7","0.00","","0","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_deduct VALUES("556","1","87","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("557","1","87","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("558","1","87","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("559","1","87","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("560","1","87","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("561","1","88","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("562","1","88","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("563","1","88","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("564","1","88","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("565","1","88","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("566","1","89","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("567","1","89","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("568","1","89","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("569","1","89","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("570","1","89","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("571","1","90","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("572","1","90","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("573","1","90","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("574","1","90","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("575","1","90","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("576","1","91","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("577","1","91","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("578","1","91","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("579","1","91","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("580","1","91","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("581","1","92","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("582","1","92","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("583","1","92","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("584","1","92","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("585","1","92","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("586","1","93","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("587","1","93","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("588","1","93","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("589","1","93","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("590","1","93","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("591","1","94","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("592","1","94","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("593","1","94","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("594","1","94","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("595","1","94","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("596","1","95","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("597","1","95","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("598","1","95","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("599","1","95","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("600","1","95","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("601","1","96","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("602","1","96","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("603","1","96","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("604","1","96","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("605","1","96","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("606","1","97","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("607","1","97","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("608","1","97","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("609","1","97","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("610","1","97","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("611","1","98","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("612","1","98","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("613","1","98","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("614","1","98","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("615","1","98","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("616","1","99","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("617","1","99","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("618","1","99","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("619","1","99","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("620","1","99","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("621","1","100","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("622","1","100","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("623","1","100","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("624","1","100","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("625","1","100","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("626","1","101","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("627","1","101","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("628","1","101","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("629","1","101","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("630","1","101","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("631","1","102","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("632","1","102","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("633","1","102","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("634","1","102","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("635","1","102","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("636","1","103","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("637","1","103","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("638","1","103","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("639","1","103","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("640","1","103","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("641","1","104","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("642","1","104","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("643","1","104","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("644","1","104","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("645","1","104","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("646","1","105","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("647","1","105","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("648","1","105","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("649","1","105","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("650","1","105","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("651","1","106","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("652","1","106","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("653","1","106","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("654","1","106","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("655","1","106","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("656","1","107","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("657","1","107","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("658","1","107","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("659","1","107","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("660","1","107","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("661","1","108","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("662","1","108","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("663","1","108","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("664","1","108","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("665","1","108","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("666","1","109","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("667","1","109","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("668","1","109","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("669","1","109","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("670","1","109","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("671","1","110","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("672","1","110","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("673","1","110","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("674","1","110","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("675","1","110","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("676","1","111","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("677","1","111","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("678","1","111","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("679","1","111","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("680","1","111","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("681","1","112","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("682","1","112","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("683","1","112","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("684","1","112","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("685","1","112","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("686","1","113","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("687","1","113","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("688","1","113","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("689","1","113","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("690","1","113","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("691","1","114","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("692","1","114","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("693","1","114","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("694","1","114","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("695","1","114","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("696","1","115","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("697","1","115","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("698","1","115","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("699","1","115","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("700","1","115","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("701","1","116","6","1","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("702","1","116","6","2","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("703","1","116","6","3","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("704","1","116","6","4","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("705","1","116","6","5","7","0.00","","0","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_deduct VALUES("706","1","117","5","1","7","0.00","","0","2024-10-18 02:56:31","2024-10-18 04:25:03","");
INSERT INTO emp_deduct VALUES("707","1","117","5","2","7","0.00","","0","2024-10-18 02:56:40","2024-10-18 04:24:50","");
INSERT INTO emp_deduct VALUES("708","1","117","5","3","7","0.00","","0","2024-10-18 02:56:51","2024-10-18 02:56:51","");
INSERT INTO emp_deduct VALUES("709","1","117","5","4","7","0.00","","0","2024-10-18 02:57:00","2024-10-18 02:57:00","");



CREATE TABLE `emp_income` (
  `emp_income_id` int(11) NOT NULL AUTO_INCREMENT,
  `comp_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `head_id` int(11) NOT NULL,
  `calc_type` varchar(20) NOT NULL,
  `std_amt` decimal(15,2) NOT NULL,
  `remark` varchar(100) DEFAULT NULL,
  `db_addate` datetime NOT NULL DEFAULT current_timestamp(),
  `db_update` datetime NOT NULL DEFAULT current_timestamp(),
  `ticket_no` varchar(6) NOT NULL,
  PRIMARY KEY (`emp_income_id`)
) ENGINE=InnoDB AUTO_INCREMENT=623 DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

INSERT INTO emp_income VALUES("1","1","1","6","1","2","7100.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("2","1","1","6","2","2","7900.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("3","1","1","6","4","2","3750.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("4","1","1","6","5","2","300.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("5","1","1","6","6","2","709.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("6","1","1","6","7","2","198.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("7","1","1","6","8","2","500.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("8","1","1","6","9","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("9","1","2","6","1","2","7100.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("10","1","2","6","2","2","7900.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("11","1","2","6","4","2","3750.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("12","1","2","6","5","2","300.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("13","1","2","6","6","2","709.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("14","1","2","6","7","2","198.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("15","1","2","6","8","2","500.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("16","1","2","6","9","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("17","1","3","6","1","2","7100.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("18","1","3","6","2","2","7900.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("19","1","3","6","4","2","3750.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("20","1","3","6","5","2","300.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("21","1","3","6","6","2","709.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("22","1","3","6","7","2","198.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("23","1","3","6","8","2","500.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("24","1","3","6","9","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("25","1","4","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("26","1","4","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("27","1","4","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("28","1","4","6","5","2","329.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("29","1","4","6","6","2","499.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("30","1","4","6","9","2","1634.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("31","1","5","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("32","1","5","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("33","1","5","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("34","1","5","6","5","2","329.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("35","1","5","6","6","2","499.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("36","1","5","6","9","2","1634.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("37","1","6","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("38","1","6","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("39","1","6","6","4","2","1028.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("40","1","6","6","5","2","752.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("41","1","6","6","6","2","130.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("42","1","6","6","8","2","749.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("43","1","6","6","9","2","302.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("44","1","7","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("45","1","7","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("46","1","7","6","4","2","1028.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("47","1","7","6","5","2","752.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("48","1","7","6","6","2","130.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("49","1","7","6","8","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("50","1","7","6","9","2","302.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("51","1","8","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("52","1","8","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("53","1","8","6","4","2","1028.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("54","1","8","6","5","2","752.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("55","1","8","6","6","2","130.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("56","1","8","6","8","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("57","1","8","6","9","2","302.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("58","1","9","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("59","1","9","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("60","1","9","6","4","2","1028.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("61","1","9","6","5","2","752.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("62","1","9","6","6","2","130.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("63","1","9","6","8","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("64","1","9","6","9","2","302.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("65","1","10","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("66","1","10","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("67","1","10","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("68","1","10","6","5","2","1455.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("69","1","11","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("70","1","11","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("71","1","11","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("72","1","11","6","5","2","1455.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("73","1","12","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("74","1","12","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("75","1","12","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("76","1","12","6","5","2","1455.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("77","1","13","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("78","1","13","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("79","1","13","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("80","1","13","6","9","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("81","1","14","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("82","1","14","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("83","1","14","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("84","1","14","6","9","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("85","1","15","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("86","1","15","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("87","1","15","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("88","1","15","6","9","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("89","1","16","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("90","1","16","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("91","1","16","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("92","1","16","6","9","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("93","1","17","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("94","1","17","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("95","1","17","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("96","1","17","6","9","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("97","1","18","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("98","1","18","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("99","1","18","6","4","2","700.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("100","1","18","6","9","2","447.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("101","1","19","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("102","1","19","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("103","1","19","6","4","2","744.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("104","1","20","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("105","1","20","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("106","1","20","6","4","2","744.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("107","1","21","6","1","2","6600.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("108","1","21","6","3","2","7224.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("109","1","21","6","4","2","744.00","","2024-10-07 05:27:20","2024-10-07 05:27:20","");
INSERT INTO emp_income VALUES("110","1","22","6","1","2","7700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("111","1","22","6","2","2","7300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("112","1","22","6","4","2","3750.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("113","1","22","6","5","2","300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("114","1","22","6","6","2","709.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("115","1","22","6","7","2","198.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("116","1","22","6","8","2","500.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("117","1","22","6","9","2","700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("118","1","23","6","1","2","7700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("119","1","23","6","2","2","7300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("120","1","23","6","4","2","3750.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("121","1","23","6","5","2","300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("122","1","23","6","6","2","709.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("123","1","23","6","7","2","198.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("124","1","23","6","8","2","500.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("125","1","23","6","9","2","700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("126","1","24","6","1","2","7700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("127","1","24","6","2","2","7300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("128","1","24","6","4","2","3750.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("129","1","24","6","5","2","300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("130","1","24","6","6","2","709.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("131","1","24","6","7","2","198.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("132","1","24","6","8","2","500.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("133","1","24","6","9","2","700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("134","1","25","6","1","2","7700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("135","1","25","6","2","2","7300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("136","1","25","6","4","2","3750.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("137","1","25","6","5","2","300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("138","1","25","6","6","2","709.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("139","1","25","6","7","2","198.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("140","1","25","6","8","2","500.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("141","1","25","6","9","2","700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("142","1","26","6","1","2","7700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("143","1","26","6","2","2","7300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("144","1","26","6","4","2","3750.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("145","1","26","6","5","2","300.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("146","1","26","6","6","2","709.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("147","1","26","6","7","2","198.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("148","1","26","6","8","2","500.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("149","1","26","6","9","2","700.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("150","1","27","6","1","2","7100.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("151","1","27","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("152","1","27","6","4","2","1579.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("153","1","27","6","5","2","504.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("154","1","27","6","6","2","135.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("155","1","27","5","8","2","520.00","","2024-10-07 05:28:11","2024-10-18 03:47:02","");
INSERT INTO emp_income VALUES("156","1","27","5","9","2","2000.00","","2024-10-07 05:28:11","2024-10-18 03:47:16","");
INSERT INTO emp_income VALUES("157","1","28","6","1","2","7100.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("158","1","28","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("159","1","28","6","4","2","1579.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("160","1","28","6","5","2","504.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("161","1","28","6","6","2","135.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("162","1","28","5","8","2","520.00","","2024-10-07 05:28:11","2024-10-18 03:54:52","");
INSERT INTO emp_income VALUES("163","1","28","5","9","2","2000.00","","2024-10-07 05:28:11","2024-10-18 03:55:11","");
INSERT INTO emp_income VALUES("164","1","29","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("165","1","29","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("166","1","29","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("167","1","30","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("168","1","30","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("169","1","30","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("170","1","31","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("171","1","31","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("172","1","31","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("173","1","32","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("174","1","32","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("175","1","32","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("176","1","33","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("177","1","33","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("178","1","33","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("179","1","34","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("180","1","34","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("181","1","34","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("182","1","35","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("183","1","35","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("184","1","35","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("185","1","36","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("186","1","36","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("187","1","36","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("188","1","37","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("189","1","37","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("190","1","37","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("191","1","38","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("192","1","38","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("193","1","38","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("194","1","39","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("195","1","39","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("196","1","39","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("197","1","40","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("198","1","40","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("199","1","40","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("200","1","41","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("201","1","41","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("202","1","41","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("203","1","42","5","1","2","7100.00","","2024-10-07 05:28:11","2024-10-18 03:32:51","");
INSERT INTO emp_income VALUES("204","1","42","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("205","1","42","5","4","2","1579.00","","2024-10-07 05:28:11","2024-10-18 03:33:18","");
INSERT INTO emp_income VALUES("206","1","43","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("207","1","43","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("208","1","43","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("209","1","44","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("210","1","44","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("211","1","44","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("212","1","45","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("213","1","45","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("214","1","45","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("215","1","46","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("216","1","46","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("217","1","46","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("218","1","47","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("219","1","47","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("220","1","47","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("221","1","48","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("222","1","48","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("223","1","48","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("224","1","49","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("225","1","49","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("226","1","49","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("227","1","50","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("228","1","50","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("229","1","50","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("230","1","51","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("231","1","51","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("232","1","51","6","4","2","691.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("233","1","52","6","1","2","6600.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("234","1","52","6","3","2","7224.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("235","1","52","6","4","2","1147.00","","2024-10-07 05:28:11","2024-10-07 05:28:11","");
INSERT INTO emp_income VALUES("335","1","53","6","1","2","7100.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("336","1","53","6","2","2","7900.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("337","1","53","6","4","2","3750.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("338","1","53","6","5","2","300.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("339","1","53","6","6","2","709.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("340","1","53","6","7","2","198.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("341","1","53","6","8","2","500.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("342","1","53","6","9","2","700.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("343","1","54","6","1","2","7100.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("344","1","54","6","2","2","7900.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("345","1","54","6","4","2","3750.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("346","1","54","6","5","2","300.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("347","1","54","6","6","2","709.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("348","1","54","6","7","2","198.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("349","1","54","6","8","2","500.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("350","1","54","6","9","2","700.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("351","1","55","6","1","2","7100.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("352","1","55","6","2","2","7900.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("353","1","55","6","4","2","3750.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("354","1","55","6","5","2","300.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("355","1","55","6","6","2","709.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("356","1","55","6","7","2","198.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("357","1","55","6","8","2","500.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("358","1","55","6","9","2","700.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("359","1","56","6","1","2","7100.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("360","1","56","6","2","2","7900.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("361","1","56","6","4","2","3750.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("362","1","56","6","6","2","701.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("363","1","56","6","9","2","700.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("364","1","57","6","1","2","7100.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("365","1","57","6","2","2","7900.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("366","1","57","6","4","2","3750.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("367","1","57","6","6","2","197.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("368","1","57","6","9","2","700.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("369","1","58","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("370","1","58","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("371","1","58","6","4","2","1147.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("372","1","59","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("373","1","59","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("374","1","59","6","4","2","3162.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("375","1","60","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("376","1","60","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("377","1","60","6","4","2","3162.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("378","1","61","6","1","2","7100.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("379","1","61","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("380","1","61","6","4","2","1579.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("381","1","61","6","5","2","504.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("382","1","61","6","6","2","135.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("383","1","61","6","8","2","512.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("384","1","61","6","9","2","1000.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("385","1","62","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("386","1","62","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("387","1","62","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("388","1","63","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("389","1","63","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("390","1","63","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("391","1","64","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("392","1","64","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("393","1","64","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("394","1","65","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("395","1","65","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("396","1","65","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("397","1","66","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("398","1","66","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("399","1","66","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("400","1","67","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("401","1","67","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("402","1","67","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("403","1","68","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("404","1","68","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("405","1","68","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("406","1","69","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("407","1","69","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("408","1","69","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("409","1","70","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("410","1","70","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("411","1","70","6","4","2","1147.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("412","1","71","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("413","1","71","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("414","1","71","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("415","1","72","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("416","1","72","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("417","1","72","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("418","1","73","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("419","1","73","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("420","1","73","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("421","1","74","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("422","1","74","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("423","1","74","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("424","1","75","6","1","2","7100.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("425","1","75","6","2","2","7900.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("426","1","75","6","4","2","3750.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("427","1","75","6","5","2","500.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("428","1","75","6","6","2","205.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("429","1","75","6","8","2","500.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("430","1","75","6","9","2","700.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("431","1","76","6","1","2","6600.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("432","1","76","6","3","2","7224.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("433","1","76","6","4","2","691.00","","2024-10-08 01:17:06","2024-10-08 01:17:06","");
INSERT INTO emp_income VALUES("434","1","77","6","1","2","9000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("435","1","77","6","2","2","6000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("436","1","77","6","4","2","3000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("437","1","77","6","5","2","2000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("438","1","77","6","6","2","3000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("439","1","77","6","7","2","2000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("440","1","77","6","8","2","4000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("441","1","77","6","9","2","3000.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("442","1","78","6","1","2","7100.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("443","1","78","6","2","2","7900.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("444","1","78","6","4","2","3750.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("445","1","78","6","6","2","701.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("446","1","78","6","9","2","700.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("447","1","79","6","1","2","6600.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("448","1","79","6","3","2","7224.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("449","1","79","6","4","2","3162.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("450","1","80","6","1","2","6600.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("451","1","80","6","3","2","7224.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("452","1","80","6","4","2","691.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("453","1","81","6","1","2","6600.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("454","1","81","6","3","2","7224.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("455","1","81","6","4","2","691.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("456","1","82","6","1","2","6600.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("457","1","82","6","3","2","7224.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("458","1","82","6","4","2","691.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("459","1","83","6","1","2","6600.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("460","1","83","6","3","2","7224.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("461","1","83","6","4","2","691.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("462","1","84","6","1","2","6600.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("463","1","84","6","3","2","7224.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("464","1","84","6","4","2","691.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("465","1","85","6","1","2","7100.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("466","1","85","6","2","2","7900.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("467","1","85","6","4","2","3750.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("468","1","85","6","6","2","701.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("469","1","85","6","9","2","700.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("470","1","86","6","1","2","6600.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("471","1","86","6","3","2","7224.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("472","1","86","6","4","2","691.00","","2024-10-08 01:45:13","2024-10-08 01:45:13","");
INSERT INTO emp_income VALUES("473","1","87","6","1","2","7100.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("474","1","87","6","2","2","7900.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("475","1","87","6","4","2","3750.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("476","1","87","6","5","2","300.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("477","1","87","6","6","2","709.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("478","1","87","6","7","2","198.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("479","1","87","6","8","2","500.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("480","1","87","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("481","1","88","6","1","2","7100.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("482","1","88","6","2","2","7900.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("483","1","88","6","4","2","3750.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("484","1","88","6","5","2","300.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("485","1","88","6","6","2","709.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("486","1","88","6","7","2","198.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("487","1","88","6","8","2","500.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("488","1","88","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("489","1","89","6","1","2","7100.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("490","1","89","6","2","2","7900.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("491","1","89","6","4","2","3750.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("492","1","89","6","5","2","300.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("493","1","89","6","6","2","709.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("494","1","89","6","7","2","198.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("495","1","89","6","8","2","500.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("496","1","89","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("497","1","90","6","1","2","7100.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("498","1","90","6","2","2","7900.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("499","1","90","6","4","2","3750.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("500","1","90","6","5","2","300.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("501","1","90","6","6","2","709.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("502","1","90","6","7","2","198.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("503","1","90","6","8","2","500.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("504","1","90","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("505","1","91","6","1","2","7100.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("506","1","91","6","2","2","7900.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("507","1","91","6","4","2","3750.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("508","1","91","6","5","2","300.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("509","1","91","6","6","2","709.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("510","1","91","6","7","2","198.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("511","1","91","6","8","2","500.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("512","1","91","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("513","1","92","6","1","2","7100.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("514","1","92","6","2","2","7900.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("515","1","92","6","4","2","3750.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("516","1","92","6","6","2","701.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("517","1","92","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("518","1","93","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("519","1","93","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("520","1","93","6","4","2","3456.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("521","1","93","6","5","2","1021.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("522","1","93","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("523","1","94","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("524","1","94","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("525","1","94","6","4","2","3456.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("526","1","94","6","5","2","1021.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("527","1","94","6","9","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("528","1","95","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("529","1","95","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("530","1","95","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("531","1","95","6","5","2","1828.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("532","1","95","6","9","2","1642.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("533","1","96","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("534","1","96","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("535","1","96","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("536","1","96","6","6","2","458.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("537","1","96","6","9","2","2004.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("538","1","97","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("539","1","97","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("540","1","97","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("541","1","97","6","5","2","1828.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("542","1","97","6","9","2","1642.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("543","1","98","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("544","1","98","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("545","1","98","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("546","1","98","6","5","2","1828.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("547","1","98","6","9","2","1642.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("548","1","99","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("549","1","99","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("550","1","99","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("551","1","99","6","5","2","1828.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("552","1","99","6","9","2","1642.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("553","1","100","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("554","1","100","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("555","1","100","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("556","1","100","6","5","2","1455.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("557","1","101","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("558","1","101","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("559","1","101","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("560","1","101","6","5","2","1455.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("561","1","101","6","6","2","503.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("562","1","102","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("563","1","102","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("564","1","102","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("565","1","102","6","5","2","1455.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("566","1","103","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("567","1","103","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("568","1","103","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("569","1","103","6","5","2","1455.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("570","1","104","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("571","1","104","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("572","1","104","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("573","1","104","6","5","2","1455.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("574","1","105","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("575","1","105","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("576","1","105","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("577","1","105","6","5","2","1455.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("578","1","106","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("579","1","106","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("580","1","106","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("581","1","106","6","5","2","1455.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("582","1","107","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("583","1","107","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("584","1","107","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("585","1","108","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("586","1","108","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("587","1","108","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("588","1","109","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("589","1","109","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("590","1","109","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("591","1","110","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("592","1","110","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("593","1","110","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("594","1","111","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("595","1","111","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("596","1","111","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("597","1","112","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("598","1","112","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("599","1","112","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("600","1","113","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("601","1","113","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("602","1","113","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("603","1","114","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("604","1","114","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("605","1","114","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("606","1","115","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("607","1","115","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("608","1","115","6","4","2","714.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("609","1","116","6","1","2","6600.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("610","1","116","6","3","2","7224.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("611","1","116","6","4","2","700.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("612","1","116","6","6","2","458.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("613","1","116","6","9","2","2004.00","","2024-10-14 01:41:38","2024-10-14 01:41:38","");
INSERT INTO emp_income VALUES("614","1","117","5","1","2","6600.00","","2024-10-18 02:54:17","2024-10-18 02:54:17","");
INSERT INTO emp_income VALUES("615","1","117","5","3","2","7224.00","","2024-10-18 02:55:03","2024-10-18 02:55:03","");
INSERT INTO emp_income VALUES("616","1","117","5","4","2","691.00","","2024-10-18 02:55:28","2024-10-18 02:55:28","");
INSERT INTO emp_income VALUES("617","1","42","5","5","2","511.00","","2024-10-18 03:37:21","2024-10-18 03:37:21","");
INSERT INTO emp_income VALUES("618","1","42","5","6","2","135.00","","2024-10-18 03:37:39","2024-10-18 03:37:39","");
INSERT INTO emp_income VALUES("619","1","42","5","8","2","1520.00","","2024-10-18 03:37:54","2024-10-18 03:37:54","");
INSERT INTO emp_income VALUES("620","1","42","5","9","2","2000.00","","2024-10-18 03:38:04","2024-10-18 03:38:04","");
INSERT INTO emp_income VALUES("621","1","31","5","5","2","1008.00","","2024-10-18 03:58:36","2024-10-18 03:58:36","");
INSERT INTO emp_income VALUES("622","1","32","5","5","2","1008.00","","2024-10-18 04:28:43","2024-10-18 04:28:43","");



CREATE TABLE `emp_leave` (
  `leave_id` int(11) NOT NULL,
  `comp_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `emp_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `from_date` date DEFAULT NULL,
  `to_date` date DEFAULT NULL,
  `calculated_to` datetime NOT NULL,
  `calculated_from` datetime NOT NULL,
  `leave_type_id` int(11) NOT NULL,
  `granted` float NOT NULL,
  `carried_forward` float NOT NULL,
  `calculated` float NOT NULL,
  `ob` decimal(4,1) NOT NULL,
  `enjoyed` decimal(4,1) NOT NULL,
  `encashed` float NOT NULL,
  `db_adddate` datetime NOT NULL,
  `db_update` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;


