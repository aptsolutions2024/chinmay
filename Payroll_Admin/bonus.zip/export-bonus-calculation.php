<?php
 error_reporting(0);
session_start();

include("../lib/connection/db-config.php");
$setCounter = 0;
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$clintid=$_SESSION['clintid'];
$client = $_REQUEST['client'];
$startyear = date('Y-m-d',strtotime($_SESSION['startbonusyear']));
$endyear = date('Y-m-d',strtotime($_SESSION['endbonusyear']));



$setExcelName = "bonus_detail ";

$get_exgratia ="select sum(te.apr_exgratia_amt+te.may_exgratia_amt+te.jun_exgratia_amt+te.jul_exgratia_amt+te.aug_exgratia_amt+te.sep_exgratia_amt+te.oct_exgratia_amt+te.nov_exgratia_amt+te.dec_exgratia_amt+te.jan_exgratia_amt+te.feb_exgratia_amt+te.mar_exgratia_amt) as exgratia from employee emp inner join bonus te on te.emp_id = emp.emp_Id inner join mast_bank bk on bk.mast_bank_id = emp.bank_id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and (te.apr_payable_days + te.may_payable_days+te.jun_payable_days+te.jul_payable_days+te.aug_payable_days+te.sep_payable_days+te.oct_payable_days+te.nov_payable_days+te.dec_payable_days+te.jan_payable_days+te.feb_payable_days+te.mar_payable_days) >=0 and emp.prnsrno !='Y'"; 
  $result = mysql_query($get_exgratia);
  $check_ex_amt = mysql_fetch_assoc($result);
//print_r($check_ex_amt);
if ($check_ex_amt['exgratia'] > 0 && $sql_exgratia['exgratia'])
{

  $setSql ="select emp.emp_id,emp.first_name,emp.middle_name,emp.last_name,emp.joindate,emp.leftdate,te.client_id,round(te.apr_wages,2) as apr_wages,te.apr_bonus_wages,te.apr_payable_days,te.apr_bonus_amt,te.apr_exgratia_amt,round(te.may_wages,2) as may_wages,te.may_bonus_wages,te.may_payable_days,te.may_bonus_amt,te.may_exgratia_amt,round(te.jun_wages,2)  as jun_wages, te.jun_bonus_wages, te.jun_payable_days, te.jun_bonus_amt, te.jun_exgratia_amt,round( te.jul_wages,2) as jul_wages, te.jul_bonus_wages, te.jul_payable_days, te.jul_bonus_amt, te.jul_exgratia_amt, round(te.aug_wages,2) as aug_wages, te.aug_bonus_wages, te.aug_payable_days, te.aug_bonus_amt, te.aug_exgratia_amt, round(te.sep_wages,2) as sep_wages, te.sep_bonus_wages, te.sep_payable_days, te.sep_bonus_amt, te.sep_exgratia_amt, round(te.oct_wages,2) as oct_wages, te.oct_bonus_wages, te.oct_payable_days, te.oct_bonus_amt, te.oct_exgratia_amt, round(te.nov_wages) as nov_wages, te.nov_bonus_wages, te.nov_payable_days, te.nov_bonus_amt, te.nov_exgratia_amt, round(te.dec_wages,2) as dec_wages, te.dec_bonus_wages, te.dec_payable_days, te.dec_bonus_amt, te.dec_exgratia_amt, round(te.jan_wages,2) as jan_wages, te.jan_bonus_wages, te.jan_payable_days, te.jan_bonus_amt, te.jan_exgratia_amt,round( te.feb_wages,2) as feb_wages, te.feb_bonus_wages, te.feb_payable_days, te.feb_bonus_amt, te.feb_exgratia_amt, round(te.mar_wages,2) as mar_wages, te.mar_bonus_wages, te.mar_payable_days,  te.mar_bonus_amt, te.mar_exgratia_amt,round(te.apr_bonus_wages+te.may_bonus_wages+te.jun_bonus_wages+te.jul_bonus_wages+te.aug_bonus_wages+te.sep_bonus_wages+te.oct_bonus_wages+te.nov_bonus_wages+te.dec_bonus_wages+te.jan_bonus_wages+te.feb_bonus_wages+te.mar_bonus_wages,2) as tot_bonus_wages,te.tot_payable_days,te.tot_bonus_amt,te.tot_exgratia_amt, (te.tot_bonus_amt+te.tot_exgratia_amt) as total_bonus,te.bonus_rate, te.exgratia_rate, te.bankacno,bk.ifsc_code,emp.pay_mode 
		from employee emp inner join bonus te on te.emp_id = emp.emp_Id inner join mast_bank bk on bk.mast_bank_id = emp.bank_id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and (te.apr_payable_days + te.may_payable_days+te.jun_payable_days+te.jul_payable_days+te.aug_payable_days+te.sep_payable_days+te.oct_payable_days+te.nov_payable_days+te.dec_payable_days+te.jan_payable_days+te.feb_payable_days+te.mar_payable_days) >=0 and emp.prnsrno !='Y'"; 
}
else
{
  $setSql ="select emp.emp_id,emp.first_name,emp.middle_name,emp.last_name,emp.joindate,emp.leftdate,te.client_id,round(te.apr_wages,2) as apr_wages,te.apr_bonus_wages,te.apr_payable_days,te.apr_bonus_amt,round(te.may_wages,2) as may_wages,te.may_bonus_wages,te.may_payable_days,te.may_bonus_amt,round(te.jun_wages,2)  as jun_wages, te.jun_bonus_wages, te.jun_payable_days, te.jun_bonus_amt, round( te.jul_wages,2) as jul_wages, te.jul_bonus_wages, te.jul_payable_days, te.jul_bonus_amt, round(te.aug_wages,2) as aug_wages, te.aug_bonus_wages, te.aug_payable_days, te.aug_bonus_amt, round(te.sep_wages,2) as sep_wages, te.sep_bonus_wages, te.sep_payable_days, te.sep_bonus_amt, round(te.oct_wages,2) as oct_wages, te.oct_bonus_wages, te.oct_payable_days, te.oct_bonus_amt, round(te.nov_wages) as nov_wages, te.nov_bonus_wages, te.nov_payable_days, te.nov_bonus_amt, round(te.dec_wages,2) as dec_wages, te.dec_bonus_wages, te.dec_payable_days, te.dec_bonus_amt, round(te.jan_wages,2) as jan_wages, te.jan_bonus_wages, te.jan_payable_days, te.jan_bonus_amt,round( te.feb_wages,2) as feb_wages, te.feb_bonus_wages, te.feb_payable_days, te.feb_bonus_amt, round(te.mar_wages,2) as mar_wages, te.mar_bonus_wages, te.mar_payable_days,  te.mar_bonus_amt,round(te.apr_bonus_wages+te.may_bonus_wages+te.jun_bonus_wages+te.jul_bonus_wages+te.aug_bonus_wages+te.sep_bonus_wages+te.oct_bonus_wages+te.nov_bonus_wages+te.dec_bonus_wages+te.jan_bonus_wages+te.feb_bonus_wages+te.mar_bonus_wages,2) as tot_bonus_wages,te.tot_payable_days,te.tot_bonus_amt, (te.tot_bonus_amt) as total_bonus,te.bonus_rate, te.bankacno,bk.ifsc_code,emp.pay_mode 
		from employee emp inner join bonus te on te.emp_id = emp.emp_Id inner join mast_bank bk on bk.mast_bank_id = emp.bank_id
		where te.client_id='$client' and te.from_date ='$startyear' and te.todate='$endyear' and (te.apr_payable_days + te.may_payable_days+te.jun_payable_days+te.jul_payable_days+te.aug_payable_days+te.sep_payable_days+te.oct_payable_days+te.nov_payable_days+te.dec_payable_days+te.jan_payable_days+te.feb_payable_days+te.mar_payable_days) >=0 and emp.prnsrno !='Y'"; 
    
}

//  $setSql= "SELECT concat(e.first_name,' ',e.middle_name,' ' ,e.last_name)as name,b.* from bonus b inner join employee e  on e.emp_id= b.emp_id where from_date = '".$startyear."' and todate ='".$endyear."' and b.emp_id in(select emp_id from employee where client_id ='".$client."')";
  $setRec = mysql_query($setSql);

$setCounter = mysql_num_fields($setRec);
$setMainHeader="Srno\t";
$setData="";
for ($i = 0; $i < $setCounter; $i++) {
    $setMainHeader .= mysql_field_name($setRec, $i)."\t";
    //print_r($setMainHeader);
}
//exit;
$srno=1;
while($rec = mysql_fetch_row($setRec))  {
    //print_r($rec);exit;
    $rowLine = $srno."\t";
    $srno++;
    foreach($rec as $value)       {
        if(!isset($value) || $value == "")  {
            $value = "\t";
        }   else  {
//It escape all the special charactor, quotes from the data.
            $value = strip_tags(str_replace('"', '""', $value));
			
            $value = '"' . $value . '"' . "\t";
        }
        $rowLine .= $value;
		if($value =='bankacno'){
				$value = '\''.$value;
			}
    }
    $setData .= trim($rowLine)."\n";
}
$setData = str_replace("\r", "", $setData);

if ($setData == "") {
    $setData = "\nno matching records found\n";
}

//This Header is used to make data download instead of display the data
header("Content-type: application/octet-stream");

header("Content-Disposition: attachment; filename=".$setExcelName.".xls");

header("Pragma: no-cache");
header("Expires: 0");

//It will print all the Table row as Excel file row with selected column name as header.
echo ucwords($setMainHeader)."\n".$setData."\n";
?>