<?php
session_start();
//print_r($_SESSION); 
if(isset($_SESSION['log_id'])&&$_SESSION['log_id']==''){
    header("location:../index.php");
}
             if($_SESSION['startbonusyear']=='' || $_SESSION['endbonusyear']=='')
                        {
                               echo "<h1>Invalid Bonus Year</h1>";
                                header( "refresh:3;url=/user-home" );
                        }
ini_set('display_errors',1);
ini_set('display_startup_errors',1);
//ini_set('max_execution_time',900);
//set_time_limit(900);
error_reporting(0);


include("../lib/connection/db-config.php");
include("../lib/class/user-class.php");
$userObj=new user();
$comp_id=$_SESSION['comp_id'];
$user_id=$_SESSION['log_id'];
$result1 = $userObj->showClient1($comp_id,$user_id);
$result2 = $userObj->getBonusType();
$_SESSION['month']='current';
?>
<!DOCTYPE html>
<head>
  <meta charset="utf-8"/>
  <!-- Set the viewport width to device width for mobile -->
  <meta name="viewport" content="width=device-width"/>
  <title>Bonus |calculation</title>
  <!-- Included CSS Files -->

  <link rel="stylesheet" href="../css/responsive.css">
  <link rel="stylesheet" href="../css/style.css">
    <link rel="stylesheet" href="../css/jquery-ui.css">
    <script type="text/javascript" src="../js/jquery.min.js"></script>
    <script type="text/javascript" src="../js/jquery-ui.js"></script>

 <body>
<!--Header starts here-->
<?php include('header.php');?>
<!--Header end here-->
<div class="clearFix"></div>
<!--Menu starts here-->

<?php include('menu.php');?>

<!--Menu ends here-->
<div class="clearFix"></div>
<!--Slider part starts here-->

<div class="twelve mobicenter innerbg">
    <div class="row">
        <div class="twelve" id="margin1"> <h3>Bonus</h3></div>
         <?php 
                  /* if($_SESSION['startbonusyear']=='' || $_SESSION['endbonusyear']=='')
                        {
                               echo "<h1>Invalid Bonus Year</h1>";
                                header( "refresh:3;url=/user-home" );
                        }*/

        ?>     
        <div class="clearFix"></div>

        <div class="twelve" id="margin1">
            <div class="boxborder" id="adddepartment">
		<div class="four padd0 columns"  >
		
		
		<div class="three padd0 columns"  >
                <span class="labelclass">Client :</span>
            </div>
		
	
		
		
					
            <div class="eight padd0 columns"  >
                <select class="textclass" name="client" id="client" >
                    <option value="">--Select--</option>
                    <?php
                    
                    
                    while($row1=mysql_fetch_array($result1)){?>
                        <option value="<?php echo $row1['mast_client_id']; ?>"><?php echo $row1['client_name']; ?></option>
                    <?php } ?>

                </select>
                <span class="errorclass hidecontent" id="nerror"></span>

            </div>
			<div class="one padd0 columns"  ></div>
		</div>
		
		<div class="four padd0 columns"  >
			<div class="three padd0 columns" >

                <span class="labelclass">Type :</span>
            </div>
            <div class="eight padd0  columns">
			<select name="type" class="textclass" id="type" onchange="displaywages(this.value)">
			<option value="">--- Select Type ---</option>
                <?php while($row = mysql_fetch_array($result2)){?>
				<option value="<?php echo $row['id'];?>"><?php echo $row['name'];?></option>
				<?php }?>
				
				</select>
				<span class="errorclass hidecontent" id="tyerror"></span>
            </div>
			<div class="one padd0 columns"  ></div>
		</div>
		 <div class="clearFix">&nbsp;</div>
		 <span id="wamt" class="hidecontent">
		 <div class="four padd0 columns hidecontent" id="wamtsec" >
				<div class="three padd0 columns"> Wages :</div>
				<div class="eight padd0 columns"><input type="text" name="amount" class="textclass" value="7000" id="amount"> <span class="errorclass hidecontent" id="wagerror"></span></div>
				<div class="one padd0 columns"></div>
		</div>
		 <div class="four padd0 columns"  >
			<div class="three padd0 columns">Bonus Rate :</div>
			<div class="eight padd0 columns"><input type="text" name="bonus_rate" class="textclass" value="8.33" style="width:90%" id="bonusrate"> &nbsp; % <span class="errorclass hidecontent" id="bonerror"></span></div>
			<div class="one padd0 columns"></div>
		 </div>
		 <div class="four padd0 columns"  >
			<div class="three padd0 columns">Exgratia :</div>
			<div class="eight padd0 columns"><input type="text" name="exgratia" class="textclass" value="0" id="exgratia"style="width:90%"> &nbsp; % <span class="errorclass hidecontent" id="exgerror"></span></div>
			<div class="one padd0 columns"></div>
		 </div>
		  <div class="clearFix">&nbsp;</div>
		 </span>
		
				
			 <div class="one padd0 columns"  >
                <span class="labelclass">Client Type</span>
            </div>
			  <div class="two columns">
                <input type="radio" name="comptype"  value="org"  checked>  As per Existing Record<br>
                <input type="radio" name="comptype"  value="new" >  As per New Client
            </div>
          
        <div class="clearFix">&nbsp;</div>
	
		
           
			<div class="one padd0 columns" align="center">
			    
			    


                <input type="button" onclick="calulation();" class="btnclass" value="Calculate">



            </div>
			<div class="clearFix">&nbsp;</div>
			<div class="twelve padd0 columns hidecontent"  id="sucmessage">

                
            </div>
            
          
       
		
        <div class="clearFix"></div>
		<div id="display"></div>
		 </div>
		  </div>
    </div>   
    </div>

</div>

<!--Slider part ends here-->
<div class="clearFix"></div>
<div id="test"></div>
<!--footer start -->
<?php include('footer.php');?>


<!--footer end -->
<script>
function calulation(){
	var client = $("#client").val();
	var type = $("#type").val();
	var amount = $("#amount").val();
	var bonusrate = $("#bonusrate").val();
	//var comptype= $("#comptype").val();
	var comptype1 = document.getElementsByName('comptype');
	 for (var i = 0; i < comptype1.length; i++) {       
        if (comptype1[i].checked) {
           
			var comptype = comptype1[i].value;
            break;
        }
    }
	var exgratia = $("#exgratia").val();
	var sessionstartdate = '<?php  if(isset($_SESSION['startbonusyear'])){echo $_SESSION['startbonusyear'];};?>';
	var sessionenddate = '<?php  if(isset($_SESSION['endbonusyear'])){echo $_SESSION['endbonusyear'];};?>';
	if(sessionstartdate =="" || sessionenddate==""){		
		$("#display").html('<div class="error31">Please select bonus Year</div>');
		return false;
	}
	if(client ==""){
		$("#nerror").show();
		$("#nerror").text("Please select client");
		return false;
	}else if(type ==""){
		$("#tyerror").show();
		$("#tyerror").text("Please select Type");
		return false;		
	}else if(amount ==""){
		$("#wagerror").show();
		$("#wagerror").text("Please enter wages");
		return false;		
	}else if(bonusrate ==""){
		$("#bonerror").show();
		$("#bonerror").text("Please enter bonus rate");
		return false;		
	}if(exgratia ==""){
		$("#exgerror").show();
		$("#exgerror").text("Please enter exgratia rate");
		return false;		
	}else{
		$("#nerror").hide();
		$("#tyerror").hide();
		$("#wagerror").hide();
		$("#bonerror").hide();
		$("#exgerror").hide();	
	
	$('#display').html('<div style="height: 200px;width:400px;padding-top:100px;" align="left"> <img src="../images/loading.gif" /></div>');
  
	$.post('/calculation-bonus',{
			'client':client,
			'type':type,
			'exgratia':exgratia,
			'bonusrate':bonusrate,
			'amount':amount,
			'comptype':comptype
			
            },function(data){ 
                alert(data);

			$("#test").text(data);
//			$("#test").hide();
			$('#display').hide();			
             
            })
}
}
function displaywages(val){
	$("#wamt").show();
	if(val =='2' || val =='3'){
		$("#wamtsec").show();
	}else{
		$("#wamtsec").hide();
	}
}


function updatelock(){
	var client = $("#client").val();
	
	if(client ==""){
		$("#nerror").show();
		$("#nerror").text("Please select client");
		return false;
	}else{
		$("#nerror").hide();
		$("#tyerror").hide();
		$("#wagerror").hide();
		$("#bonerror").hide();
		$("#exgerror").hide();	
	

	$.post('/updatebonuslock',{
			'client':client
	        },function(data){ 
			$("#test").text(data);
			$('#sucmessage').show();
			$('#sucmessage').html('<div class="success31">&nbsp; &nbsp; Record Successfully Updated !</div>');
			$('#display').hide();			
             
            });
}
}





</script>

</body>

</html>