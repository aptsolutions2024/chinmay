<?php
session_start();
error_reporting(0);
echo "!!!";
include("../lib/connection/db-config.php");
include("../lib/class/user-class.php");
$userObj=new user();
$client_id = $_REQUEST['client'];
$result = $userObj->updateBonusLock($client_id,$_SESSION['startbonusyear'],$_SESSION['endbonusyear']);
if ($result>0)
{
    echo "Data locked successfully!!!";
}
?>

