<?php
session_start();
//error_reporting(0);
include("../lib/connection/db-config.php");
$bonusyear=$_REQUEST['bonusyear'];
$byear=explode("-",$bonusyear);
//print_r($byear);
$startday=$byear[0]."-04-30";
$endday =$byear[1]."-03-31";
$_SESSION['startbonusyear'] = $startday;
$_SESSION['endbonusyear'] = $endday;
echo "Bonus year saved successfully";
?>